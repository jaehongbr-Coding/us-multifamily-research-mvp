# 한국어 높은 신뢰도 Watchlist

- 생성 시각: 2026-05-14 16:21:11
- 참고 원문 파일: `high_confidence_watchlist_report.md`
- 번역 방식: 규칙 기반 한국어 요약. OpenAI/GPT API는 호출하지 않음.

## 높은 신뢰도 신호

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: New York, 멀티패밀리, 점수 94 (Refinancing opportunity; Review immediately)
- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: Sun Belt, 주거복합, 점수 92 (Institutional capital movement; Review immediately)
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: Sun Belt, 멀티패밀리, 점수 88 (Refinancing opportunity; Review immediately)
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: New York, 일반 주거, 점수 88 (Institutional capital movement; Review immediately)
- Disposition / Exit - Other / Unknown - Marcus & Millichap Arranges Sale of 64-Unit Multifamily Property Waterview Apartments in L...: 기타 / 미확인, 멀티패밀리, 점수 82 (LA urban infill opportunity; Maintain on strategic radar)
- Operational / Property Management Tech - Texas - Crypto rewards eye renters who want to save for a down payment: Texas, 일반 주거, 점수 80 (Institutional capital movement; Maintain on strategic radar)
- Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek in West Nashville.: Sun Belt, 주거복합, 점수 78 (LA urban infill opportunity; Maintain on strategic radar)
- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco: California, 시니어 하우징, 점수 77 (Entitlement progression; Track entitlement progression)
- BTR / Build-to-Rent - National - Trump Pushes House To Pass Housing Bill With BTR Forced-Sale Provision: Unknown, 아파트, 점수 75 (Construction start pipeline; Monitor construction execution)
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: California, 어포더블 하우징, 점수 72 (Construction start pipeline; Monitor construction execution)

## 기관투자자급 신호

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: New York, 멀티패밀리, 점수 94 (Strong Institutional Signal)
- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: Sun Belt, 주거복합, 점수 92 (Strong Institutional Signal)
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: New York, 일반 주거, 점수 88 (Strong Institutional Signal)
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: Sun Belt, 멀티패밀리, 점수 88 (Strong Institutional Signal)

## 노이즈 제외 후 봐야 할 항목

- 반복 출현, 구체적 프로젝트명, sponsor/lender 식별, lifecycle 일관성이 있는 항목을 우선 검토합니다.
