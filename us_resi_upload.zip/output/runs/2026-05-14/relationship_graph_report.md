# Developer Network & Relationship Graph Report

Generated: 2026-05-14 16:21:11

- Total relationship edges: 40
- Most connected developer / GP: Crescent Communities (3 edge(s))
- Most connected lender / debt provider: fannie mae (1 edge(s))
- Most connected market: Los Angeles (5 edge(s))
- Strongest relationship edge: Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village... -> fannie mae
- Highest Woomi relevance edge: Crescent Communities -> JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...

## Top 10 Relationship Edges

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village... -> fannie mae: Financing Relationship, New York, score 74. Monitor lender activity.
- Crescent Communities -> JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: JV / Partnership, Sun Belt, score 72. Review potential JV relevance.
- Crescent Communities -> Nashville: JV / Partnership, Sun Belt, score 72. Review potential JV relevance.
- Crescent Communities -> Sun Belt: JV / Partnership, Sun Belt, score 72. Review potential JV relevance.
- Blackstone -> blackstone: Capital Flow, New York, score 71. Track GP relationship history.
- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village... -> New York: Financing Relationship, New York, score 66. Monitor only.
- Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal... -> cbre: Financing Relationship, Other / Unknown, score 65. Monitor lender activity.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl... -> berkadia: Financing Relationship, Sun Belt, score 65. Monitor lender activity.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd. -> Los Angeles: Market Expansion, Los Angeles, score 62. Track LA / California activity.
- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena -> Los Angeles: Entitlement / Permitting, Los Angeles, score 61. Track LA / California activity.

## Developer / GP Relationship Map

- Crescent Communities -> JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: JV / Partnership, Sun Belt, score 72. Review potential JV relevance.
- Crescent Communities -> Nashville: JV / Partnership, Sun Belt, score 72. Review potential JV relevance.
- Crescent Communities -> Sun Belt: JV / Partnership, Sun Belt, score 72. Review potential JV relevance.
- Blackstone -> blackstone: Capital Flow, New York, score 71. Track GP relationship history.
- Blackstone -> General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve...: Pricing / Valuation Signal, New York, score 59. Track GP relationship history.
- Blackstone -> New York: Market Expansion, New York, score 57. Track GP relationship history.

## Lender / Debt Provider Relationship Map

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village... -> fannie mae: Financing Relationship, New York, score 74. Monitor lender activity.
- Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal... -> cbre: Financing Relationship, Other / Unknown, score 65. Monitor lender activity.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl... -> berkadia: Financing Relationship, Sun Belt, score 65. Monitor lender activity.
- Acquisition - Other / Unknown - Mapletree Pays $100M for 97-Acre Future Logistics Site in Central Jersey -> jll: Financing Relationship, Other / Unknown, score 51. Monitor lender activity.

## Capital Partner / Institutional Flow Map

- Blackstone -> blackstone: Capital Flow, New York, score 71. Track GP relationship history.

## Market Relationship Map

- Crescent Communities -> Nashville: JV / Partnership, Sun Belt, score 72. Review potential JV relevance.
- Crescent Communities -> Sun Belt: JV / Partnership, Sun Belt, score 72. Review potential JV relevance.
- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village... -> New York: Financing Relationship, New York, score 66. Monitor only.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd. -> Los Angeles: Market Expansion, Los Angeles, score 62. Track LA / California activity.
- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena -> Los Angeles: Entitlement / Permitting, Los Angeles, score 61. Track LA / California activity.
- Blackstone -> New York: Market Expansion, New York, score 57. Track GP relationship history.
- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd. -> Los Angeles: Market Expansion, Los Angeles, score 57. Track LA / California activity.
- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd. -> Southeast: Market Expansion, Los Angeles, score 57. Track LA / California activity.
- General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts -> Los Angeles: Market Expansion, Los Angeles, score 57. Track LA / California activity.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights -> Los Angeles: Market Expansion, Los Angeles, score 57. Track LA / California activity.

## California / LA Relationship Signals

- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd. -> Los Angeles: Market Expansion, Los Angeles, score 62. Track LA / California activity.
- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena -> Los Angeles: Entitlement / Permitting, Los Angeles, score 61. Track LA / California activity.
- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd. -> Los Angeles: Market Expansion, Los Angeles, score 57. Track LA / California activity.
- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd. -> Southeast: Market Expansion, Los Angeles, score 57. Track LA / California activity.
- General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts -> Los Angeles: Market Expansion, Los Angeles, score 57. Track LA / California activity.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights -> Los Angeles: Market Expansion, Los Angeles, score 57. Track LA / California activity.
- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco -> California: Entitlement / Permitting, California, score 54. Track LA / California activity.
- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco -> San Francisco: Entitlement / Permitting, California, score 54. Track LA / California activity.

## Potential Woomi Partnership Signals

- Crescent Communities -> JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: JV / Partnership, Sun Belt, score 72. Review potential JV relevance.
- Crescent Communities -> Nashville: JV / Partnership, Sun Belt, score 72. Review potential JV relevance.
- Crescent Communities -> Sun Belt: JV / Partnership, Sun Belt, score 72. Review potential JV relevance.
- JV / Partnership - Other / Unknown - Affordable Senior Housing Community Southernside West Set to Break Ground in Greenvillen S... -> JV / Partnership - Other / Unknown - Affordable Senior Housing Community Southernside West Set to Break Ground in Greenvillen S...: JV / Partnership, Other / Unknown, score 46. Review potential JV relevance.

## Canonical Relationship Map

| Source | Target | Relationship | Confidence |
| --- | --- | --- | ---: |
| Fannie Mae | Fannie Mae | Financing Relationship | 60 |
| Crescent Communities | Los Angeles | JV / Partnership | 40 |
| Crescent Communities | Sun Belt | JV / Partnership | 40 |
| Crescent Communities | Sun Belt | JV / Partnership | 40 |
| Blackstone | Blackstone | Capital Flow | 75 |
| Fannie Mae | New York | Financing Relationship | 60 |
| CBRE | CBRE | Financing Relationship | 60 |
| Berkadia | Berkadia | Financing Relationship | 60 |
| Los Angeles | Los Angeles | Market Expansion | 60 |
| Los Angeles | Los Angeles | Entitlement / Permitting | 60 |

## Multi-Source Confirmation Summary

Canonical deal fingerprints are available in `deal_fingerprint_report.md`.
Relationship repeat strength uses unique canonical deal/event counts instead of raw article volume.

## Emerging GP Watchlist Reference

Ranked GP watchlist signals are available in `gp_watchlist_report.md`.
- Crescent Communities: 66 (Tier 3 Monitoring GP), Potential GP partnership candidate.
- Blackstone: 58 (Tier 3 Monitoring GP), Potential GP partnership candidate.

## GP Source Expansion Summary

Developer / GP source coverage is available in `gp_source_coverage_report.md`.
Better GP, lender, and capital platform feeds should improve relationship graph quality over time.

## Source Activation Summary

Validated source activation scoring is available in `source_activation_report.md`.
Use that report to prioritize source fixes that should improve relationship edge quality.

## Historical Persistence Summary

Recurring relationship tracking is available in `relationship_persistence_report.md`.
Capital-flow memory is available in `capital_flow_report.md`.
Longitudinal memory is available in `historical_memory_report.md`.

## Recommended Executive Follow-Up

- Monitor lender activity: Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village... -> fannie mae (Financing Relationship).
- Review potential JV relevance: Crescent Communities -> JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek... (JV / Partnership).
- Review potential JV relevance: Crescent Communities -> Nashville (JV / Partnership).
- Review potential JV relevance: Crescent Communities -> Sun Belt (JV / Partnership).
- Track GP relationship history: Blackstone -> blackstone (Capital Flow).
- Monitor only: Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village... -> New York (Financing Relationship).
- Monitor lender activity: Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal... -> cbre (Financing Relationship).
- Monitor lender activity: General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl... -> berkadia (Financing Relationship).



## Persistent Asset Memory Summary

- Raw project references: 344
- Canonical projects: 85
- Duplicate project clusters: 46
- Persistent assets tracked: 85
- LA persistent asset watch items: 51
- See `project_identity_report.md`, `persistent_asset_memory_report.md`, and `la_persistent_asset_watch_report.md` for canonical project tracking.

