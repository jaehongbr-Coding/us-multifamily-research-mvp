# LA / Southern California Asset Watch Report

Generated: 2026-05-14 16:21:12

- Total LA / Southern California asset watch items: 28

## Top LA Site-Level Opportunities

- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Los Angeles, Affordable / Density Bonus Strategy, la_asset_opportunity_score 100.
- General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts: Los Angeles, Affordable / Density Bonus Strategy, la_asset_opportunity_score 100.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, Affordable / Density Bonus Strategy, la_asset_opportunity_score 100.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Los Angeles, Lease-Up / Delivery, la_asset_opportunity_score 100.
- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: Los Angeles, General Asset Signal, la_asset_opportunity_score 99.
- General Project Signal - Other / Unknown - 22 homes pitched for 1072 E. Villa St. in Pasadena: Los Angeles, General Asset Signal, la_asset_opportunity_score 91.
- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Los Angeles, Refinancing / Recapitalization, la_asset_opportunity_score 90.
- New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Los Angeles, Affordable / Density Bonus Strategy, la_asset_opportunity_score 90.
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, Affordable / Density Bonus Strategy, la_asset_opportunity_score 90.
- New look for affordable housing at 10304 S. Central Ave. in Watts: Los Angeles, Affordable / Density Bonus Strategy, la_asset_opportunity_score 90.

## Top LA Site-Level Risks

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Los Angeles, Refinancing / Recapitalization, la_asset_risk_score 57.
- HUD trims environmental reviews for multifamily projects: Los Angeles, General Asset Signal, la_asset_risk_score 42.
- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Los Angeles, Affordable / Density Bonus Strategy, la_asset_risk_score 40.
- General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts: Los Angeles, Affordable / Density Bonus Strategy, la_asset_risk_score 40.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, Affordable / Density Bonus Strategy, la_asset_risk_score 40.
- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: Los Angeles, General Asset Signal, la_asset_risk_score 40.
- New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Los Angeles, Affordable / Density Bonus Strategy, la_asset_risk_score 40.
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, Affordable / Density Bonus Strategy, la_asset_risk_score 40.
- Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: Los Angeles, General Asset Signal, la_asset_risk_score 40.
- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco: Los Angeles, Entitlement Play, la_asset_risk_score 36.

## Koreatown / Wilshire Site Watch

- None detected.

## DTLA / Office Conversion Site Watch

- None detected.

## Hollywood / TOD Site Watch

- None detected.

## Pasadena / Entitlement Watch

- None detected.

## Orange County / Suburban Apartment Watch

- None detected.

## Inland Empire / BTR Watch

- None detected.

## Local Sponsor / Developer Watch

- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: Los Angeles, General Asset Signal, la_asset_opportunity_score 87.
- General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve...: Los Angeles, General Asset Signal, la_asset_opportunity_score 72.

## Recommended LA Asset Follow-up Actions

- Review parcel clue, entitlement path, sponsor, and comparable sites: Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena.
- Review parcel clue, entitlement path, sponsor, and comparable sites: General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts.
- Review parcel clue, entitlement path, sponsor, and comparable sites: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.
- Review parcel clue, entitlement path, sponsor, and comparable sites: General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd..
- Review parcel clue, entitlement path, sponsor, and comparable sites: General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd..
- Monitor asset for repeated local confirmation: General Project Signal - Other / Unknown - 22 homes pitched for 1072 E. Villa St. in Pasadena.
- Track lender, maturity, owner, and recapitalization path: Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village....
- Review parcel clue, entitlement path, sponsor, and comparable sites: New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena.



## Development Lifecycle Intelligence Summary

- Lifecycle records: 48
- LA lifecycle watch items: 29
- Stage mix: Site Acquisition / Site Control: 5, Vertical Construction: 3, Refinancing / Recapitalization: 4, Unknown Stage: 26, Delivery / Opening: 7
- See `development_lifecycle_report.md` and `la_development_lifecycle_watch_report.md` for project timing, entitlement, permit, construction, delivery, and refinancing stages.




## Lifecycle Transition Summary

- Lifecycle transitions analyzed: 48
- Newly detected projects: 0
- Forward progression projects: 0
- Possible stalled projects: 0
- LA lifecycle transition watch items: 26
- See `lifecycle_transition_report.md` and `la_lifecycle_transition_watch_report.md` for multi-run project movement and timing signals.




## Persistent Asset Memory Summary

- Raw project references: 344
- Canonical projects: 85
- Duplicate project clusters: 46
- Persistent assets tracked: 85
- LA persistent asset watch items: 51
- See `project_identity_report.md`, `persistent_asset_memory_report.md`, and `la_persistent_asset_watch_report.md` for canonical project tracking.

