# Market Entry Window Report

Generated: 2026-05-18 16:30:55

## Top Market Entry Windows

- Los Angeles: score 85, Active Watch Window, posture: Actively source opportunities.
- Sun Belt: score 62, Early Signal / Prepare, posture: Prepare GP conversations.
- National / Other: score 57, Early Signal / Prepare, posture: Monitor refinancing and distress pipeline.
- Florida: score 47, Monitor Only, posture: Prepare GP conversations.
- New York: score 44, Monitor Only, posture: Prepare GP conversations.
- California: score 42, Monitor Only, posture: Prepare GP conversations.
- Texas: score 29, Not Attractive Now, posture: Monitor only.
- Seattle: score 8, Not Attractive Now, posture: Monitor only.

## LA / California Entry Window

- Los Angeles: score 85, Active Watch Window, posture: Actively source opportunities.
- California: score 42, Monitor Only, posture: Prepare GP conversations.

## Sun Belt Entry Window

- Sun Belt: score 62, Early Signal / Prepare, posture: Prepare GP conversations.
- Florida: score 47, Monitor Only, posture: Prepare GP conversations.
- Texas: score 29, Not Attractive Now, posture: Monitor only.

## New York / Refinancing Stress Window

- New York: score 44, Monitor Only, posture: Prepare GP conversations.

## Entitlement / LA Watch Summary

Developer-grade entitlement detail is available in `entitlement_intelligence_report.md`.
LA / California entitlement watch is available in `la_entitlement_watch_report.md`.

## Sector-Specific Entry Implications

- Multifamily and apartment signals remain the core entry lens.
- BTR / SFR, affordable/workforce housing, and office conversion timing should be reviewed when their timing signals appear.

## Recommended Entry Posture By Market

- Los Angeles: Actively source opportunities (Active Watch Window).
- Sun Belt: Prepare GP conversations (Early Signal / Prepare).
- National / Other: Monitor refinancing and distress pipeline (Early Signal / Prepare).
- Florida: Prepare GP conversations (Monitor Only).
- New York: Prepare GP conversations (Monitor Only).
- California: Prepare GP conversations (Monitor Only).
- Texas: Monitor only (Not Attractive Now).
- Seattle: Monitor only (Not Attractive Now).

## Key Risks and Opportunities

- Los Angeles: risks: financing stress and refinancing pressure; supply, delivery, lease-up, or concession pressure; entitlement, zoning, permitting, and policy uncertainty; opportunities: active opportunity radar signals; possible distress or recapitalization watch; capital-flow or institutional activity signal; core Woomi California / LA strategic relevance.
- Sun Belt: risks: supply, delivery, lease-up, or concession pressure; opportunities: active opportunity radar signals; capital-flow or institutional activity signal.
- National / Other: risks: supply, delivery, lease-up, or concession pressure; opportunities: active opportunity radar signals; possible distress or recapitalization watch.
- Florida: risks: limited timing evidence; opportunities: active opportunity radar signals; capital-flow or institutional activity signal.
- New York: risks: limited timing evidence; opportunities: active opportunity radar signals; capital-flow or institutional activity signal.

## Executive Summary for Woomi

- Top current market entry window is Los Angeles with a Active Watch Window label and posture: Actively source opportunities.



## Development Lifecycle Intelligence Summary

- Lifecycle records: 54
- LA lifecycle watch items: 32
- Stage mix: Unknown Stage: 28, Vertical Construction: 4, Site Acquisition / Site Control: 8, Delivery / Opening: 9, Early Site Signal: 4
- See `development_lifecycle_report.md` and `la_development_lifecycle_watch_report.md` for project timing, entitlement, permit, construction, delivery, and refinancing stages.




## Lifecycle Transition Summary

- Lifecycle transitions analyzed: 54
- Newly detected projects: 0
- Forward progression projects: 0
- Possible stalled projects: 0
- LA lifecycle transition watch items: 30
- See `lifecycle_transition_report.md` and `la_lifecycle_transition_watch_report.md` for multi-run project movement and timing signals.

