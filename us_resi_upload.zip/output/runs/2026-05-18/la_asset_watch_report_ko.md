# 한국어 LA 자산 / 프로젝트 Watch

- 생성 시각: 2026-05-18 16:30:54
- 참고 원문 파일: `la_asset_watch_report.md`
- 번역 방식: 규칙 기반 한국어 요약. OpenAI/GPT API는 호출하지 않음.

## LA / Southern California 자산 Watch

- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: Los Angeles, 주거복합, 점수 100 (Unknown; Review parcel clue, entitlement path, sponsor, and comparable sites)
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, 어포더블 하우징, 점수 100 (Unknown; Review parcel clue, entitlement path, sponsor, and comparable sites)
- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Los Angeles, 아파트, 점수 100 (Unknown; Review parcel clue, entitlement path, sponsor, and comparable sites)
- Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave.: Los Angeles, 어포더블 하우징, 점수 100 (Site Search / Early Signal; Review parcel clue, entitlement path, sponsor, and comparable sites)
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Los Angeles, 아파트, 점수 100 (Delivered / Lease-Up; Review parcel clue, entitlement path, sponsor, and comparable sites)
- Acquisition - Other / Unknown - Guardian Acquires 332-Unit Ladd Tower Apartment Building in Downtown Portland: Los Angeles, 아파트, 점수 100 (Site Controlled; Monitor asset for repeated local confirmation)
- Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles: Los Angeles, 주거복합, 점수 90 (Delivered / Lease-Up; Review parcel clue, entitlement path, sponsor, and comparable sites)
- 96 apartments + retail proposed at 8871 W. Venice Blvd.: Los Angeles, 주거복합, 점수 90 (Unknown; Review parcel clue, entitlement path, sponsor, and comparable sites)
- Metro partners with developer on plans for housing at G Line's Balboa Station: Los Angeles, 어포더블 하우징, 점수 90 (Unknown; Review parcel clue, entitlement path, sponsor, and comparable sites)
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, 어포더블 하우징, 점수 90 (Unknown; Review parcel clue, entitlement path, sponsor, and comparable sites)

## 프로젝트 / 부지 단서

- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: 8871 W. Venice Blvd, Los Angeles
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: 1321 N. Mission Rd, Los Angeles
- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Southern California, Los Angeles
- Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave.: 4301 S. Vermont Ave, Los Angeles
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: 5700 Wilshire Blvd, Los Angeles

## 인허가 / 개발 단계

- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Los Angeles, 아파트, 점수 100 (Unknown Stage; Create or refresh a project watch file with sponsor, site, entitlement, financing, and timing notes)
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: Los Angeles, 주거복합, 점수 95 (Unknown Stage; Monitor for repeated project updates)
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, 어포더블 하우징, 점수 95 (Unknown Stage; Monitor for repeated project updates)
- Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave.: Los Angeles, 어포더블 하우징, 점수 95 (Unknown Stage; Monitor for repeated project updates)
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Los Angeles, 아파트, 점수 95 (Unknown Stage; Monitor for repeated project updates)

## 추천 현지 확인 사항

- 주소 단서, 스폰서, site control, 인허가 단계, financing signal을 함께 확인합니다.
