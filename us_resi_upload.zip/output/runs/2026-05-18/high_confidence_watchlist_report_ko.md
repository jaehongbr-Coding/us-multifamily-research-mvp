# 한국어 높은 신뢰도 Watchlist

- 생성 시각: 2026-05-18 16:30:54
- 참고 원문 파일: `high_confidence_watchlist_report.md`
- 번역 방식: 규칙 기반 한국어 요약. OpenAI/GPT API는 호출하지 않음.

## 높은 신뢰도 신호

- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: California, 아파트, 점수 91 (LA urban infill opportunity; Review immediately)
- Disposition / Exit - California - Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale: California, 어포더블 하우징, 점수 90 (LA urban infill opportunity; Review immediately)
- BTR / Build-to-Rent - Sun Belt - NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino: Sun Belt, BTR / 단독주택 임대, 점수 89 (BTR expansion; Review immediately)
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: New York, 일반 주거, 점수 88 (Institutional capital movement; Review immediately)
- Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee: Sun Belt, 주거복합, 점수 86 (Construction start pipeline; Review immediately)
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: California, 주거복합, 점수 86 (Construction start pipeline; Review immediately)
- Disposition / Exit - Sun Belt - Institutional Property Advisors Closes Sale and Arranges Financing for Dallas Multifamily...: Sun Belt, 멀티패밀리, 점수 85 (LA urban infill opportunity; Review immediately)
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: 기타 / 미확인, 아파트, 점수 82 (Refinancing opportunity; Watch refinancing timing)
- BTR / Build-to-Rent - Florida - Adam America Real Estate and Stellar Communities Deliver First Homes at Havens at Palm Bay...: Florida, BTR / 단독주택 임대, 점수 81 (BTR expansion; Maintain on strategic radar)
- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Los Angeles, 아파트, 점수 80 (LA urban infill opportunity; Monitor sponsor relationship)

## 기관투자자급 신호

- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: California, 아파트, 점수 91 (Strong Institutional Signal)
- Disposition / Exit - California - Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale: California, 어포더블 하우징, 점수 90 (Strong Institutional Signal)
- BTR / Build-to-Rent - Sun Belt - NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino: Sun Belt, BTR / 단독주택 임대, 점수 89 (Strong Institutional Signal)
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: New York, 일반 주거, 점수 88 (Strong Institutional Signal)
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: California, 주거복합, 점수 86 (Strong Institutional Signal)

## 노이즈 제외 후 봐야 할 항목

- 반복 출현, 구체적 프로젝트명, sponsor/lender 식별, lifecycle 일관성이 있는 항목을 우선 검토합니다.
