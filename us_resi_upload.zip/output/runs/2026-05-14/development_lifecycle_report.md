# Development Lifecycle Report

Generated: 2026-05-14 16:21:12

- Total lifecycle records: 48

## Lifecycle Stage Distribution

- Unknown Stage: 26
- Delivery / Opening: 7
- Site Acquisition / Site Control: 5
- Refinancing / Recapitalization: 4
- Vertical Construction: 3
- Early Site Signal: 2
- Environmental Review / CEQA: 1

## Top Development Timing Opportunities

- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: Site Acquisition / Site Control, Nashville, lifecycle_opportunity_score 100.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Vertical Construction, Los Angeles, lifecycle_opportunity_score 86.
- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Refinancing / Recapitalization, New York, lifecycle_opportunity_score 85.
- General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve...: Unknown Stage, New York, lifecycle_opportunity_score 84.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Delivery / Opening, Los Angeles, lifecycle_opportunity_score 83.
- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: Delivery / Opening, Southeast, lifecycle_opportunity_score 82.
- CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Caldwell New Jersey: Refinancing / Recapitalization, Unknown, lifecycle_opportunity_score 81.
- New look for affordable housing at 10304 S. Central Ave. in Watts: Site Acquisition / Site Control, Los Angeles, lifecycle_opportunity_score 81.
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Vertical Construction, Lincoln Heights, lifecycle_opportunity_score 80.
- Entitlement / Permitting - Other / Unknown - Completion nears for mixed-use building at 3557 S. Motor Ave. in Palms: Delivery / Opening, Unknown, lifecycle_opportunity_score 77.

## Top Lifecycle Risks

- HUD trims environmental reviews for multifamily projects: Environmental Review / CEQA, Los Angeles, lifecycle_risk_score 65.
- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Refinancing / Recapitalization, New York, lifecycle_risk_score 62.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: Refinancing / Recapitalization, Miami, lifecycle_risk_score 60.
- Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal...: Refinancing / Recapitalization, Unknown, lifecycle_risk_score 60.
- CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Caldwell New Jersey: Refinancing / Recapitalization, Unknown, lifecycle_risk_score 53.
- General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts: Unknown Stage, Los Angeles, lifecycle_risk_score 34.
- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Unknown Stage, Los Angeles, lifecycle_risk_score 34.
- New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Unknown Stage, Los Angeles, lifecycle_risk_score 34.
- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco: Unknown Stage, San Francisco, lifecycle_risk_score 33.
- Formal Permits For 375 Laguna Honda Boulevard, San Francisco: Unknown Stage, Unknown, lifecycle_risk_score 33.

## Projects Under Entitlement / Planning

- HUD trims environmental reviews for multifamily projects: Environmental Review / CEQA, Los Angeles, lifecycle_opportunity_score 44.

## Construction-Ready / Construction-Start Signals

- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Vertical Construction, Los Angeles, lifecycle_opportunity_score 86.
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Vertical Construction, Lincoln Heights, lifecycle_opportunity_score 80.
- Development Start - National - Apartment Construction Starts Plummet To 15-Year Low: Vertical Construction, National, lifecycle_opportunity_score 71.

## Delivery / Lease-Up Signals

- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Delivery / Opening, Los Angeles, lifecycle_opportunity_score 83.
- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: Delivery / Opening, Southeast, lifecycle_opportunity_score 82.
- Entitlement / Permitting - Other / Unknown - Completion nears for mixed-use building at 3557 S. Motor Ave. in Palms: Delivery / Opening, Unknown, lifecycle_opportunity_score 77.
- Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: Delivery / Opening, Beverly Grove, lifecycle_opportunity_score 76.
- Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Delivery / Opening, Los Angeles, lifecycle_opportunity_score 76.
- Completion nears for mixed-use building at 3557 S. Motor Ave. in Palms: Delivery / Opening, Los Angeles, lifecycle_opportunity_score 75.
- General Project Signal - Other / Unknown - Multifamily Absorption Rate Remains Below 50%: Delivery / Opening, Unknown, lifecycle_opportunity_score 47.

## Distressed / Stalled Lifecycle Signals

- None detected.

## Refinancing / Recapitalization Lifecycle Signals

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Refinancing / Recapitalization, New York, lifecycle_risk_score 62.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: Refinancing / Recapitalization, Miami, lifecycle_risk_score 60.
- Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal...: Refinancing / Recapitalization, Unknown, lifecycle_risk_score 60.
- CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Caldwell New Jersey: Refinancing / Recapitalization, Unknown, lifecycle_risk_score 53.

## Implications for Woomi / Woomi Global

- Lifecycle intelligence helps translate site-level clues into timing decisions: watch, prepare, underwrite, partner, or wait.
- LA / California rows with planning, CEQA, permit, construction-ready, or stalled signals should be reviewed alongside entitlement and asset reports.

## Recommended Lifecycle Follow-up Actions

- Monitor lifecycle signal for repeated confirmation: JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek....
- Benchmark construction timeline, sponsor execution, and delivery risk: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.
- Track lender, maturity, debt terms, and recapitalization need: Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village....
- Monitor lifecycle signal for repeated confirmation: General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve....
- Benchmark delivery, lease-up, occupancy, and rent assumptions: General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd..
- Benchmark delivery, lease-up, occupancy, and rent assumptions: General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd..
- Track lender, maturity, debt terms, and recapitalization need: CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Caldwell New Jersey.
- Monitor lifecycle signal for repeated confirmation: New look for affordable housing at 10304 S. Central Ave. in Watts.



## Lifecycle Transition Summary

- Lifecycle transitions analyzed: 48
- Newly detected projects: 0
- Forward progression projects: 0
- Possible stalled projects: 0
- LA lifecycle transition watch items: 26
- See `lifecycle_transition_report.md` and `la_lifecycle_transition_watch_report.md` for multi-run project movement and timing signals.




## Persistent Asset Memory Summary

- Raw project references: 344
- Canonical projects: 85
- Duplicate project clusters: 46
- Persistent assets tracked: 85
- LA persistent asset watch items: 51
- See `project_identity_report.md`, `persistent_asset_memory_report.md`, and `la_persistent_asset_watch_report.md` for canonical project tracking.




## Signal Quality / Confidence Summary

- Signals evaluated: 85
- Institutional-grade signals: 4
- High-confidence signals: 14
- Weak/noisy signals: 61
- High-confidence watchlist items: 14
- See `signal_quality_report.md` and `high_confidence_watchlist_report.md` before using signals for executive decisions.

