# Real Asset & Parcel Intelligence Report

Generated: 2026-05-18 16:30:56

- Total asset / parcel signals: 54

## Top Site-Level Opportunities

- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: General Asset Signal, Southern California, asset_opportunity_score 100.
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: Entitlement Play, 8871 W. Venice Blvd, asset_opportunity_score 95.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Affordable / Density Bonus Strategy, 1321 N. Mission Rd, asset_opportunity_score 95.
- Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave.: Affordable / Density Bonus Strategy, 4301 S. Vermont Ave, asset_opportunity_score 95.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Lease-Up / Delivery, 5700 Wilshire Blvd, asset_opportunity_score 95.
- Acquisition - Other / Unknown - Guardian Acquires 332-Unit Ladd Tower Apartment Building in Downtown Portland: Acquisition / Site Control, Unknown, asset_opportunity_score 94.
- Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles: Lease-Up / Delivery, Los Angeles, asset_opportunity_score 85.
- Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee: Development Start, Nashville, asset_opportunity_score 85.
- Construction Financing - Other / Unknown - Cypress Equity Investments gets $170M loan for two Santa Monica projects: General Asset Signal, Unknown, asset_opportunity_score 84.
- General Project Signal - California - Metro partners with developer on plans for housing at G Line's Balboa Station: General Asset Signal, California, asset_opportunity_score 84.

## Top Site-Level Risks

- Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles: Lease-Up / Delivery, Los Angeles, asset_risk_score 56.
- Construction Financing - Other / Unknown - Cypress Equity Investments gets $170M loan for two Santa Monica projects: General Asset Signal, Unknown, asset_risk_score 54.
- Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC...: General Asset Signal, Unknown, asset_risk_score 54.
- Acquisition - Los Angeles - JLL Arranges Sale of 365,774 SF Industrial Portfolio Near Los Angeles Across Two Separate...: General Asset Signal, Los Angeles, asset_risk_score 52.
- Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades: General Asset Signal, Southern California, asset_risk_score 50.
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: Entitlement Play, 8871 W. Venice Blvd, asset_risk_score 40.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Affordable / Density Bonus Strategy, 1321 N. Mission Rd, asset_risk_score 40.
- General Project Signal - California - Metro partners with developer on plans for housing at G Line's Balboa Station: General Asset Signal, California, asset_risk_score 40.
- BTR / Build-to-Rent - Los Angeles - Core Spaces Secures $1.64B Fundraise for Student Housing Development, Investment: General Asset Signal, Los Angeles, asset_risk_score 40.
- 96 apartments + retail proposed at 8871 W. Venice Blvd.: Entitlement Play, 8871 W. Venice Blvd, asset_risk_score 40.

## Assets With Address / Location Clues

- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: General Asset Signal, Southern California, asset_opportunity_score 100.
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: Entitlement Play, 8871 W. Venice Blvd, asset_opportunity_score 95.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Affordable / Density Bonus Strategy, 1321 N. Mission Rd, asset_opportunity_score 95.
- Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave.: Affordable / Density Bonus Strategy, 4301 S. Vermont Ave, asset_opportunity_score 95.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Lease-Up / Delivery, 5700 Wilshire Blvd, asset_opportunity_score 95.
- Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles: Lease-Up / Delivery, Los Angeles, asset_opportunity_score 85.
- Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee: Development Start, Nashville, asset_opportunity_score 85.
- General Project Signal - California - Metro partners with developer on plans for housing at G Line's Balboa Station: General Asset Signal, California, asset_opportunity_score 84.
- BTR / Build-to-Rent - Los Angeles - Core Spaces Secures $1.64B Fundraise for Student Housing Development, Investment: General Asset Signal, Los Angeles, asset_opportunity_score 80.
- Disposition / Exit - California - Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale: General Asset Signal, California, asset_opportunity_score 76.

## Assets With Identified Developers / Sponsors

- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: General Asset Signal, Southern California, asset_opportunity_score 100.
- Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee: Development Start, Nashville, asset_opportunity_score 85.
- General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve...: General Asset Signal, New York, asset_opportunity_score 67.

## Assets With Entitlement or Permit Signals

- None detected.

## Assets With Financing / Refinancing Signals

- Cypress Equity Investments gets $170M loan for two Santa Monica projects: Refinancing / Recapitalization, 2025 Wilshire Boulevard, asset_risk_score 34.
- Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles: Refinancing / Recapitalization, Los Angeles, asset_risk_score 32.

## Office-to-Residential Asset Signals

- None detected.

## Affordable / Density Bonus Asset Signals

- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Affordable / Density Bonus Strategy, 1321 N. Mission Rd, asset_opportunity_score 95.
- Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave.: Affordable / Density Bonus Strategy, 4301 S. Vermont Ave, asset_opportunity_score 95.
- Metro partners with developer on plans for housing at G Line's Balboa Station: Affordable / Density Bonus Strategy, 6338 Balboa Boulevard, asset_opportunity_score 75.
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Affordable / Density Bonus Strategy, 1321 N. Mission Rd, asset_opportunity_score 75.
- Site prep underway for affordable housing at 4301 S. Vermont Ave.: Affordable / Density Bonus Strategy, 4301 S. Vermont Ave, asset_opportunity_score 75.

## Implications for Woomi / Woomi Global

- Asset and parcel intelligence helps connect strategy signals to specific sites, sponsors, permits, financing events, and construction stages.
- Rows with addresses, named projects, entitlement status, or site control clues should feed underwriting, local sponsor mapping, and site-screening conversations.

## Recommended Asset-Level Follow-up Actions

- Review site details, sponsor, entitlement path, and local precedent: Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments.
- Review site details, sponsor, entitlement path, and local precedent: Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd..
- Review site details, sponsor, entitlement path, and local precedent: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.
- Review site details, sponsor, entitlement path, and local precedent: Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave..
- Review site details, sponsor, entitlement path, and local precedent: General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd..
- Review acquisition, financing, ownership, and comparable transaction details: Acquisition - Other / Unknown - Guardian Acquires 332-Unit Ladd Tower Apartment Building in Downtown Portland.
- Review site details, sponsor, entitlement path, and local precedent: Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles.
- Monitor asset-level signal for repeated confirmation: Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee.



## Development Lifecycle Intelligence Summary

- Lifecycle records: 54
- LA lifecycle watch items: 32
- Stage mix: Unknown Stage: 28, Vertical Construction: 4, Site Acquisition / Site Control: 8, Delivery / Opening: 9, Early Site Signal: 4
- See `development_lifecycle_report.md` and `la_development_lifecycle_watch_report.md` for project timing, entitlement, permit, construction, delivery, and refinancing stages.




## Lifecycle Transition Summary

- Lifecycle transitions analyzed: 54
- Newly detected projects: 0
- Forward progression projects: 0
- Possible stalled projects: 0
- LA lifecycle transition watch items: 30
- See `lifecycle_transition_report.md` and `la_lifecycle_transition_watch_report.md` for multi-run project movement and timing signals.




## Persistent Asset Memory Summary

- Raw project references: 405
- Canonical projects: 100
- Duplicate project clusters: 55
- Persistent assets tracked: 100
- LA persistent asset watch items: 65
- See `project_identity_report.md`, `persistent_asset_memory_report.md`, and `la_persistent_asset_watch_report.md` for canonical project tracking.

