# LA / California Entitlement Watch Report

Generated: 2026-05-18 16:30:55

- Total LA / California entitlement watch items: 2

## Top LA / California Entitlement Opportunities

- Los Angeles: Entitlement Approval, Unknown Stage, score 45. Watch affordable housing requirement.
- L.A.: Entitlement Approval, Early Planning, score 45. Track entitlement precedent.

## Top LA / California Entitlement Risks

- Los Angeles: Entitlement Approval, Unknown Stage, score 38. Watch affordable housing requirement.
- L.A.: Entitlement Approval, Early Planning, score 20. Track entitlement precedent.

## Submarket Watch Table

| Submarket | Items | Top relevance |
| --- | ---: | ---: |
| Los Angeles | 1 | 65 |
| L.A. | 1 | 61 |

## Project / Sponsor Watch

- Los Angeles: Entitlement Approval, Unknown Stage, score 65. Watch affordable housing requirement.
- L.A.: Entitlement Approval, Early Planning, score 61. Track entitlement precedent.

## Office-to-Residential Watch

- None detected.

## Affordable / Density Bonus Watch

- Los Angeles: Entitlement Approval, Unknown Stage, score 65. Watch affordable housing requirement.

## Recommended Local Follow-up Actions

- Track local planning docket, sponsor, submarket, and entitlement precedent: Los Angeles / Entitlement Approval.
- Track local planning docket, sponsor, submarket, and entitlement precedent: L.A. / Entitlement Approval.

## Submarket / Parcel Intelligence Reference

Submarket-level site strategy detail is available in `submarket_intelligence_report.md` and `la_submarket_watch_report.md`.



## Development Lifecycle Intelligence Summary

- Lifecycle records: 54
- LA lifecycle watch items: 32
- Stage mix: Unknown Stage: 28, Vertical Construction: 4, Site Acquisition / Site Control: 8, Delivery / Opening: 9, Early Site Signal: 4
- See `development_lifecycle_report.md` and `la_development_lifecycle_watch_report.md` for project timing, entitlement, permit, construction, delivery, and refinancing stages.

