# Residential Sector Coverage Report

Generated: 2026-05-18 16:30:55

- Active residential sectors: 7

## Sector Coverage Summary

- Apartment: 13 article(s), 13 high-priority, 8 deal/project, Core Strategy Sector.
- Multifamily: 16 article(s), 5 high-priority, 10 deal/project, Core Strategy Sector.
- Affordable Housing: 5 article(s), 4 high-priority, 4 deal/project, Strategic Expansion Sector.
- Student Housing: 3 article(s), 2 high-priority, 3 deal/project, Strategic Expansion Sector.
- BTR / Single-Family Rental: 5 article(s), 1 high-priority, 5 deal/project, Strategic Expansion Sector.
- Mixed-Use Residential: 6 article(s), 5 high-priority, 5 deal/project, Monitoring Sector.
- General Residential: 5 article(s), 0 high-priority, 4 deal/project, Monitoring Sector.

## Top Residential Sectors By Relevance

- Apartment: Core Strategy Sector, average relevance 87.6, dominant market Other / Unknown.
- Multifamily: Core Strategy Sector, average relevance 70.4, dominant market Other / Unknown.
- Affordable Housing: Strategic Expansion Sector, average relevance 90.6, dominant market Los Angeles.
- Student Housing: Strategic Expansion Sector, average relevance 85.3, dominant market Los Angeles.
- BTR / Single-Family Rental: Strategic Expansion Sector, average relevance 66.8, dominant market Sun Belt.
- Mixed-Use Residential: Monitoring Sector, average relevance 88.5, dominant market Los Angeles.
- General Residential: Monitoring Sector, average relevance 57.8, dominant market Los Angeles.
- Manufactured Housing: Monitoring Sector, average relevance 0, dominant market None detected.

## Multifamily / Apartment

- Apartment: 13 article(s), 8 deal/project signal(s), Core Strategy Sector. Keep in weekly developer strategy review.
- Multifamily: 16 article(s), 10 deal/project signal(s), Core Strategy Sector. Keep in weekly developer strategy review.

## BTR / SFR

- BTR / Single-Family Rental: 5 article(s), 5 deal/project signal(s), Strategic Expansion Sector. Monitor BTR / SFR operators, capital flows, and target markets.

## Student Housing

- Student Housing: 3 article(s), 3 deal/project signal(s), Strategic Expansion Sector. Monitor university-market demand and partnership signals.

## Senior Housing

- Senior Housing: 0 article(s), 0 deal/project signal(s), Monitoring Sector. Monitor senior housing demand and operating model signals.

## Affordable / Workforce Housing

- Affordable Housing: 5 article(s), 4 deal/project signal(s), Strategic Expansion Sector. Track LA / California affordability, entitlement, and public-private partnership signals.
- Workforce Housing: 0 article(s), 0 deal/project signal(s), Monitoring Sector. Add to sector watchlist.

## Office-to-Residential Conversion

- Office-to-Residential Conversion: 0 article(s), 0 deal/project signal(s), Monitoring Sector. Track conversion feasibility, policy support, and construction cost assumptions.

## Sector Implications for Woomi / Woomi Global

- Strategic expansion sectors should be reviewed for product diversification, GP partnerships, and underwriting assumptions.
- Affordable and workforce housing signals in California / LA should feed entitlement and public-private partnership monitoring.

## Recommended Sector Follow-up Actions

- Apartment: Keep in weekly developer strategy review
- Multifamily: Keep in weekly developer strategy review
- Affordable Housing: Track LA / California affordability, entitlement, and public-private partnership signals
- Student Housing: Monitor university-market demand and partnership signals
- BTR / Single-Family Rental: Monitor BTR / SFR operators, capital flows, and target markets
- Mixed-Use Residential: Add to sector watchlist
- General Residential: Add to sector watchlist
- Manufactured Housing: Add to sector watchlist
- Office-to-Residential Conversion: Track conversion feasibility, policy support, and construction cost assumptions
- Senior Housing: Monitor senior housing demand and operating model signals
- Workforce Housing: Add to sector watchlist
