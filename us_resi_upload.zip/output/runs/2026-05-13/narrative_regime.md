# Narrative Regime Detection

Generated: 2026-05-13 17:23:17

## Detected Regime

- Primary regime: Selective Capital Re-entry
- Secondary regime: Developer Strategy Shift
- Confidence level: High
- Explanation: Institutional flow, deal-size, or major-player signals suggest the team should watch pricing discovery and capital re-entry.

## Regime Scorecard

| Regime | Score |
| --- | ---: |
| Selective Capital Re-entry | 68 |
| Developer Strategy Shift | 54 |
| Financing Stress | 46 |
| Supply Pressure | 26 |
| Policy / Entitlement Watch | 0 |
| Construction Cost Pressure | 0 |

## Regime Heatmap Reference

Calibrated 0-100 heatmap scores are available in `regime_heatmap_report.md` and `regime_heatmap.csv`.
Regime momentum is available in `regime_momentum_report.md` when previous heatmap history exists.

| Regime | Final Score | Strength |
| --- | ---: | --- |
| Selective Capital Re-entry | 89 | Very Strong |
| Financing Stress | 75 | Strong |
| Supply Pressure | 51 | Moderate |
| Developer Strategy Shift | 48 | Moderate |
| Policy / Entitlement Watch | 5 | Not Detected |
| Construction Cost Pressure | 3 | Not Detected |
| Stable Monitoring Environment | 0 | Not Detected |

## Signal Inputs

- Strategy-briefing articles reviewed: 22
- Market-signal articles reviewed: 17
- Articles with extracted numbers: 17
- Institutional player mentions: 4

### Strategic Angles

- Developer Strategy: 11
- Institutional Flow: 8
- Financing Risk: 7
- Rent Growth / Demand: 3
- Supply Pressure: 2

### Market Signals

- Deal Size Signal: 7
- Rent Growth Signal: 4
- Supply / Starts Signal: 3
- Financing Cost Signal: 2
- Vacancy Signal: 1

### Decision Uses

- Track Developer Strategy: 11
- Track Institutional Capital Flow: 8
- Track Financing Conditions: 7
- Track Rent / Vacancy Trend: 3
- Track Supply Pipeline: 2

### Market Focus

- Other / Unknown: 14
- National: 2
- New York: 2
- Florida: 2
- Sun Belt: 1
- Los Angeles: 1

### Action Levels

- Must Read: 10
- Review: 9
- Monitor: 3

### Woomi Relevance

- High relevance to US residential developer strategy: 15
- Medium relevance to market monitoring: 7

## Key Thematic Context

- Los Angeles focus is New Theme (0 to 1).
- Market signal activity is increasing, led by Supply / Starts Signal (2 to 3).

## Cross-Theme Interpretation

- Financing stress plus supply pressure may call for more conservative underwriting, especially around leverage, lease-up pace, and exit cap rates.
- Institutional flow plus cap rate or deal-size signals may indicate pricing discovery by major capital players.

## Implications for Woomi / Woomi Global

- Keep LA / California monitoring active because local policy, entitlement, and supply signals are directly relevant to market-entry planning.
- Track institutional capital flow to identify pricing signals, partnership targets, and markets where capital may be returning selectively.
- Use developer strategy signals to build US residential development capabilities around product type, delivery model, and GP partnership structure.

## Recommended Strategy Team Questions

- Are financing conditions changing enough to affect new development starts, refinancing, or exit cap assumptions?
- Are supply signals concentrated in specific markets, product types, or lease-up windows?
- Are institutional buyers returning to markets, assets, or capital structures relevant to Woomi?
- Are LA / California policy changes creating entitlement opportunities or risks?
