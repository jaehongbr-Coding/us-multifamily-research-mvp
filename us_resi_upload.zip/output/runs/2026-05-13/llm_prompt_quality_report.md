# LLM Prompt Quality Report

Generated: 2026-05-13 17:23:17

- Total prompts reviewed: 22
- Average prompt quality score: 87.1
- Excellent prompts: 14
- Good prompts: 8
- Needs Improvement prompts: 0
- Poor prompts: 0

## Top 5 Strongest Prompts

- 98 (Excellent): JLL Arranges $58M Refinancing for Newly Constructed Mixed-Use Multifamily Property in Brooklyn New York
- 98 (Excellent): Kilroy Sells 2 Hollywood High-Rises for $202M
- 98 (Excellent): Guardian and PCCP Joint Venture Acquire 23-Story Multifamily Community Ladd Tower in Downtown Portland
- 98 (Excellent): ECI Group, ApexOne partner on $500M multifamily fund
- 90 (Excellent): JLL Worked on Behalf of Seller on $40.85M Sale of Multifamily Portfolio in New Haven Connecticut

## Top 5 Weakest Prompts

- 74 (Good): Best Year for Missing Middle Construction Since 2007 - Missing: missing extracted numbers; missing market focus; missing market signal
- 74 (Good): Missing Middle Weakness - Missing: missing extracted numbers; missing market focus; missing market signal
- 74 (Good): Shorter Apartment Construction Time in 2024 - Missing: missing extracted numbers; missing market focus; missing market signal
- 74 (Good): Why Senior Housing’s Recovery Is Gaining Traction - Missing: missing extracted numbers; missing market focus; missing market signal
- 82 (Good): The Market Data that Matters for the rest of 2026: A Chat with Zillow’s Chief Economist - Missing: missing extracted numbers; missing market signal

## Common Missing Context Issues

- missing market focus: 14
- missing market signal: 9
- missing extracted numbers: 7
