# Institutional Relationship & Capital Flow Report

Generated: 2026-05-14 16:21:11

## Top Institutional Relationship Signals

- Blackstone: score 88, Capital Inflow, Potential JV / Partnership Signal. Map potential GP / JV relationship and monitor partnership activity.
- Crescent Communities: score 77, No Clear Capital Flow Signal, Potential JV / Partnership Signal. Map potential GP / JV relationship and monitor partnership activity.

## Tier 1 Firm Watch

- Blackstone: score 88, Capital Inflow, Potential JV / Partnership Signal. Map potential GP / JV relationship and monitor partnership activity.

## California / LA Capital and Developer Watch

- No current signal detected.

## Capital Inflow / Outflow Signals

- Blackstone: score 88, Capital Inflow, Potential JV / Partnership Signal. Map potential GP / JV relationship and monitor partnership activity.

## JV / Partnership Signals

- Blackstone: score 88, Capital Inflow, Potential JV / Partnership Signal. Map potential GP / JV relationship and monitor partnership activity.
- Crescent Communities: score 77, No Clear Capital Flow Signal, Potential JV / Partnership Signal. Map potential GP / JV relationship and monitor partnership activity.

## Competitive Benchmark Signals

- No current signal detected.

## Pricing Discovery Signals

- No current signal detected.

## Relationship Map

| Firm | Market | Source Category | Activity Type | Capital Flow | Relationship Signal | Woomi Implication |
| --- | --- | --- | --- | --- | --- | --- |
| Blackstone | New York | Developer / GP Newsrooms | acquisition; refinancing; JV / partnership; capital raise | Capital Inflow | Potential JV / Partnership Signal | potential JV partnership signal |
| Crescent Communities | Sun Belt | Core Multifamily News | JV / partnership | No Clear Capital Flow Signal | Potential JV / Partnership Signal | potential JV partnership signal |

## Deal / Project Intelligence

Deal and project-level extraction is available in `deal_pipeline_report.md`.
- Refinancing in New York: Unknown / Unknown / fannie mae.
- Construction Financing in Other / Unknown: Unknown / Unknown / cbre.
- General Project Signal in Sun Belt: Unknown / Unknown / berkadia.
- General Project Signal in New York: blackstone / blackstone / Unknown.
- Acquisition in Other / Unknown: Unknown / Unknown / jll.

## Relationship Graph Intelligence

Capital partner, lender, GP, and market edges are available in `relationship_graph_report.md`.
- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village... -> fannie mae: Financing Relationship.
- Blackstone -> blackstone: Capital Flow.
- Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal... -> cbre: Financing Relationship.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl... -> berkadia: Financing Relationship.
- Acquisition - Other / Unknown - Mapletree Pays $100M for 97-Acre Future Logistics Site in Central Jersey -> jll: Financing Relationship.

## High-Scoring GP Watchlist Reference

Emerging GP watchlist rankings are available in `gp_watchlist_report.md`.
- Crescent Communities: 66 (Tier 3 Monitoring GP), Strong partnership signal.
- Blackstone: 58 (Tier 3 Monitoring GP), Strong partnership signal.

## GP Source Expansion Summary

Developer / GP source coverage is available in `gp_source_coverage_report.md`.
Use that report to prioritize missing capital platform, lender, and GP feeds that would strengthen relationship scoring.

## Source Activation Summary

Validated source activation scoring is available in `source_activation_report.md`.
Use that report to separate production-ready institutional feeds from critical manual-review sources.

## Historical Persistence Summary

Institutional memory is available in `historical_memory_report.md`.
Capital-flow memory is available in `capital_flow_report.md`.
Recurring relationship tracking is available in `relationship_persistence_report.md`.

## Opportunity / Distress Radar

Opportunity radar is available in `opportunity_radar_report.md`.
Distress watchlist is available in `distress_watchlist_report.md`.
Canonical deal fingerprints are available in `deal_fingerprint_report.md`.
Opportunity deduplication is available in `opportunity_deduplication_report.md`.
Timing intelligence is available in `timing_intelligence_report.md`.
Market entry window scoring is available in `market_entry_window_report.md`.

## Implications for Woomi / Woomi Global

- JV / partnership signals should be mapped to potential GP relationship targets and compared with Woomi's US entry needs.
- Capital inflow or deployment signals can help benchmark pricing, underwriting assumptions, and market timing.

## Recommended Executive Follow-Up

- Blackstone: Map potential GP / JV relationship and monitor partnership activity
- Crescent Communities: Map potential GP / JV relationship and monitor partnership activity



## Signal Quality / Confidence Summary

- Signals evaluated: 85
- Institutional-grade signals: 4
- High-confidence signals: 14
- Weak/noisy signals: 61
- High-confidence watchlist items: 14
- See `signal_quality_report.md` and `high_confidence_watchlist_report.md` before using signals for executive decisions.

