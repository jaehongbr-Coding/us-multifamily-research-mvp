# LA Persistent Asset Watch Report

Generated: 2026-05-18 16:30:57

- Total LA persistent asset watch items: 65

## Priority LA Asset Watch Items

- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Los Angeles, Unknown Stage, Track repeat project updates.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, Site Acquisition / Site Control, Track repeat project updates.
- Disposition / Exit - California - Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale: Los Angeles, Site Acquisition / Site Control, Track repeat project updates.
- BTR / Build-to-Rent - Sun Belt - NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino: Los Angeles, Delivery / Opening, Track repeat project updates.
- Disposition / Exit - Sun Belt - Institutional Property Advisors Closes Sale and Arranges Financing for Dallas Multifamily...: Los Angeles, Delivery / Opening, Track repeat project updates.
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: Los Angeles, Unknown Stage, Track repeat project updates.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, Refinancing / Recapitalization, Track repeat project updates.
- BTR / Build-to-Rent - Florida - Adam America Real Estate and Stellar Communities Deliver First Homes at Havens at Palm Bay...: Los Angeles, Unknown Stage, Track repeat project updates.

## Koreatown / Wilshire Persistent Assets

- None detected.

## DTLA Persistent Assets

- None detected.

## Hollywood Persistent Assets

- None detected.

## Pasadena Persistent Assets

- None detected.

## Orange County Persistent Assets

- None detected.

## Stalled / Delayed LA Asset Watch

- Construction Financing - Other / Unknown - Cypress Equity Investments gets $170M loan for two Santa Monica projects: Santa Monica, Unknown Stage, Track repeat project updates.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, Site Acquisition / Site Control, Track repeat project updates.
- Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades: Los Angeles, Site Acquisition / Site Control, Track repeat project updates.

## Construction / Delivery Transition Watch

- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Lincoln Heights, Vertical Construction, Track repeat project updates.
- BTR / Build-to-Rent - Sun Belt - NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino: Los Angeles, Delivery / Opening, Track repeat project updates.
- Disposition / Exit - Sun Belt - Institutional Property Advisors Closes Sale and Arranges Financing for Dallas Multifamily...: Los Angeles, Delivery / Opening, Track repeat project updates.

## Recommended Local Follow-up Actions

- Create or refresh a project watch file with sponsor, site, entitlement, financing, and timing notes: Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments.
- Monitor for repeated project updates: Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd..
- Monitor for repeated project updates: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.
- Monitor for repeated project updates: Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave..
- Monitor for repeated project updates: General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd..
- Monitor for repeated project updates: Construction Financing - Other / Unknown - Cypress Equity Investments gets $170M loan for two Santa Monica projects.
- Create or refresh a project watch file with sponsor, site, entitlement, financing, and timing notes: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.
- Create or refresh a project watch file with sponsor, site, entitlement, financing, and timing notes: Disposition / Exit - California - Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale.
