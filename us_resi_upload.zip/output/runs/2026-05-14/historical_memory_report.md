# Historical Memory Report

Generated: 2026-05-14 16:21:11

- Memory rows tracked: 129
- Fastest-rising GP: Blackstone
- Strongest recurring lender: Fannie Mae

## Fastest-Rising GP

- Blackstone (GP / Developer): Persistent, 24 observation(s), importance 60.

## Strongest Recurring Lender

- Fannie Mae (Lender / Debt Provider): Persistent, 24 observation(s), importance 74.
- CBRE (Lender / Debt Provider): Persistent, 24 observation(s), importance 73.
- Berkadia (Lender / Debt Provider): Persistent, 24 observation(s), importance 65.
- JLL (Lender / Debt Provider): Persistent, 24 observation(s), importance 58.

## Recurring California / LA Relationships

- Los Angeles -> California (Relationship Edge): Fading, 22 observation(s), importance 75.
- Los Angeles -> Los Angeles (Relationship Edge): Persistent, 96 observation(s), importance 74.
- Los Angeles -> Los Angeles (Relationship Edge): Persistent, 24 observation(s), importance 74.
- Los Angeles -> California (Relationship Edge): Persistent, 24 observation(s), importance 74.
- Los Angeles -> San Francisco (Relationship Edge): Persistent, 24 observation(s), importance 74.
- Los Angeles -> Southeast (Relationship Edge): Persistent, 24 observation(s), importance 74.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd. (Deal / Project): Persistent, 24 observation(s), importance 73.
- JV / Partnership - California - Early Collaboration, Public-Private Partnerships New Norm For Bay Area Student Housing Dev... (Deal / Project): Fading, 22 observation(s), importance 73.
- Student Housing (Residential Sector): Fading, 22 observation(s), importance 73.
- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena (Deal / Project): Persistent, 24 observation(s), importance 72.

## Persistent BTR / Student / Senior Housing Players

- JV / Partnership - California - Early Collaboration, Public-Private Partnerships New Norm For Bay Area Student Housing Dev... (Deal / Project): Fading, 22 observation(s), importance 73.
- Student Housing (Residential Sector): Fading, 22 observation(s), importance 73.
- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco (Deal / Project): Persistent, 24 observation(s), importance 72.
- Senior Housing (Residential Sector): Persistent, 24 observation(s), importance 58.
- BTR / Single-Family Rental (Residential Sector): Persistent, 19 observation(s), importance 57.
- JV / Partnership - Other / Unknown - Affordable Senior Housing Community Southernside West Set to Break Ground in Greenvillen S... (Deal / Project): Persistent, 24 observation(s), importance 56.
- BTR / Build-to-Rent - National - Trump Pushes House To Pass Housing Bill With BTR Forced-Sale Provision (Deal / Project): Persistent, 24 observation(s), importance 55.
- BTR / Build-to-Rent - Other / Unknown - JV Breaks Ground on South Carolina BTR Community (Deal / Project): Fading, 5 observation(s), importance 48.
- BTR / Single-Family Rental (Residential Sector): Fading, 5 observation(s), importance 48.
- General Project Signal - Texas - Texas State University Project Lands $116M for Construction (Deal / Project): Fading, 5 observation(s), importance 48.

## Recurring Institutional Capital Pairings

- Los Angeles -> California (Relationship Edge): Fading, 22 observation(s), importance 75.
- Los Angeles -> Los Angeles (Relationship Edge): Persistent, 96 observation(s), importance 74.
- Los Angeles -> Los Angeles (Relationship Edge): Persistent, 24 observation(s), importance 74.
- Los Angeles -> California (Relationship Edge): Persistent, 24 observation(s), importance 74.
- Los Angeles -> San Francisco (Relationship Edge): Persistent, 24 observation(s), importance 74.
- Los Angeles -> Southeast (Relationship Edge): Persistent, 24 observation(s), importance 74.
- Fannie Mae -> Fannie Mae (Relationship Edge): Persistent, 24 observation(s), importance 68.
- Berkadia -> Berkadia (Relationship Edge): Persistent, 24 observation(s), importance 67.
- CBRE -> CBRE (Relationship Edge): Persistent, 24 observation(s), importance 67.
- Fannie Mae -> New York (Relationship Edge): Persistent, 24 observation(s), importance 67.

## Strongest Multi-Run Relationships

- Los Angeles -> California (Relationship Edge): Fading, 22 observation(s), importance 75.
- Los Angeles -> Los Angeles (Relationship Edge): Persistent, 96 observation(s), importance 74.
- Los Angeles -> Los Angeles (Relationship Edge): Persistent, 24 observation(s), importance 74.
- Los Angeles -> California (Relationship Edge): Persistent, 24 observation(s), importance 74.
- Los Angeles -> San Francisco (Relationship Edge): Persistent, 24 observation(s), importance 74.
- Los Angeles -> Southeast (Relationship Edge): Persistent, 24 observation(s), importance 74.
- Fannie Mae -> Fannie Mae (Relationship Edge): Persistent, 24 observation(s), importance 68.
- Berkadia -> Berkadia (Relationship Edge): Persistent, 24 observation(s), importance 67.
- CBRE -> CBRE (Relationship Edge): Persistent, 24 observation(s), importance 67.
- Fannie Mae -> New York (Relationship Edge): Persistent, 24 observation(s), importance 67.

## Accelerating Markets

- None detected.

## Fading Markets

- New York (Market / Region): Fading, 17 observation(s), importance 50.
- New York (Market / Region): Fading, 5 observation(s), importance 42.

## Recurring Refinancing Stress Signals

- Fannie Mae (Lender / Debt Provider): Persistent, 24 observation(s), importance 74.
- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village... (Deal / Project): Persistent, 24 observation(s), importance 66.
- Blackstone (GP / Developer): Persistent, 24 observation(s), importance 60.

## Canonical Deal Summary

Capital-flow memory uses deal fingerprints from `deal_fingerprint_report.md` to avoid overstating repeated refinancing coverage.
Opportunity deduplication details are available in `opportunity_deduplication_report.md`.

## Opportunity / Distress Radar

Opportunity radar is available in `opportunity_radar_report.md`.
Distress watchlist is available in `distress_watchlist_report.md`.
Canonical deal fingerprints are available in `deal_fingerprint_report.md`.
Opportunity deduplication is available in `opportunity_deduplication_report.md`.
Timing intelligence is available in `timing_intelligence_report.md`.
Market entry window scoring is available in `market_entry_window_report.md`.
Entitlement intelligence is available in `entitlement_intelligence_report.md`.
LA entitlement watch is available in `la_entitlement_watch_report.md`.
