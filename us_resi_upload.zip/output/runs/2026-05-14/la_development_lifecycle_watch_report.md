# LA Development Lifecycle Watch Report

Generated: 2026-05-14 16:21:12

- Total LA lifecycle watch items: 29

## LA Lifecycle Stage Distribution

- Unknown Stage: 14
- Delivery / Opening: 6
- Site Acquisition / Site Control: 3
- Vertical Construction: 2
- Early Site Signal: 2
- Refinancing / Recapitalization: 1
- Environmental Review / CEQA: 1

## Koreatown / Wilshire Lifecycle Watch

- None detected.

## DTLA Lifecycle Watch

- None detected.

## Hollywood Lifecycle Watch

- None detected.

## Pasadena Lifecycle Watch

- None detected.

## Long Beach Lifecycle Watch

- None detected.

## Orange County Lifecycle Watch

- None detected.

## Inland Empire Lifecycle Watch

- None detected.

## Stalled / Distressed LA Project Watch

- None detected.

## Construction-Ready LA Project Watch

- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Vertical Construction, Monitor only, opportunity 86.
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Vertical Construction, Monitor only, opportunity 80.

## Recommended LA Lifecycle Follow-up Actions

- Monitor lifecycle status for repeated confirmation: JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek....
- Track construction progress and delivery timeline: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.
- Review lender exposure, sponsor stress, and possible JV or rescue-capital angle: Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village....
- Monitor lifecycle status for repeated confirmation: General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve....
- Monitor lifecycle status for repeated confirmation: General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd..
- Monitor lifecycle status for repeated confirmation: General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd..
- Monitor lifecycle status for repeated confirmation: New look for affordable housing at 10304 S. Central Ave. in Watts.
- Track construction progress and delivery timeline: Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.



## Lifecycle Transition Summary

- Lifecycle transitions analyzed: 48
- Newly detected projects: 0
- Forward progression projects: 0
- Possible stalled projects: 0
- LA lifecycle transition watch items: 26
- See `lifecycle_transition_report.md` and `la_lifecycle_transition_watch_report.md` for multi-run project movement and timing signals.




## Persistent Asset Memory Summary

- Raw project references: 344
- Canonical projects: 85
- Duplicate project clusters: 46
- Persistent assets tracked: 85
- LA persistent asset watch items: 51
- See `project_identity_report.md`, `persistent_asset_memory_report.md`, and `la_persistent_asset_watch_report.md` for canonical project tracking.

