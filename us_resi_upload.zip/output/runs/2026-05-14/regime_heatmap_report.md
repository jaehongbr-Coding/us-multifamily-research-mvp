# Regime Heatmap Report

Generated: 2026-05-14 16:21:11

Scores are calibrated with capped weighted components, so final_score is less likely to saturate at 100 unless the supporting signals are very strong.

- Top regime by final_score: Supply Pressure (79)
- Second regime by final_score: Financing Stress (69)

## Full Regime Score Table

| Regime | Raw Score | Normalized Score | Final Score | Strength | Supporting Signals |
| --- | ---: | ---: | ---: | --- | --- |
| Supply Pressure | 119 | 79 | 79 | Strong | Supply Pressure articles: 4; Supply/vacancy/concession signals: 6; Supply matched-keyword articles: 4 |
| Financing Stress | 103 | 69 | 69 | Strong | Financing Risk articles: 8; Financing/cap-rate market signals: 1; Financing matched-keyword articles: 7 |
| Selective Capital Re-entry | 102 | 68 | 68 | Strong | Institutional Flow articles: 6; Deal Size Signal articles: 1; Institutional player mentions: 4 |
| Developer Strategy Shift | 80 | 53 | 53 | Moderate | Developer Strategy articles: 17; Developer matched-keyword articles: 3; Must Read articles: 17 |
| Policy / Entitlement Watch | 62 | 41 | 41 | Moderate | Regulation Risk articles: 2; Policy matched-keyword articles: 4; California / Los Angeles focus count: 6 |
| Construction Cost Pressure | 4 | 3 | 3 | Not Detected | Cost Control articles: 0; Construction Cost Signal articles: 0; Cost matched-keyword articles: 1 |
| Stable Monitoring Environment | 0 | 0 | 0 | Not Detected | Highest active regime score before stable adjustment: 119; Monitor articles: 2 |

## Regime Interpretations

- Supply Pressure (Strong): Supply, starts, deliveries, lease-up, vacancy, or concession signals are visible.
- Financing Stress (Strong): Debt, rates, refinancing, or cap-rate pressure is visible enough to affect underwriting attention.
- Selective Capital Re-entry (Strong): Institutional flow, deal-size, or major-player activity suggests capital-market re-engagement.
- Developer Strategy Shift (Moderate): Developer behavior, product strategy, adaptive reuse, BTR, modular, or operating-model signals are visible.
- Policy / Entitlement Watch (Moderate): Policy, zoning, permitting, entitlement, rent-control, or housing-production signals require monitoring.
- Construction Cost Pressure (Not Detected): Construction Cost Pressure is not a meaningful signal in this run.
- Stable Monitoring Environment (Not Detected): Stable Monitoring Environment is not a meaningful signal in this run.

## Implications for Woomi / Woomi Global

- Financing Stress is strong, so use conservative underwriting and tighter debt-sensitivity assumptions.
- Selective Capital Re-entry is strong, so track pricing discovery, GP partners, and institutional capital counterparties.
- Supply Pressure is strong, so monitor lease-up, vacancy, concessions, starts, and delivery timing.
