# 한국어 경영진 대시보드 브리핑

- 생성 시각: 2026-05-14 16:21:11
- 참고 원문 파일: `executive_dashboard_brief.md`
- 번역 방식: 규칙 기반 한국어 요약. OpenAI/GPT API는 호출하지 않음.

## 오늘의 핵심 브리핑

경영진 대시보드 기준 핵심 신호 33건을 요약했습니다. 본 리포트는 유료 API 없이 규칙 기반으로 작성되며, 우미 / 우미글로벌의 미국 주거 개발 전략 관점에서 우선순위와 후속 조치를 빠르게 확인하기 위한 자료입니다.
- 저장 기사 수: 43
- 높은 신뢰도 신호: 14
- 대시보드 카드: 33
- 최우선 카드: Berkadia
- 추천 경영진 포커스: Review Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village... and related high-confidence project signals.

## 우선 확인 Top 5

- Berkadia: Berkadia, 멀티패밀리, 점수 100 (Capital Flow; Track capital flow pattern and related relationships)
- Blackstone: Blackstone, 일반 주거, 점수 100 (Capital Flow; Track capital flow pattern and related relationships)
- Blackstone: Blackstone, 일반 주거, 점수 100 (Capital Flow; Track capital flow pattern and related relationships)
- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Los Angeles, 어포더블 하우징, 점수 100 (LA Asset Watch; Review parcel clue, entitlement path, sponsor, and comparable sites)
- General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts: Los Angeles, 어포더블 하우징, 점수 100 (LA Asset Watch; Review parcel clue, entitlement path, sponsor, and comparable sites)

## LA / California Watch

- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Los Angeles, 어포더블 하우징, 점수 100 (Review parcel clue, entitlement path, sponsor, and comparable sites)
- General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts: Los Angeles, 어포더블 하우징, 점수 100 (Review parcel clue, entitlement path, sponsor, and comparable sites)
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Los Angeles, 아파트, 점수 100 (Review parcel clue, entitlement path, sponsor, and comparable sites)
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, 어포더블 하우징, 점수 100 (Review parcel clue, entitlement path, sponsor, and comparable sites)
- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: Los Angeles, 어포더블 하우징, 점수 99 (Review parcel clue, entitlement path, sponsor, and comparable sites)

## GP / Capital Partner Watch

- Berkadia: Berkadia, 멀티패밀리, 점수 100 (Track capital flow pattern and related relationships)
- Blackstone: Blackstone, 일반 주거, 점수 100 (Track capital flow pattern and related relationships)
- Blackstone: Blackstone, 일반 주거, 점수 100 (Track capital flow pattern and related relationships)
- Crescent Communities: Sun Belt, 주거복합, 점수 66 (Track JV and capital partner activity)
- Blackstone: New York, 일반 주거, 점수 58 (Track JV and capital partner activity)

## Opportunity / Distress Watch

- JV / Partnership Gap: Sun Belt, 주거복합, 점수 74 (Map GP, capital partner, and relationship history)
- GP Capability Partnership Opportunity: New York, 일반 주거, 점수 72 (Map GP, capital partner, and relationship history)
- Refinancing Gap: New York, 멀티패밀리, 점수 68 (Track debt stack, maturity, lender, and recapitalization details)
- LA / California Entitlement Opportunity: Los Angeles, 아파트, 점수 66 (Review entitlement, zoning, permitting, and local sponsor context)
- refinancing stress: New York, 멀티패밀리, 점수 66 (Track debt maturity, lender exposure, sponsor stress, and recapitalization options)

## 추천 경영진 액션

- `executive_priority_brief_ko.md`에서 Tier 1 / Tier 2 안건을 확인합니다.
- `high_confidence_watchlist_report_ko.md`에서 노이즈를 제외한 핵심 신호를 확인합니다.
