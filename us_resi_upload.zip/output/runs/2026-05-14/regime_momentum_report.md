# Regime Momentum Report

Generated: 2026-05-14 16:21:11

- Top regime by final_score: Supply Pressure (79)
- Second regime by final_score: Financing Stress (69)
- Dominant regime spread: 10

## Momentum Summary

| Regime | Previous Score | Latest Score | Change | Momentum |
| --- | ---: | ---: | ---: | --- |
| Supply Pressure | 79 | 79 | 0 | Stable |
| Financing Stress | 69 | 69 | 0 | Stable |
| Selective Capital Re-entry | 68 | 68 | 0 | Stable |
| Developer Strategy Shift | 53 | 53 | 0 | Stable |
| Policy / Entitlement Watch | 41 | 41 | 0 | Stable |
| Construction Cost Pressure | 3 | 3 | 0 | Stable |
| Stable Monitoring Environment | 0 | 0 | 0 | Stable |

## Concentration Interpretation

- The current regime picture is more concentrated because the top score is clearly ahead.

## Implications for Woomi / Woomi Global

- No regime is accelerating sharply, but strong current scores still deserve monitoring: Supply Pressure, Financing Stress, Selective Capital Re-entry.
