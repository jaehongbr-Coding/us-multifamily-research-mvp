# Narrative Severity Report

Generated: 2026-05-18 16:30:54

- Top severity regime: Selective Capital Re-entry (100)
- Top conviction regime: Selective Capital Re-entry (100)

## Severity And Conviction Table

| Regime | Severity | Conviction | Urgency | Risk / Opportunity |
| --- | ---: | ---: | --- | --- |
| Selective Capital Re-entry | 100 | 100 | Immediate Attention | Opportunity / Pricing Signal |
| Financing Stress | 100 | 86 | Immediate Attention | Risk |
| Supply Pressure | 100 | 86 | Immediate Attention | Risk |
| Developer Strategy Shift | 91 | 92 | Immediate Attention | Opportunity / Capability Signal |
| Policy / Entitlement Watch | 60 | 58 | Review This Week | Risk / Opportunity |
| Construction Cost Pressure | 2 | 4 | Background | Risk |

## Key Evidence

- Selective Capital Re-entry: supporting articles: 14; high-priority supporting articles: 13; supporting articles with extracted numbers: 10; momentum: Stable; Institutional Flow articles: 13; Deal Size Signal articles: 1; Institutional player mentions: 6
- Financing Stress: supporting articles: 12; high-priority supporting articles: 12; supporting articles with extracted numbers: 9; momentum: Stable; Financing Risk articles: 9; Financing/cap-rate market signals: 3; Financing matched-keyword articles: 11
- Supply Pressure: supporting articles: 14; high-priority supporting articles: 13; supporting articles with extracted numbers: 9; momentum: Stable; Supply Pressure articles: 5; Supply/vacancy/concession signals: 10; Supply matched-keyword articles: 6
- Developer Strategy Shift: supporting articles: 20; high-priority supporting articles: 20; supporting articles with extracted numbers: 11; momentum: Stable; Developer Strategy articles: 20; Developer matched-keyword articles: 8; Must Read articles: 22
- Policy / Entitlement Watch: supporting articles: 4; high-priority supporting articles: 4; supporting articles with extracted numbers: 3; momentum: Stable; Regulation Risk articles: 2; Policy matched-keyword articles: 4; California / Los Angeles focus count: 10
- Construction Cost Pressure: supporting articles: 0; high-priority supporting articles: 0; supporting articles with extracted numbers: 0; momentum: Stable; Cost Control articles: 0; Construction Cost Signal articles: 0; Cost matched-keyword articles: 0

## Implications for Woomi / Woomi Global

- Immediate Attention: track pricing discovery, acquisitions, GP partners, and institutional capital re-entry.
- Immediate Attention: tighten debt assumptions, refinancing sensitivity, and exit-cap underwriting.
- Immediate Attention: watch lease-up, vacancy, concessions, and starts before assuming rent-growth durability.

## Recommended Management Attention Items

### Immediate Attention

- Selective Capital Re-entry: severity 100, conviction 100.
- Financing Stress: severity 100, conviction 86.
- Supply Pressure: severity 100, conviction 86.
- Developer Strategy Shift: severity 91, conviction 92.

### Review This Week

- Policy / Entitlement Watch: severity 60, conviction 58.
