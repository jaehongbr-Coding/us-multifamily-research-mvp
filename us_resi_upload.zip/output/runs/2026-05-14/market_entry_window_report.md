# Market Entry Window Report

Generated: 2026-05-14 16:21:11

## Top Market Entry Windows

- New York: score 76, Selective Entry Window, posture: Monitor refinancing and distress pipeline.
- Sun Belt: score 69, Selective Entry Window, posture: Monitor refinancing and distress pipeline.
- Los Angeles: score 61, Early Signal / Prepare, posture: Track entitlement / permitting pipeline.
- National / Other: score 58, Early Signal / Prepare, posture: Monitor refinancing and distress pipeline.
- California: score 54, Early Signal / Prepare, posture: Track entitlement / permitting pipeline.
- Texas: score 29, Not Attractive Now, posture: Monitor only.
- Florida: score 9, Not Attractive Now, posture: Monitor only.
- Seattle: score 8, Not Attractive Now, posture: Monitor only.

## LA / California Entry Window

- Los Angeles: score 61, Early Signal / Prepare, posture: Track entitlement / permitting pipeline.
- California: score 54, Early Signal / Prepare, posture: Track entitlement / permitting pipeline.

## Sun Belt Entry Window

- Sun Belt: score 69, Selective Entry Window, posture: Monitor refinancing and distress pipeline.
- Texas: score 29, Not Attractive Now, posture: Monitor only.
- Florida: score 9, Not Attractive Now, posture: Monitor only.

## New York / Refinancing Stress Window

- New York: score 76, Selective Entry Window, posture: Monitor refinancing and distress pipeline.

## Entitlement / LA Watch Summary

Developer-grade entitlement detail is available in `entitlement_intelligence_report.md`.
LA / California entitlement watch is available in `la_entitlement_watch_report.md`.

## Sector-Specific Entry Implications

- Multifamily and apartment signals remain the core entry lens.
- BTR / SFR, affordable/workforce housing, and office conversion timing should be reviewed when their timing signals appear.

## Recommended Entry Posture By Market

- New York: Monitor refinancing and distress pipeline (Selective Entry Window).
- Sun Belt: Monitor refinancing and distress pipeline (Selective Entry Window).
- Los Angeles: Track entitlement / permitting pipeline (Early Signal / Prepare).
- National / Other: Monitor refinancing and distress pipeline (Early Signal / Prepare).
- California: Track entitlement / permitting pipeline (Early Signal / Prepare).
- Texas: Monitor only (Not Attractive Now).
- Florida: Monitor only (Not Attractive Now).
- Seattle: Monitor only (Not Attractive Now).

## Key Risks and Opportunities

- New York: risks: financing stress and refinancing pressure; opportunities: active opportunity radar signals; possible distress or recapitalization watch; capital-flow or institutional activity signal.
- Sun Belt: risks: limited timing evidence; opportunities: active opportunity radar signals; possible distress or recapitalization watch; capital-flow or institutional activity signal.
- Los Angeles: risks: supply, delivery, lease-up, or concession pressure; entitlement, zoning, permitting, and policy uncertainty; opportunities: active opportunity radar signals; capital-flow or institutional activity signal; core Woomi California / LA strategic relevance.
- National / Other: risks: supply, delivery, lease-up, or concession pressure; opportunities: active opportunity radar signals; possible distress or recapitalization watch.
- California: risks: entitlement, zoning, permitting, and policy uncertainty; opportunities: active opportunity radar signals; capital-flow or institutional activity signal; core Woomi California / LA strategic relevance.

## Executive Summary for Woomi

- Top current market entry window is New York with a Selective Entry Window label and posture: Monitor refinancing and distress pipeline.



## Development Lifecycle Intelligence Summary

- Lifecycle records: 48
- LA lifecycle watch items: 29
- Stage mix: Site Acquisition / Site Control: 5, Vertical Construction: 3, Refinancing / Recapitalization: 4, Unknown Stage: 26, Delivery / Opening: 7
- See `development_lifecycle_report.md` and `la_development_lifecycle_watch_report.md` for project timing, entitlement, permit, construction, delivery, and refinancing stages.




## Lifecycle Transition Summary

- Lifecycle transitions analyzed: 48
- Newly detected projects: 0
- Forward progression projects: 0
- Possible stalled projects: 0
- LA lifecycle transition watch items: 26
- See `lifecycle_transition_report.md` and `la_lifecycle_transition_watch_report.md` for multi-run project movement and timing signals.

