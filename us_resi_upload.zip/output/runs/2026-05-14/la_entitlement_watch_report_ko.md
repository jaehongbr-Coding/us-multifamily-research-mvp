# 한국어 LA / California 인허가 Watch

- 생성 시각: 2026-05-14 16:21:11
- 참고 원문 파일: `la_entitlement_watch_report.md`
- 번역 방식: 규칙 기반 한국어 요약. OpenAI/GPT API는 호출하지 않음.

## LA / California 인허가 Watch

- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Los Angeles, 어포더블 하우징, 점수 65 (Unknown Stage; Track local planning docket, sponsor, submarket, and entitlement precedent)
- HUD trims environmental reviews for multifamily projects: Los Angeles, 멀티패밀리, 점수 52 (Under Review; Review CEQA status, appeal risk, and approval timeline)
- Swedish Investor Selling 1,500-Unit Northern Virginia Portfolio: Los Angeles, 아파트, 점수 49 (Unknown Stage; Compare density bonus / TOC precedent with target-site assumptions)
- Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek in West Nashville.: Los Angeles, 주거복합, 점수 49 (Unknown Stage; Compare density bonus / TOC precedent with target-site assumptions)
- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco: San Francisco, 시니어 하우징, 점수 49 (Unknown Stage; Track local planning docket, sponsor, submarket, and entitlement precedent)
- Crypto rewards eye renters who want to save for a down payment: Los Angeles, 일반 주거, 점수 35 (Unknown Stage; Compare density bonus / TOC precedent with target-site assumptions)

## Density Bonus / TOC

- Swedish Investor Selling 1,500-Unit Northern Virginia Portfolio: 전국, 아파트, 점수 48 (Density incentive)
- Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek in West Nashville.: Sun Belt, 주거복합, 점수 48 (Density incentive)
- Crypto rewards eye renters who want to save for a down payment: Texas, 일반 주거, 점수 38 (Density incentive)

## CEQA / Environmental Review

- HUD trims environmental reviews for multifamily projects: 기타 / 미확인, 멀티패밀리, 점수 65 (CEQA risk)

## Planning / Permit Signals

- 해당 신호 없음
