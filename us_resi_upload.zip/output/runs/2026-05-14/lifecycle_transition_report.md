# Lifecycle Transition Report

Generated: 2026-05-14 16:21:12

- Total lifecycle transitions analyzed: 48
- Newly detected projects: 0
- Forward progression projects: 0
- Possible stalled projects: 0
- Reappearing projects: 0

## Strongest Progression Signals

- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: Delivery / Opening -> Delivery / Opening, Mature / Operating, progression_score 78.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Delivery / Opening -> Delivery / Opening, Mature / Operating, progression_score 78.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Vertical Construction -> Vertical Construction, Same Stage Persistence, progression_score 78.
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Vertical Construction -> Vertical Construction, Same Stage Persistence, progression_score 78.
- Entitlement / Permitting - Other / Unknown - Completion nears for mixed-use building at 3557 S. Motor Ave. in Palms: Delivery / Opening -> Delivery / Opening, Mature / Operating, progression_score 77.
- Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Delivery / Opening -> Delivery / Opening, Mature / Operating, progression_score 77.
- Completion nears for mixed-use building at 3557 S. Motor Ave. in Palms: Delivery / Opening -> Delivery / Opening, Mature / Operating, progression_score 69.
- Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: Delivery / Opening -> Delivery / Opening, Mature / Operating, progression_score 69.
- Development Start - National - Apartment Construction Starts Plummet To 15-Year Low: Vertical Construction -> Vertical Construction, Same Stage Persistence, progression_score 68.
- General Project Signal - Other / Unknown - Multifamily Absorption Rate Remains Below 50%: Delivery / Opening -> Delivery / Opening, Mature / Operating, progression_score 65.

## Highest Stall Risk Signals

- HUD trims environmental reviews for multifamily projects: Environmental Review / CEQA -> Environmental Review / CEQA, Same Stage Persistence, stall_risk_score 64.
- New look for affordable housing at 10304 S. Central Ave. in Watts: Site Acquisition / Site Control -> Site Acquisition / Site Control, Same Stage Persistence, stall_risk_score 38.
- General Project Signal - New York - Stagg Group Files Plans for 68 Apartments in Astoria: Early Site Signal -> Early Site Signal, Same Stage Persistence, stall_risk_score 38.
- Stagg Group Files Plans for 68 Apartments in Astoria: Early Site Signal -> Early Site Signal, Same Stage Persistence, stall_risk_score 38.
- Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek in West Nashville.: Site Acquisition / Site Control -> Site Acquisition / Site Control, Same Stage Persistence, stall_risk_score 37.
- Mapletree Pays $100M for 97-Acre Future Logistics Site in Central Jersey: Site Acquisition / Site Control -> Site Acquisition / Site Control, Same Stage Persistence, stall_risk_score 37.
- Acquisition - Other / Unknown - Mapletree Pays $100M for 97-Acre Future Logistics Site in Central Jersey: Site Acquisition / Site Control -> Site Acquisition / Site Control, Same Stage Persistence, stall_risk_score 37.
- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: Site Acquisition / Site Control -> Site Acquisition / Site Control, Same Stage Persistence, stall_risk_score 36.
- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Unknown Stage -> Unknown Stage, Unknown Transition, stall_risk_score 32.
- General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts: Unknown Stage -> Unknown Stage, Unknown Transition, stall_risk_score 32.

## Newly Detected Projects

- None detected.

## Forward Progression Projects

- None detected.

## Possible Stalled Projects

- None detected.

## Reappearing Projects

- None detected.

## Refinancing / Recap Timing Transitions

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Refinancing / Recapitalization -> Refinancing / Recapitalization, Same Stage Persistence, stall_risk_score 30.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: Refinancing / Recapitalization -> Refinancing / Recapitalization, Same Stage Persistence, stall_risk_score 30.
- Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal...: Refinancing / Recapitalization -> Refinancing / Recapitalization, Same Stage Persistence, stall_risk_score 30.
- CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Caldwell New Jersey: Refinancing / Recapitalization -> Refinancing / Recapitalization, Same Stage Persistence, stall_risk_score 29.

## Construction Start Transitions

- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Vertical Construction -> Vertical Construction, Same Stage Persistence, progression_score 78.
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Vertical Construction -> Vertical Construction, Same Stage Persistence, progression_score 78.
- Development Start - National - Apartment Construction Starts Plummet To 15-Year Low: Vertical Construction -> Vertical Construction, Same Stage Persistence, progression_score 68.

## Implications for Woomi / Woomi Global

- Lifecycle transitions help separate one-time project mentions from projects that are actually moving through approval, permit, construction, delivery, or refinancing stages.
- Forward movement can inform timing for GP conversations, underwriting updates, and market-entry readiness.
- Stall or conflicting signals should be checked before treating a project as executable pipeline.

## Recommended Transition Follow-up Actions

- Use as delivery, lease-up, and underwriting benchmark: General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd..
- Use as delivery, lease-up, and underwriting benchmark: General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd..
- Monitor for another run to confirm lifecycle direction: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.
- Monitor for another run to confirm lifecycle direction: Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.
- Use as delivery, lease-up, and underwriting benchmark: Entitlement / Permitting - Other / Unknown - Completion nears for mixed-use building at 3557 S. Motor Ave. in Palms.
- Use as delivery, lease-up, and underwriting benchmark: Onni Group plans twin 67-story towers at 5700 Wilshire Blvd..
- Use as delivery, lease-up, and underwriting benchmark: Completion nears for mixed-use building at 3557 S. Motor Ave. in Palms.
- Use as delivery, lease-up, and underwriting benchmark: Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd..



## Persistent Asset Memory Summary

- Raw project references: 344
- Canonical projects: 85
- Duplicate project clusters: 46
- Persistent assets tracked: 85
- LA persistent asset watch items: 51
- See `project_identity_report.md`, `persistent_asset_memory_report.md`, and `la_persistent_asset_watch_report.md` for canonical project tracking.




## Signal Quality / Confidence Summary

- Signals evaluated: 85
- Institutional-grade signals: 4
- High-confidence signals: 14
- Weak/noisy signals: 61
- High-confidence watchlist items: 14
- See `signal_quality_report.md` and `high_confidence_watchlist_report.md` before using signals for executive decisions.

