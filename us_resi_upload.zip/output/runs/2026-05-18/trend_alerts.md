# Trend Alerts

Generated: 2026-05-18 16:30:57

- Latest run timestamp: 2026-05-18 16:30:54
- Previous run timestamp: 2026-05-18 16:09:30

## Trend Metrics

| Metric | Latest | Previous | Change | Percentage Change | Alert |
| --- | ---: | ---: | ---: | ---: | --- |
| Total article volume | 53 | 56 | -3 | -5.4% | Stable |
| High-priority article volume | 30 | 30 | 0 | 0.0% | Stable |
| Market-signal article volume | 23 | 23 | 0 | 0.0% | Stable |
| Strategy-briefing article volume | 31 | 31 | 0 | 0.0% | Stable |

## Interpretation for Strategy Team

- All monitored volumes are stable, so the market signal environment appears stable in this run.
