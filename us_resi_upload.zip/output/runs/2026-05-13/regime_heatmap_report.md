# Regime Heatmap Report

Generated: 2026-05-13 17:23:17

Scores are calibrated with capped weighted components, so final_score is less likely to saturate at 100 unless the supporting signals are very strong.

- Top regime by final_score: Selective Capital Re-entry (89)
- Second regime by final_score: Financing Stress (75)

## Full Regime Score Table

| Regime | Raw Score | Normalized Score | Final Score | Strength | Supporting Signals |
| --- | ---: | ---: | ---: | --- | --- |
| Selective Capital Re-entry | 134 | 89 | 89 | Very Strong | Institutional Flow articles: 8; Deal Size Signal articles: 7; Institutional player mentions: 4 |
| Financing Stress | 112 | 75 | 75 | Strong | Financing Risk articles: 7; Financing/cap-rate market signals: 2; Financing matched-keyword articles: 7 |
| Supply Pressure | 76 | 51 | 51 | Moderate | Supply Pressure articles: 2; Supply/vacancy/concession signals: 4; Supply matched-keyword articles: 2 |
| Developer Strategy Shift | 72 | 48 | 48 | Moderate | Developer Strategy articles: 11; Developer matched-keyword articles: 1; Must Read articles: 10 |
| Policy / Entitlement Watch | 7 | 5 | 5 | Not Detected | Regulation Risk articles: 0; Policy matched-keyword articles: 1; California / Los Angeles focus count: 1 |
| Construction Cost Pressure | 4 | 3 | 3 | Not Detected | Cost Control articles: 0; Construction Cost Signal articles: 0; Cost matched-keyword articles: 1 |
| Stable Monitoring Environment | 0 | 0 | 0 | Not Detected | Highest active regime score before stable adjustment: 134; Monitor articles: 3 |

## Regime Interpretations

- Selective Capital Re-entry (Very Strong): Institutional flow, deal-size, or major-player activity suggests capital-market re-engagement.
- Financing Stress (Strong): Debt, rates, refinancing, or cap-rate pressure is visible enough to affect underwriting attention.
- Supply Pressure (Moderate): Supply, starts, deliveries, lease-up, vacancy, or concession signals are visible.
- Developer Strategy Shift (Moderate): Developer behavior, product strategy, adaptive reuse, BTR, modular, or operating-model signals are visible.
- Policy / Entitlement Watch (Not Detected): Policy / Entitlement Watch is not a meaningful signal in this run.
- Construction Cost Pressure (Not Detected): Construction Cost Pressure is not a meaningful signal in this run.
- Stable Monitoring Environment (Not Detected): Stable Monitoring Environment is not a meaningful signal in this run.

## Implications for Woomi / Woomi Global

- Financing Stress is strong, so use conservative underwriting and tighter debt-sensitivity assumptions.
- Selective Capital Re-entry is strong, so track pricing discovery, GP partners, and institutional capital counterparties.
