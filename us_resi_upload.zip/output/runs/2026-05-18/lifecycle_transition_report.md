# Lifecycle Transition Report

Generated: 2026-05-18 16:30:57

- Total lifecycle transitions analyzed: 54
- Newly detected projects: 0
- Forward progression projects: 0
- Possible stalled projects: 0
- Reappearing projects: 0

## Strongest Progression Signals

- Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles: Delivery / Opening -> Delivery / Opening, Mature / Operating, progression_score 78.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Delivery / Opening -> Delivery / Opening, Mature / Operating, progression_score 78.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Vertical Construction -> Vertical Construction, Same Stage Persistence, progression_score 78.
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Vertical Construction -> Vertical Construction, Same Stage Persistence, progression_score 78.
- Development Start - Los Angeles - The Broad's $100M expansion tops out in DTLA: Vertical Construction -> Vertical Construction, Same Stage Persistence, progression_score 78.
- Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Delivery / Opening -> Delivery / Opening, Mature / Operating, progression_score 77.
- Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles: Delivery / Opening -> Delivery / Opening, Mature / Operating, progression_score 76.
- BTR / Build-to-Rent - Sun Belt - NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino: Delivery / Opening -> Delivery / Opening, Mature / Operating, progression_score 76.
- Disposition / Exit - Sun Belt - Institutional Property Advisors Closes Sale and Arranges Financing for Dallas Multifamily...: Delivery / Opening -> Delivery / Opening, Mature / Operating, progression_score 75.
- NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino: Delivery / Opening -> Delivery / Opening, Mature / Operating, progression_score 75.

## Highest Stall Risk Signals

- Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades: Site Acquisition / Site Control -> Site Acquisition / Site Control, Same Stage Persistence, stall_risk_score 41.
- Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave.: Site Acquisition / Site Control -> Site Acquisition / Site Control, Same Stage Persistence, stall_risk_score 38.
- Disposition / Exit - California - Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale: Site Acquisition / Site Control -> Site Acquisition / Site Control, Same Stage Persistence, stall_risk_score 38.
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: Early Site Signal -> Early Site Signal, Same Stage Persistence, stall_risk_score 38.
- Guardian Acquires 332-Unit Ladd Tower Apartment Building in Downtown Portland: Site Acquisition / Site Control -> Site Acquisition / Site Control, Same Stage Persistence, stall_risk_score 38.
- 96 apartments + retail proposed at 8871 W. Venice Blvd.: Early Site Signal -> Early Site Signal, Same Stage Persistence, stall_risk_score 38.
- Acquisition - Other / Unknown - Guardian Acquires 332-Unit Ladd Tower Apartment Building in Downtown Portland: Site Acquisition / Site Control -> Site Acquisition / Site Control, Same Stage Persistence, stall_risk_score 38.
- General Project Signal - California - Metro partners with developer on plans for housing at G Line's Balboa Station: Early Site Signal -> Early Site Signal, Same Stage Persistence, stall_risk_score 38.
- General Project Signal - Los Angeles - Taylor Yard wetland takes shape, General Hospital update, and more: Site Acquisition / Site Control -> Site Acquisition / Site Control, Same Stage Persistence, stall_risk_score 38.
- Metro partners with developer on plans for housing at G Line's Balboa Station: Early Site Signal -> Early Site Signal, Same Stage Persistence, stall_risk_score 38.

## Newly Detected Projects

- None detected.

## Forward Progression Projects

- None detected.

## Possible Stalled Projects

- None detected.

## Reappearing Projects

- None detected.

## Refinancing / Recap Timing Transitions

- Cypress Equity Investments gets $170M loan for two Santa Monica projects: Refinancing / Recapitalization -> Refinancing / Recapitalization, Same Stage Persistence, stall_risk_score 29.

## Construction Start Transitions

- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Vertical Construction -> Vertical Construction, Same Stage Persistence, progression_score 78.
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Vertical Construction -> Vertical Construction, Same Stage Persistence, progression_score 78.
- Development Start - Los Angeles - The Broad's $100M expansion tops out in DTLA: Vertical Construction -> Vertical Construction, Same Stage Persistence, progression_score 78.
- Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee: Vertical Construction -> Vertical Construction, Same Stage Persistence, progression_score 71.

## Implications for Woomi / Woomi Global

- Lifecycle transitions help separate one-time project mentions from projects that are actually moving through approval, permit, construction, delivery, or refinancing stages.
- Forward movement can inform timing for GP conversations, underwriting updates, and market-entry readiness.
- Stall or conflicting signals should be checked before treating a project as executable pipeline.

## Recommended Transition Follow-up Actions

- Use as delivery, lease-up, and underwriting benchmark: Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles.
- Use as delivery, lease-up, and underwriting benchmark: General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd..
- Monitor for another run to confirm lifecycle direction: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.
- Monitor for another run to confirm lifecycle direction: Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.
- Monitor for another run to confirm lifecycle direction: Development Start - Los Angeles - The Broad's $100M expansion tops out in DTLA.
- Use as delivery, lease-up, and underwriting benchmark: Onni Group plans twin 67-story towers at 5700 Wilshire Blvd..
- Use as delivery, lease-up, and underwriting benchmark: Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles.
- Use as delivery, lease-up, and underwriting benchmark: BTR / Build-to-Rent - Sun Belt - NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino.



## Persistent Asset Memory Summary

- Raw project references: 405
- Canonical projects: 100
- Duplicate project clusters: 55
- Persistent assets tracked: 100
- LA persistent asset watch items: 65
- See `project_identity_report.md`, `persistent_asset_memory_report.md`, and `la_persistent_asset_watch_report.md` for canonical project tracking.




## Signal Quality / Confidence Summary

- Signals evaluated: 100
- Institutional-grade signals: 7
- High-confidence signals: 19
- Weak/noisy signals: 72
- High-confidence watchlist items: 19
- See `signal_quality_report.md` and `high_confidence_watchlist_report.md` before using signals for executive decisions.

