# Regime Transition Report

Generated: 2026-05-13 17:23:17

## Summary

- Current primary regime: Selective Capital Re-entry
- Previous primary regime: Selective Capital Re-entry
- Regime changed: No
- Consecutive runs in current regime: 9
- Confidence direction: stable
- Market signals direction: stable
- Transition label: Persistent Regime

## Recent Regime History

| Run Timestamp | Primary Regime | Secondary Regime | Confidence | Market Signals | Top Strategic Angle | Top Market Focus | Top Market Signal |
| --- | --- | --- | --- | ---: | --- | --- | --- |
| 2026-05-13 16:12:36 | Selective Capital Re-entry | Financing Stress | High | 15 | Financing Risk | Other / Unknown | Deal Size Signal |
| 2026-05-13 16:43:20 | Selective Capital Re-entry | Financing Stress | High | 15 | Financing Risk | Other / Unknown | Deal Size Signal |
| 2026-05-13 17:03:20 | Selective Capital Re-entry | Financing Stress | High | 15 | Financing Risk | Other / Unknown | Deal Size Signal |
| 2026-05-13 17:19:56 | Selective Capital Re-entry | Financing Stress | High | 15 | Financing Risk | Other / Unknown | Deal Size Signal |
| 2026-05-13 17:23:17 | Selective Capital Re-entry | Developer Strategy Shift | High | 17 | Developer Strategy | Other / Unknown | Deal Size Signal |

## Strategy Interpretation

- Selective Capital Re-entry persistence may indicate pricing discovery and renewed capital engagement by institutional players.
- Market-signal volume is stable compared with the previous run.
