# LLM Prompt Quality Report

Generated: 2026-05-14 16:21:11

- Total prompts reviewed: 27
- Average prompt quality score: 87.6
- Excellent prompts: 16
- Good prompts: 11
- Needs Improvement prompts: 0
- Poor prompts: 0

## Top 5 Strongest Prompts

- 98 (Excellent): Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village in Central Islip New York
- 98 (Excellent): Apartment Construction Starts Plummet To 15-Year Low
- 98 (Excellent): Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.
- 98 (Excellent): Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights
- 98 (Excellent): Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.

## Top 5 Weakest Prompts

- 74 (Good): Marcus & Millichap Arranges Sale of 64-Unit Multifamily Property Waterview Apartments in Lawrenceburg Indiana - Missing: missing extracted numbers; missing market focus; missing market signal
- 74 (Good): Best Year for Missing Middle Construction Since 2007 - Missing: missing extracted numbers; missing market focus; missing market signal
- 74 (Good): Missing Middle Weakness - Missing: missing extracted numbers; missing market focus; missing market signal
- 74 (Good): Affordable Senior Housing Community Southernside West Set to Break Ground in Greenvillen South Carolina - Missing: missing extracted numbers; missing market focus; missing market signal
- 74 (Good): Shorter Apartment Construction Time in 2024 - Missing: missing extracted numbers; missing market focus; missing market signal

## Common Missing Context Issues

- missing market signal: 13
- missing market focus: 12
- missing extracted numbers: 10
