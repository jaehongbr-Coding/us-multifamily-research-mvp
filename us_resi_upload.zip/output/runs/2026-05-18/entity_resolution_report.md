# Entity Resolution Report

Generated: 2026-05-18 16:30:55

- Total raw entities reviewed: 115
- Total canonical entities created: 36
- Possible duplicate entity groups: 5
- Weak matches needing review: 74
- Unknown entities needing review: 4

## Top Canonical Firms

- Unknown: 106 occurrence(s)
- JLL: 10 occurrence(s)
- Blackstone: 8 occurrence(s)
- Quarterra: 7 occurrence(s)
- Alliance Residential: 6 occurrence(s)
- CBRE: 2 occurrence(s)
- cushman: 2 occurrence(s)

## Top Canonical Markets

- Los Angeles: 45 occurrence(s)
- Sun Belt: 34 occurrence(s)
- Other / Unknown: 33 occurrence(s)
- Unknown: 16 occurrence(s)
- California: 14 occurrence(s)
- National: 13 occurrence(s)
- New York: 7 occurrence(s)
- Florida: 5 occurrence(s)
- Houston: 2 occurrence(s)
- Southeast: 2 occurrence(s)

## Possible Duplicate Entities

- Blackstone: Blackstone, General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve..., blackstone
- California: California, Southern California
- JLL: Acquisition - Los Angeles - JLL Arranges Sale of 365,774 SF Industrial Portfolio Near Los Angeles Across Two Separate..., Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC..., jll
- Los Angeles: Acquisition - National - TruCore Industrial Acquires 71,552 SF Single-Tenant Property in Peoria, Illinois, Acquisition - Other / Unknown - Guardian Acquires 332-Unit Ladd Tower Apartment Building in Downtown Portland, BTR / Build-to-Rent - Florida - Adam America Real Estate and Stellar Communities Deliver First Homes at Havens at Palm Bay..., BTR / Build-to-Rent - Los Angeles - Core Spaces Secures $1.64B Fundraise for Student Housing Development, Investment, BTR / Build-to-Rent - Sun Belt - NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino, Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades, Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles, Development Start - Los Angeles - The Broad's $100M expansion tops out in DTLA, Disposition / Exit - California - Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale, Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments, Disposition / Exit - Sun Belt - Institutional Property Advisors Brokers Multifamily Asset Sale in Suburban Dallas, Disposition / Exit - Sun Belt - Institutional Property Advisors Closes Sale and Arranges Financing for Dallas Multifamily..., Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd., Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave., General Project Signal - California - Metro partners with developer on plans for housing at G Line's Balboa Station, General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd., General Project Signal - Los Angeles - Taylor Yard wetland takes shape, General Hospital update, and more, General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights, L.A., La County, Los Angeles
- Sun Belt: Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee, Acquisition - Sun Belt - Outrigger Industrial Sells 1 MSF Building at Generation Park in Northeast Houston, Austin, Dallas, JV / Partnership - Sun Belt - CFAM, RPM Living Acquire 380-Unit Waterfront Multifamily Community in North Miami, Miami, Nashville, Phoenix, Sun Belt

## Weak Matches Needing Manual Review

- Acquisition - National - Core Spaces Closes $1.6B Student Housing Fund -> Acquisition - National - Core Spaces Closes $1.6B Student Housing Fund (40, relationship_graph.csv)
- Acquisition - Other / Unknown - Chozick Realty Arranges $3M Sale of Student Housing Building in Mansfield, Connecticut -> Acquisition - Other / Unknown - Chozick Realty Arranges $3M Sale of Student Housing Building in Mansfield, Connecticut (40, relationship_graph.csv)
- Acquisition - Other / Unknown - Colliers Brokers Sale of 321,000 SF Office Building in Kansas City -> Acquisition - Other / Unknown - Colliers Brokers Sale of 321,000 SF Office Building in Kansas City (40, relationship_graph.csv)
- Alliance Residential -> Alliance Residential (40, deal_pipeline.csv)
- Alliance Residential -> Alliance Residential (40, gp_intelligence.csv)
- Alliance Residential -> Alliance Residential (40, institutional_relationships.csv)
- Alliance Residential -> Alliance Residential (40, relationship_graph.csv)
- Arizona -> Arizona (40, regional_intelligence.csv)
- BTR / Build-to-Rent - National - Cushman & Wakefield Brokers $26.4M Sale of 108-Home Built-to-Rent Multifamily Community Th... -> BTR / Build-to-Rent - National - Cushman & Wakefield Brokers $26.4M Sale of 108-Home Built-to-Rent Multifamily Community Th... (40, relationship_graph.csv)
- BTR / Build-to-Rent - Other / Unknown - Build-to-rent sale mandate cut from House’s ROAD to Housing bill -> BTR / Build-to-Rent - Other / Unknown - Build-to-rent sale mandate cut from House’s ROAD to Housing bill (40, relationship_graph.csv)
- General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve... -> Blackstone (60, relationship_graph.csv)
- Construction Financing - Other / Unknown - Cypress Equity Investments gets $170M loan for two Santa Monica projects -> Construction Financing - Other / Unknown - Cypress Equity Investments gets $170M loan for two Santa Monica projects (40, relationship_graph.csv)
- Development Start - Other / Unknown - Fourth Quarter 2025 Multifamily Construction Data -> Development Start - Other / Unknown - Fourth Quarter 2025 Multifamily Construction Data (40, relationship_graph.csv)
- Development Start - Other / Unknown - Missing Middle Weakness -> Development Start - Other / Unknown - Missing Middle Weakness (40, relationship_graph.csv)
- Development Start - Other / Unknown - Overall Housing Starts Inch Lower in 2025 -> Development Start - Other / Unknown - Overall Housing Starts Inch Lower in 2025 (40, relationship_graph.csv)

## Relationship Graph Improvement Notes

- Canonical source and target names are now written into relationship_graph.csv.
- Deal rows now include canonical GP/developer, lender, capital partner, and market fields.
- Weak and unknown entities should be reviewed before relying on multi-run network counts.

## Recommended Cleanup Actions

- Add confirmed aliases for repeated weak matches.
- Review unknown lender, capital partner, and project/deal entities.
- Expand the market alias dictionary when new submarkets appear repeatedly.
