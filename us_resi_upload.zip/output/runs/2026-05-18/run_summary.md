# Run Summary

Generated: 2026-05-18 16:30:54

## Quick Counts

- Total articles saved: 53
- High-confidence signals: 19
- Opportunities: 35
- Distress signals: 4
- LA asset watch items: 32
- Dashboard cards: 35
- Pipeline health status: OK

## Key Files To Open First

- `executive_dashboard_brief.md`
- `high_confidence_watchlist_report.md`
- `pipeline_health_report.md`
- `pipeline_manifest.md`

## Top Dashboard Signal

- Alliance Residential (Capital Flow)

## Suggested Next Action

- Open the executive dashboard brief first, then review the high-confidence watchlist.

## Korean Report Reference

- Korean executive reports are available in `korean_reporting_index.md`.
- Start with `executive_dashboard_brief_ko.md` for a Korean executive briefing.

