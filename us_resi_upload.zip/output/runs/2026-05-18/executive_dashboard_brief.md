# Executive Dashboard Brief

Generated: 2026-05-18 16:30:54

## Executive Snapshot

- Total articles reviewed: 53
- High-confidence signals: 19
- Institutional-grade signals: 7
- Opportunities: 35
- Distress signals: 4
- Recommended executive focus: Review Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments and related high-confidence project signals.

## Top 5 Things to Review Today

- Alliance Residential (Capital Flow, Critical): Track capital flow pattern and related relationships.
- Berkadia (Capital Flow, Critical): Track capital flow pattern and related relationships.
- Blackstone (Capital Flow, Critical): Track capital flow pattern and related relationships.
- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments (LA Asset Watch, Critical): Review parcel clue, entitlement path, sponsor, and comparable sites.
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd. (LA Asset Watch, Critical): Review parcel clue, entitlement path, sponsor, and comparable sites.

## Immediate Watch Items

- Alliance Residential: Stable Action: Track capital flow pattern and related relationships.
- Berkadia: Fading Action: Track capital flow pattern and related relationships.
- Blackstone: Stable Action: Track capital flow pattern and related relationships.
- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Track local sponsor activity Action: Review parcel clue, entitlement path, sponsor, and comparable sites.
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: Monitor entitlement path Action: Review parcel clue, entitlement path, sponsor, and comparable sites.

## LA / California Watch

- Blackstone: Stable Action: Track capital flow pattern and related relationships.
- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Track local sponsor activity Action: Review parcel clue, entitlement path, sponsor, and comparable sites.
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: Monitor entitlement path Action: Review parcel clue, entitlement path, sponsor, and comparable sites.
- Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave.: Track site control precedent Action: Review parcel clue, entitlement path, sponsor, and comparable sites.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Monitor only Action: Review parcel clue, entitlement path, sponsor, and comparable sites.

## GP / Capital Partner Watch

- Alliance Residential: Stable Action: Track capital flow pattern and related relationships.
- Berkadia: Fading Action: Track capital flow pattern and related relationships.
- Blackstone: Stable Action: Track capital flow pattern and related relationships.
- Quarterra: Institutional-backed regional expansion Action: Review LA / California development activity.
- Blackstone: Selective residential growth Action: Track JV and capital partner activity.

## Opportunity / Distress Watch

- LA / California Entitlement Opportunity: LA / California Entitlement Opportunity may create a pricing, capital, partnership, or pipeline opening in Los Angeles. Action: Add to executive opportunity review.
- Acquisition Opportunity: Acquisition Opportunity may create a pricing, capital, partnership, or pipeline opening in Sun Belt. Action: Research owner, basis, pricing, and transaction history.
- GP Capability Partnership Opportunity: GP Capability Partnership Opportunity may create a pricing, capital, partnership, or pipeline opening in New York. Action: Map GP, capital partner, and relationship history.
- construction loan gap: Construction Financing Action: Track debt maturity, lender exposure, sponsor stress, and recapitalization options.
- construction loan gap: Construction Financing Action: Track debt maturity, lender exposure, sponsor stress, and recapitalization options.

## Development Lifecycle Watch

- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Track local sponsor activity Action: Review parcel clue, entitlement path, sponsor, and comparable sites.
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: Monitor entitlement path Action: Review parcel clue, entitlement path, sponsor, and comparable sites.
- Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave.: Track site control precedent Action: Review parcel clue, entitlement path, sponsor, and comparable sites.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Monitor only Action: Review parcel clue, entitlement path, sponsor, and comparable sites.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Benchmark density bonus use Action: Review parcel clue, entitlement path, sponsor, and comparable sites.

## Capital Flow Watch

- Alliance Residential: Stable Action: Track capital flow pattern and related relationships.
- Berkadia: Fading Action: Track capital flow pattern and related relationships.
- Blackstone: Stable Action: Track capital flow pattern and related relationships.

## Source Health Notes

- Critical source validation warnings: 21 source(s) failed validation. Action: Review failed critical feeds and manual-review queue.

## Recommended Management Actions

- Track capital flow pattern and related relationships (capital_flow_report.md).
- Track capital flow pattern and related relationships (capital_flow_report.md).
- Track capital flow pattern and related relationships (capital_flow_report.md).
- Review parcel clue, entitlement path, sponsor, and comparable sites (la_asset_watch_report.md).
- Review parcel clue, entitlement path, sponsor, and comparable sites (la_asset_watch_report.md).


## Korean Report Reference

- Korean executive reports are available in `korean_reporting_index.md`.
- Start with `executive_dashboard_brief_ko.md` for a Korean executive briefing.

