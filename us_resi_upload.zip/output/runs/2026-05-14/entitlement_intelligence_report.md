# Entitlement Intelligence Report

Generated: 2026-05-14 16:21:11

- Total entitlement signals detected: 9

## Top Entitlement Opportunities

- Density Bonus / TOC in Los Angeles: Unknown Stage, entitlement_opportunity_score 48. Benchmark density bonus / TOC use and project economics.
- Entitlement Approval in Unknown: Unknown Stage, entitlement_opportunity_score 48. Track construction-ready pipeline and comparable sponsor execution.
- Density Bonus / TOC in Los Angeles: Unknown Stage, entitlement_opportunity_score 48. Benchmark density bonus / TOC use and project economics.
- Entitlement Approval in Los Angeles: Unknown Stage, entitlement_opportunity_score 45. Track local planning filings, approval body, sponsor, and entitlement precedent.
- Density Bonus / TOC in Los Angeles: Unknown Stage, entitlement_opportunity_score 38. Benchmark density bonus / TOC use and project economics.
- Entitlement Approval in San Francisco: Unknown Stage, entitlement_opportunity_score 35. Track local planning filings, approval body, sponsor, and entitlement precedent.
- CEQA / Environmental Review in Los Angeles: Under Review, entitlement_opportunity_score 30. Monitor CEQA timeline, appeals, and environmental review milestones.
- Entitlement Approval in Unknown: Unknown Stage, entitlement_opportunity_score 30. Track construction-ready pipeline and comparable sponsor execution.
- Entitlement Approval in Unknown: Unknown Stage, entitlement_opportunity_score 30. Track construction-ready pipeline and comparable sponsor execution.

## Top Entitlement Risks

- CEQA / Environmental Review in Los Angeles: Under Review, entitlement_risk_score 65. Monitor CEQA timeline, appeals, and environmental review milestones.
- Entitlement Approval in Los Angeles: Unknown Stage, entitlement_risk_score 38. Track local planning filings, approval body, sponsor, and entitlement precedent.
- Density Bonus / TOC in Los Angeles: Unknown Stage, entitlement_risk_score 28. Benchmark density bonus / TOC use and project economics.
- Entitlement Approval in Unknown: Unknown Stage, entitlement_risk_score 28. Track construction-ready pipeline and comparable sponsor execution.
- Density Bonus / TOC in Los Angeles: Unknown Stage, entitlement_risk_score 28. Benchmark density bonus / TOC use and project economics.
- Density Bonus / TOC in Los Angeles: Unknown Stage, entitlement_risk_score 28. Benchmark density bonus / TOC use and project economics.
- Entitlement Approval in San Francisco: Unknown Stage, entitlement_risk_score 28. Track local planning filings, approval body, sponsor, and entitlement precedent.
- Entitlement Approval in Unknown: Unknown Stage, entitlement_risk_score 28. Track construction-ready pipeline and comparable sponsor execution.
- Entitlement Approval in Unknown: Unknown Stage, entitlement_risk_score 28. Track construction-ready pipeline and comparable sponsor execution.

## Planning / Approval Signals

- Entitlement Approval in Unknown: Unknown Stage, entitlement_opportunity_score 48. Track construction-ready pipeline and comparable sponsor execution.
- Entitlement Approval in Los Angeles: Unknown Stage, entitlement_opportunity_score 45. Track local planning filings, approval body, sponsor, and entitlement precedent.
- Entitlement Approval in San Francisco: Unknown Stage, entitlement_opportunity_score 35. Track local planning filings, approval body, sponsor, and entitlement precedent.
- Entitlement Approval in Unknown: Unknown Stage, entitlement_opportunity_score 30. Track construction-ready pipeline and comparable sponsor execution.
- Entitlement Approval in Unknown: Unknown Stage, entitlement_opportunity_score 30. Track construction-ready pipeline and comparable sponsor execution.

## Density Bonus / TOC Signals

- Density Bonus / TOC in Los Angeles: Unknown Stage, entitlement_opportunity_score 48. Benchmark density bonus / TOC use and project economics.
- Density Bonus / TOC in Los Angeles: Unknown Stage, entitlement_opportunity_score 48. Benchmark density bonus / TOC use and project economics.
- Density Bonus / TOC in Los Angeles: Unknown Stage, entitlement_opportunity_score 38. Benchmark density bonus / TOC use and project economics.

## CEQA / Environmental Review Signals

- CEQA / Environmental Review in Los Angeles: Under Review, entitlement_risk_score 65. Monitor CEQA timeline, appeals, and environmental review milestones.

## Affordable Housing Requirement Signals

- Entitlement Approval in Los Angeles: Unknown Stage, entitlement_opportunity_score 45. Track local planning filings, approval body, sponsor, and entitlement precedent.

## Office-to-Residential Conversion Signals

- None detected.

## Implications for Woomi / Woomi Global

- Entitlement intelligence helps track project approval precedent, local policy risk, and construction-ready pipeline timing.
- LA / California signals should feed site strategy, sponsor mapping, and entitlement-risk assumptions.
- Submarket-level site strategy detail is available in `submarket_intelligence_report.md` and `la_submarket_watch_report.md`.

## Recommended Entitlement Follow-up Actions

- Monitor CEQA timeline, appeals, and environmental review milestones: CEQA / Environmental Review in Los Angeles.
- Benchmark density bonus / TOC use and project economics: Density Bonus / TOC in Los Angeles.
- Track construction-ready pipeline and comparable sponsor execution: Entitlement Approval in Unknown.
- Benchmark density bonus / TOC use and project economics: Density Bonus / TOC in Los Angeles.
- Track local planning filings, approval body, sponsor, and entitlement precedent: Entitlement Approval in Los Angeles.
- Benchmark density bonus / TOC use and project economics: Density Bonus / TOC in Los Angeles.
- Track local planning filings, approval body, sponsor, and entitlement precedent: Entitlement Approval in San Francisco.
- Track construction-ready pipeline and comparable sponsor execution: Entitlement Approval in Unknown.



## Development Lifecycle Intelligence Summary

- Lifecycle records: 48
- LA lifecycle watch items: 29
- Stage mix: Site Acquisition / Site Control: 5, Vertical Construction: 3, Refinancing / Recapitalization: 4, Unknown Stage: 26, Delivery / Opening: 7
- See `development_lifecycle_report.md` and `la_development_lifecycle_watch_report.md` for project timing, entitlement, permit, construction, delivery, and refinancing stages.

