# Opportunity Deduplication Report

Generated: 2026-05-18 16:30:55

- Total duplicate clusters: 4
- Opportunities removed via deduplication: 0
- Distress inflation prevented: 0

## Strongest Multi-Source Confirmed Opportunities

- Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles: Los Angeles, 2 related row(s), opportunity score 66, distress score 69.
- Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades: Los Angeles, 2 related row(s), opportunity score 65, distress score 68.
- Cypress Equity Investments gets $170M loan for two Santa Monica projects: Other / Unknown, 2 related row(s), opportunity score 61, distress score 56.
- JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC Phase 1 in Vancouver Washington: Other / Unknown, 2 related row(s), opportunity score 60, distress score 56.

## Repeated Refinancing Stories

- None detected.

## Repeated GP Partnership Stories

- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: New York, 1 related row(s), opportunity score 72, distress score 0.
- CFAM, RPM Living Acquire 380-Unit Waterfront Multifamily Community in North Miami: Sun Belt, 1 related row(s), opportunity score 62, distress score 0.

## California / LA Duplicate Project Tracking

- Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles: Los Angeles, 2 related row(s), opportunity score 66, distress score 69.
- Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades: Los Angeles, 2 related row(s), opportunity score 65, distress score 68.
- Quarterra Seeks Buyers For Almost 4,000 Apartments: Los Angeles, 1 related row(s), opportunity score 91, distress score 0.
- Site prep underway for affordable housing at 4301 S. Vermont Ave.: Los Angeles, 1 related row(s), opportunity score 67, distress score 0.
- Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Los Angeles, 1 related row(s), opportunity score 67, distress score 0.
- 96 apartments + retail proposed at 8871 W. Venice Blvd.: Los Angeles, 1 related row(s), opportunity score 66, distress score 0.
- Core Spaces Secures $1.64B Fundraise for Student Housing Development, Investment: Los Angeles, 1 related row(s), opportunity score 65, distress score 0.
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, 1 related row(s), opportunity score 64, distress score 0.
- Metro partners with developer on plans for housing at G Line's Balboa Station: California, 1 related row(s), opportunity score 63, distress score 0.
- Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale: California, 1 related row(s), opportunity score 63, distress score 0.

## Why This Matters

- Deduplication prevents syndicated or repeated articles from overstating opportunity, distress, GP, and capital-flow signals.
- Multi-source confirmation still raises confidence when different sources point to the same canonical event.
