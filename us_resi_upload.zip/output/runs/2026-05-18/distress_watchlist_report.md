# Distress Watchlist Report

Generated: 2026-05-18 16:30:55

- Total distress signals: 4

## Top Distress Watch Items

- construction loan gap in Los Angeles: Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles, score 69. Track debt maturity, lender exposure, sponsor stress, and recapitalization options.
- construction loan gap in Los Angeles: Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades, score 68. Track debt maturity, lender exposure, sponsor stress, and recapitalization options.
- construction loan gap in Other / Unknown: Construction Financing - Other / Unknown - Cypress Equity Investments gets $170M loan for two Santa Monica projects, score 56. Monitor for repeated distress signals.
- construction loan gap in Other / Unknown: Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC..., score 56. Monitor for repeated distress signals.

## Refinancing Stress Watch

- None detected.

## Construction Financing Gap Watch

- construction loan gap in Los Angeles: Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles, score 69. Track debt maturity, lender exposure, sponsor stress, and recapitalization options.
- construction loan gap in Los Angeles: Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades, score 68. Track debt maturity, lender exposure, sponsor stress, and recapitalization options.
- construction loan gap in Other / Unknown: Construction Financing - Other / Unknown - Cypress Equity Investments gets $170M loan for two Santa Monica projects, score 56. Monitor for repeated distress signals.
- construction loan gap in Other / Unknown: Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC..., score 56. Monitor for repeated distress signals.

## Stalled Project Watch

- None detected.

## Distressed Seller / Sponsor Watch

- None detected.

## Timing / Market Entry Window Summary

Timing intelligence is available in `timing_intelligence_report.md`.
Market entry window scoring is available in `market_entry_window_report.md`.

## Deduplicated Distress Summary

Distress rows are checked against `deal_fingerprint_report.md` and `opportunity_deduplication_report.md`.
This helps avoid counting repeated refinancing or stalled-project coverage as separate distress events.

## Market Concentration of Distress Signals

- Los Angeles: 2 distress signal(s)
- Other / Unknown: 2 distress signal(s)

## Implications for Woomi / Woomi Global

- Distress rows can highlight recapitalization, rescue capital, acquisition basis, or lender pressure themes to monitor.

## Recommended Next Actions

- Track debt maturity, lender exposure, sponsor stress, and recapitalization options: construction loan gap in Los Angeles.
- Track debt maturity, lender exposure, sponsor stress, and recapitalization options: construction loan gap in Los Angeles.
- Monitor for repeated distress signals: construction loan gap in Other / Unknown.
- Monitor for repeated distress signals: construction loan gap in Other / Unknown.



## Development Lifecycle Intelligence Summary

- Lifecycle records: 54
- LA lifecycle watch items: 32
- Stage mix: Unknown Stage: 28, Vertical Construction: 4, Site Acquisition / Site Control: 8, Delivery / Opening: 9, Early Site Signal: 4
- See `development_lifecycle_report.md` and `la_development_lifecycle_watch_report.md` for project timing, entitlement, permit, construction, delivery, and refinancing stages.




## Lifecycle Transition Summary

- Lifecycle transitions analyzed: 54
- Newly detected projects: 0
- Forward progression projects: 0
- Possible stalled projects: 0
- LA lifecycle transition watch items: 30
- See `lifecycle_transition_report.md` and `la_lifecycle_transition_watch_report.md` for multi-run project movement and timing signals.




## Persistent Asset Memory Summary

- Raw project references: 405
- Canonical projects: 100
- Duplicate project clusters: 55
- Persistent assets tracked: 100
- LA persistent asset watch items: 65
- See `project_identity_report.md`, `persistent_asset_memory_report.md`, and `la_persistent_asset_watch_report.md` for canonical project tracking.




## Signal Quality / Confidence Summary

- Signals evaluated: 100
- Institutional-grade signals: 7
- High-confidence signals: 19
- Weak/noisy signals: 72
- High-confidence watchlist items: 19
- See `signal_quality_report.md` and `high_confidence_watchlist_report.md` before using signals for executive decisions.

