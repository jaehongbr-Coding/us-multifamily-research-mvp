# Opportunity Radar Report

Generated: 2026-05-18 16:30:55

- Total opportunities detected: 35

## Top 10 Opportunities

- LA / California Entitlement Opportunity in Los Angeles: Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments, score 91. Add to executive opportunity review.
- Acquisition Opportunity in Sun Belt: Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee, score 76. Research owner, basis, pricing, and transaction history.
- GP Capability Partnership Opportunity in New York: General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve..., score 72. Map GP, capital partner, and relationship history.
- LA / California Entitlement Opportunity in Los Angeles: Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave., score 67. Review entitlement, zoning, permitting, and local sponsor context.
- LA / California Entitlement Opportunity in Los Angeles: General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd., score 67. Review entitlement, zoning, permitting, and local sponsor context.
- Construction Financing Gap in Los Angeles: Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles, score 66. Track debt stack, maturity, lender, and recapitalization details.
- LA / California Entitlement Opportunity in Los Angeles: Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd., score 66. Review entitlement, zoning, permitting, and local sponsor context.
- Construction Financing Gap in Los Angeles: Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades, score 65. Track debt stack, maturity, lender, and recapitalization details.
- LA / California Entitlement Opportunity in Los Angeles: BTR / Build-to-Rent - Los Angeles - Core Spaces Secures $1.64B Fundraise for Student Housing Development, Investment, score 65. Review entitlement, zoning, permitting, and local sponsor context.
- LA / California Entitlement Opportunity in Los Angeles: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights, score 64. Review entitlement, zoning, permitting, and local sponsor context.

## LA / California Opportunities

- LA / California Entitlement Opportunity in Los Angeles: Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments, score 91. Add to executive opportunity review.
- LA / California Entitlement Opportunity in Los Angeles: Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave., score 67. Review entitlement, zoning, permitting, and local sponsor context.
- LA / California Entitlement Opportunity in Los Angeles: General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd., score 67. Review entitlement, zoning, permitting, and local sponsor context.
- Construction Financing Gap in Los Angeles: Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles, score 66. Track debt stack, maturity, lender, and recapitalization details.
- LA / California Entitlement Opportunity in Los Angeles: Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd., score 66. Review entitlement, zoning, permitting, and local sponsor context.
- Construction Financing Gap in Los Angeles: Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades, score 65. Track debt stack, maturity, lender, and recapitalization details.
- LA / California Entitlement Opportunity in Los Angeles: BTR / Build-to-Rent - Los Angeles - Core Spaces Secures $1.64B Fundraise for Student Housing Development, Investment, score 65. Review entitlement, zoning, permitting, and local sponsor context.
- LA / California Entitlement Opportunity in Los Angeles: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights, score 64. Review entitlement, zoning, permitting, and local sponsor context.
- LA / California Entitlement Opportunity in California: General Project Signal - California - Metro partners with developer on plans for housing at G Line's Balboa Station, score 63. Review entitlement, zoning, permitting, and local sponsor context.
- LA / California Entitlement Opportunity in California: Disposition / Exit - California - Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale, score 63. Review entitlement, zoning, permitting, and local sponsor context.

## Acquisition / Recapitalization Opportunities

- Acquisition Opportunity in Sun Belt: Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee, score 76. Research owner, basis, pricing, and transaction history.
- Acquisition Opportunity in Los Angeles: Acquisition - Los Angeles - JLL Arranges Sale of 365,774 SF Industrial Portfolio Near Los Angeles Across Two Separate..., score 62. Research owner, basis, pricing, and transaction history.
- Acquisition Opportunity in Other / Unknown: Acquisition - Other / Unknown - Guardian Acquires 332-Unit Ladd Tower Apartment Building in Downtown Portland, score 60. Research owner, basis, pricing, and transaction history.
- Acquisition Opportunity in Other / Unknown: Acquisition - Other / Unknown - Chozick Realty Arranges $3M Sale of Student Housing Building in Mansfield, Connecticut, score 57. Research owner, basis, pricing, and transaction history.
- Acquisition Opportunity in Sun Belt: Acquisition - Sun Belt - Outrigger Industrial Sells 1 MSF Building at Generation Park in Northeast Houston, score 57. Research owner, basis, pricing, and transaction history.
- Acquisition Opportunity in National: Acquisition - National - Core Spaces Closes $1.6B Student Housing Fund, score 54. Research owner, basis, pricing, and transaction history.
- Acquisition Opportunity in Other / Unknown: Acquisition - Other / Unknown - Colliers Brokers Sale of 321,000 SF Office Building in Kansas City, score 53. Research owner, basis, pricing, and transaction history.
- Acquisition Opportunity in National: Acquisition - National - TruCore Industrial Acquires 71,552 SF Single-Tenant Property in Peoria, Illinois, score 52. Research owner, basis, pricing, and transaction history.

## Distressed / Rescue Capital Opportunities

- None detected.

## BTR / SFR Opportunities

- BTR / SFR Platform Opportunity in National: BTR / Build-to-Rent - National - Cushman & Wakefield Brokers $26.4M Sale of 108-Home Built-to-Rent Multifamily Community Th..., score 59. Monitor for repeated signals.
- Acquisition Opportunity in Sun Belt: Acquisition - Sun Belt - Outrigger Industrial Sells 1 MSF Building at Generation Park in Northeast Houston, score 57. Research owner, basis, pricing, and transaction history.
- BTR / SFR Platform Opportunity in Sun Belt: BTR / Build-to-Rent - Sun Belt - NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino, score 53. Monitor for repeated signals.
- BTR / SFR Platform Opportunity in Florida: BTR / Build-to-Rent - Florida - Adam America Real Estate and Stellar Communities Deliver First Homes at Havens at Palm Bay..., score 52. Monitor for repeated signals.
- BTR / SFR Platform Opportunity in Other / Unknown: BTR / Build-to-Rent - Other / Unknown - Build-to-rent sale mandate cut from House’s ROAD to Housing bill, score 50. Monitor for repeated signals.

## Office-to-Residential Opportunities

- None detected.

## Affordable / Workforce Opportunities

- LA / California Entitlement Opportunity in Los Angeles: Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave., score 67. Review entitlement, zoning, permitting, and local sponsor context.
- LA / California Entitlement Opportunity in Los Angeles: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights, score 64. Review entitlement, zoning, permitting, and local sponsor context.
- LA / California Entitlement Opportunity in California: General Project Signal - California - Metro partners with developer on plans for housing at G Line's Balboa Station, score 63. Review entitlement, zoning, permitting, and local sponsor context.
- Construction Financing Gap in Other / Unknown: Construction Financing - Other / Unknown - Cypress Equity Investments gets $170M loan for two Santa Monica projects, score 61. Track debt stack, maturity, lender, and recapitalization details.

## Potential GP Partnership Opportunities

- GP Capability Partnership Opportunity in New York: General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve..., score 72. Map GP, capital partner, and relationship history.
- JV / Partnership Gap in Sun Belt: JV / Partnership - Sun Belt - CFAM, RPM Living Acquire 380-Unit Waterfront Multifamily Community in North Miami, score 62. Map GP, capital partner, and relationship history.

## Timing / Market Entry Window Summary

Timing intelligence is available in `timing_intelligence_report.md`.
Market entry window scoring is available in `market_entry_window_report.md`.

## Deduplicated Opportunity Summary

Canonical event cleanup is available in `opportunity_deduplication_report.md`.
Deal fingerprints are available in `deal_fingerprint_report.md`.
Opportunity rows use canonical fingerprints so repeated article coverage does not inflate the radar.

## Multi-Source Confirmation Summary

Repeat coverage increases confirmation only when it maps to the same canonical event fingerprint.

## Implications for Woomi / Woomi Global

- Use Immediate and Strategic Opportunity Watch rows as a first-pass agenda for acquisition, recapitalization, JV, and market-entry discussion.
- Cross-check top rows against relationship persistence and capital-flow memory before outreach or underwriting work.

## Recommended Executive Follow-up

- Add to executive opportunity review: LA / California Entitlement Opportunity in Los Angeles.
- Research owner, basis, pricing, and transaction history: Acquisition Opportunity in Sun Belt.
- Map GP, capital partner, and relationship history: GP Capability Partnership Opportunity in New York.
- Review entitlement, zoning, permitting, and local sponsor context: LA / California Entitlement Opportunity in Los Angeles.
- Review entitlement, zoning, permitting, and local sponsor context: LA / California Entitlement Opportunity in Los Angeles.



## Development Lifecycle Intelligence Summary

- Lifecycle records: 54
- LA lifecycle watch items: 32
- Stage mix: Unknown Stage: 28, Vertical Construction: 4, Site Acquisition / Site Control: 8, Delivery / Opening: 9, Early Site Signal: 4
- See `development_lifecycle_report.md` and `la_development_lifecycle_watch_report.md` for project timing, entitlement, permit, construction, delivery, and refinancing stages.




## Lifecycle Transition Summary

- Lifecycle transitions analyzed: 54
- Newly detected projects: 0
- Forward progression projects: 0
- Possible stalled projects: 0
- LA lifecycle transition watch items: 30
- See `lifecycle_transition_report.md` and `la_lifecycle_transition_watch_report.md` for multi-run project movement and timing signals.




## Persistent Asset Memory Summary

- Raw project references: 405
- Canonical projects: 100
- Duplicate project clusters: 55
- Persistent assets tracked: 100
- LA persistent asset watch items: 65
- See `project_identity_report.md`, `persistent_asset_memory_report.md`, and `la_persistent_asset_watch_report.md` for canonical project tracking.




## Signal Quality / Confidence Summary

- Signals evaluated: 100
- Institutional-grade signals: 7
- High-confidence signals: 19
- Weak/noisy signals: 72
- High-confidence watchlist items: 19
- See `signal_quality_report.md` and `high_confidence_watchlist_report.md` before using signals for executive decisions.

