# 한국어 기회 레이더 리포트

- 생성 시각: 2026-05-18 16:30:54
- 참고 원문 파일: `opportunity_radar_report.md`
- 번역 방식: 규칙 기반 한국어 요약. OpenAI/GPT API는 호출하지 않음.

## 주요 기회 신호

- LA / California Entitlement Opportunity: Los Angeles, 아파트, 점수 91 (Immediate Opportunity Watch; Add to executive opportunity review)
- Acquisition Opportunity: Sun Belt, 주거복합, 점수 76 (Strategic Opportunity Watch; Research owner, basis, pricing, and transaction history)
- GP Capability Partnership Opportunity: New York, 일반 주거, 점수 72 (Strategic Opportunity Watch; Map GP, capital partner, and relationship history)
- LA / California Entitlement Opportunity: Los Angeles, 어포더블 하우징, 점수 67 (Strategic Opportunity Watch; Review entitlement, zoning, permitting, and local sponsor context)
- LA / California Entitlement Opportunity: Los Angeles, 아파트, 점수 67 (Strategic Opportunity Watch; Review entitlement, zoning, permitting, and local sponsor context)
- Construction Financing Gap: Los Angeles, 주거복합, 점수 66 (Strategic Opportunity Watch; Track debt stack, maturity, lender, and recapitalization details)
- LA / California Entitlement Opportunity: Los Angeles, 주거복합, 점수 66 (Strategic Opportunity Watch; Review entitlement, zoning, permitting, and local sponsor context)
- Construction Financing Gap: Los Angeles, 일반 주거, 점수 65 (Strategic Opportunity Watch; Track debt stack, maturity, lender, and recapitalization details)
- LA / California Entitlement Opportunity: Los Angeles, 학생주택, 점수 65 (Strategic Opportunity Watch; Review entitlement, zoning, permitting, and local sponsor context)
- LA / California Entitlement Opportunity: Los Angeles, 어포더블 하우징, 점수 64 (Strategic Opportunity Watch; Review entitlement, zoning, permitting, and local sponsor context)

## LA / California 기회

- LA / California Entitlement Opportunity: Los Angeles, 아파트, 점수 91 (Evaluate LA / California entitlement, zoning, or local GP partnership relevance)
- LA / California Entitlement Opportunity: Los Angeles, 어포더블 하우징, 점수 67 (Evaluate LA / California entitlement, zoning, or local GP partnership relevance)
- LA / California Entitlement Opportunity: Los Angeles, 아파트, 점수 67 (Evaluate LA / California entitlement, zoning, or local GP partnership relevance)
- Construction Financing Gap: Los Angeles, 주거복합, 점수 66 (Evaluate LA / California entitlement, zoning, or local GP partnership relevance)
- LA / California Entitlement Opportunity: Los Angeles, 주거복합, 점수 66 (Evaluate LA / California entitlement, zoning, or local GP partnership relevance)

## JV / Partnership Gap

- Blackstone: New York, 일반 주거, 점수 72 (Map possible GP partnership or capability-building relationship)
- Unknown: Sun Belt, 아파트, 점수 62 (Map possible GP partnership or capability-building relationship)

## 추천 후속 조치

- 상위 기회는 관련 GP, 자본 파트너, 프로젝트 단계, 시장 진입 타이밍을 함께 확인합니다.
