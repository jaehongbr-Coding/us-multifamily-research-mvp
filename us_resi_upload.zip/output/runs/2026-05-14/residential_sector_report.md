# Residential Sector Coverage Report

Generated: 2026-05-14 16:21:11

- Active residential sectors: 7

## Sector Coverage Summary

- Apartment: 12 article(s), 11 high-priority, 9 deal/project, Core Strategy Sector.
- Affordable Housing: 8 article(s), 7 high-priority, 7 deal/project, Strategic Expansion Sector.
- Multifamily: 13 article(s), 3 high-priority, 7 deal/project, Core Strategy Sector.
- BTR / Single-Family Rental: 2 article(s), 1 high-priority, 1 deal/project, Strategic Expansion Sector.
- Senior Housing: 2 article(s), 2 high-priority, 2 deal/project, Monitoring Sector.
- Mixed-Use Residential: 1 article(s), 1 high-priority, 1 deal/project, Monitoring Sector.
- General Residential: 5 article(s), 0 high-priority, 4 deal/project, Monitoring Sector.

## Top Residential Sectors By Relevance

- Apartment: Core Strategy Sector, average relevance 83.8, dominant market Other / Unknown.
- Affordable Housing: Strategic Expansion Sector, average relevance 92.6, dominant market Other / Unknown.
- Multifamily: Core Strategy Sector, average relevance 69.8, dominant market Other / Unknown.
- BTR / Single-Family Rental: Strategic Expansion Sector, average relevance 64.0, dominant market National.
- Senior Housing: Monitoring Sector, average relevance 79.5, dominant market Other / Unknown.
- Mixed-Use Residential: Monitoring Sector, average relevance 85.0, dominant market Sun Belt.
- General Residential: Monitoring Sector, average relevance 56.2, dominant market New York.
- Manufactured Housing: Monitoring Sector, average relevance 0, dominant market None detected.

## Multifamily / Apartment

- Apartment: 12 article(s), 9 deal/project signal(s), Core Strategy Sector. Keep in weekly developer strategy review.
- Multifamily: 13 article(s), 7 deal/project signal(s), Core Strategy Sector. Keep in weekly developer strategy review.

## BTR / SFR

- BTR / Single-Family Rental: 2 article(s), 1 deal/project signal(s), Strategic Expansion Sector. Monitor BTR / SFR operators, capital flows, and target markets.

## Student Housing

- Student Housing: 0 article(s), 0 deal/project signal(s), Monitoring Sector. Monitor university-market demand and partnership signals.

## Senior Housing

- Senior Housing: 2 article(s), 2 deal/project signal(s), Monitoring Sector. Monitor senior housing demand and operating model signals.

## Affordable / Workforce Housing

- Affordable Housing: 8 article(s), 7 deal/project signal(s), Strategic Expansion Sector. Add to sector watchlist.
- Workforce Housing: 0 article(s), 0 deal/project signal(s), Monitoring Sector. Add to sector watchlist.

## Office-to-Residential Conversion

- Office-to-Residential Conversion: 0 article(s), 0 deal/project signal(s), Monitoring Sector. Track conversion feasibility, policy support, and construction cost assumptions.

## Sector Implications for Woomi / Woomi Global

- Strategic expansion sectors should be reviewed for product diversification, GP partnerships, and underwriting assumptions.

## Recommended Sector Follow-up Actions

- Apartment: Keep in weekly developer strategy review
- Affordable Housing: Add to sector watchlist
- Multifamily: Keep in weekly developer strategy review
- BTR / Single-Family Rental: Monitor BTR / SFR operators, capital flows, and target markets
- Senior Housing: Monitor senior housing demand and operating model signals
- Mixed-Use Residential: Add to sector watchlist
- General Residential: Add to sector watchlist
- Manufactured Housing: Add to sector watchlist
- Office-to-Residential Conversion: Track conversion feasibility, policy support, and construction cost assumptions
- Student Housing: Monitor university-market demand and partnership signals
- Workforce Housing: Add to sector watchlist
