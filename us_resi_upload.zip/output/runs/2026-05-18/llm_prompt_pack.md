# LLM Prompt Pack for US Multifamily Strategy Analysis

Generated: 2026-05-18 16:30:54

## Instructions

This file prepares prompts for a future GPT-based analysis layer.
The current MVP does not call a paid LLM API.
Copy one prompt at a time into an LLM, or use this file later as input for an API workflow.

Prompt count: 31

## Prompt 1: The Market Data that Matters for the rest of 2026: A Chat with Zillow’s Chief Economist

- Quality score: 82
- Quality label: Good
- Missing context: missing extracted numbers; missing market signal

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: The Market Data that Matters for the rest of 2026: A Chat with Zillow’s Chief Economist
- Source: Multifamily Executive
- URL: https://www.multifamilyexecutive.com/premium/webinar/752676
- Market focus: National
- Strategic angle: Financing Risk; Rent Growth / Demand
- Market signal: No Clear Numeric Signal
- Extracted numbers: None detected
- Strategic implication: Monitor financing conditions because the article includes concession, concessions, construction and no specific number, which may affect construction loans, refinancing risk, and exit cap rates.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 2: Institutional Property Advisors Closes Sale and Arranges Financing for Dallas Multifamily Asset Sylvan Thirty

- Quality score: 82
- Quality label: Good
- Missing context: missing extracted numbers; missing market signal

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Institutional Property Advisors Closes Sale and Arranges Financing for Dallas Multifamily Asset Sylvan Thirty
- Source: Yield PRO
- URL: https://yieldpro.com/2026/05/sylvan-thirty/
- Market focus: Sun Belt
- Strategic angle: Financing Risk; Institutional Flow; Developer Strategy
- Market signal: No Clear Numeric Signal
- Extracted numbers: None detected
- Strategic implication: Monitor financing conditions because the article includes apartment, development, financing and no specific number, which may affect construction loans, refinancing risk, and exit cap rates.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 3: Cushman & Wakefield Brokers $26.4M Sale of 108-Home Built-to-Rent Multifamily Community The Manors at Brookmere in Matteson Illinois

- Quality score: 98
- Quality label: Excellent
- Missing context: None

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Cushman & Wakefield Brokers $26.4M Sale of 108-Home Built-to-Rent Multifamily Community The Manors at Brookmere in Matteson Illinois
- Source: Yield PRO
- URL: https://yieldpro.com/2026/05/the-manors-at-brookmere/
- Market focus: National
- Strategic angle: Institutional Flow; Developer Strategy
- Market signal: Rent Growth Signal
- Extracted numbers: $26.4m; $26.4 million
- Strategic implication: Track rent and vacancy conditions because the article points to demand, occupancy, rent, vacancy, or concession signals in National.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 4: JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC Phase 1 in Vancouver Washington

- Quality score: 82
- Quality label: Good
- Missing context: missing market focus; missing market signal

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC Phase 1 in Vancouver Washington
- Source: Yield PRO
- URL: https://yieldpro.com/2026/05/the-vic-phase-1/
- Market focus: Other / Unknown
- Strategic angle: Financing Risk; Institutional Flow; Developer Strategy
- Market signal: No Clear Numeric Signal
- Extracted numbers: $75m; $75 million
- Strategic implication: Monitor financing conditions because the article includes capital markets, construction, development and $75m, $75 million, which may affect construction loans, refinancing risk, and exit cap rates.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 5: Institutional Property Advisors Brokers Multifamily Asset Sale in Suburban Dallas

- Quality score: 82
- Quality label: Good
- Missing context: missing extracted numbers; missing market signal

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Institutional Property Advisors Brokers Multifamily Asset Sale in Suburban Dallas
- Source: Yield PRO
- URL: https://yieldpro.com/2026/05/alta-firewheel/
- Market focus: Sun Belt
- Strategic angle: Supply Pressure; Institutional Flow
- Market signal: No Clear Numeric Signal
- Extracted numbers: None detected
- Strategic implication: Review this as a supply risk signal because it references new deliveries, starts, pipeline, or permits in Sun Belt.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 6: Quarterra Seeks Buyers For Almost 4,000 Apartments

- Quality score: 98
- Quality label: Excellent
- Missing context: None

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Quarterra Seeks Buyers For Almost 4,000 Apartments
- Source: Bisnow
- URL: https://www.bisnow.com/national/news/multifamily/quarterra-seeks-buyers-for-almost-4000-apartments-134586
- Market focus: Los Angeles
- Strategic angle: Institutional Flow
- Market signal: Supply / Starts Signal
- Extracted numbers: 4,000 apartments; 3,746 units
- Strategic implication: Review this as a supply risk signal because it references new deliveries, starts, pipeline, or permits in Los Angeles.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 7: Core Spaces Secures $1.64B Fundraise for Student Housing Development, Investment

- Quality score: 98
- Quality label: Excellent
- Missing context: None

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Core Spaces Secures $1.64B Fundraise for Student Housing Development, Investment
- Source: Commercial Observer
- URL: https://commercialobserver.com/2026/05/core-spaces-secures-1-64b-fundraise-for-student-housing-development-investment/
- Market focus: Los Angeles
- Strategic angle: Developer Strategy
- Market signal: Rent Growth Signal
- Extracted numbers: $1.64b; $1.64 billion
- Strategic implication: Track rent and vacancy conditions because the article points to demand, occupancy, rent, vacancy, or concession signals in Los Angeles.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 8: 96 apartments + retail proposed at 8871 W. Venice Blvd.

- Quality score: 98
- Quality label: Excellent
- Missing context: None

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: 96 apartments + retail proposed at 8871 W. Venice Blvd.
- Source: Urbanize LA
- URL: https://la.urbanize.city/post/96-apartments-retail-proposed-8871-w-venice-blvd
- Market focus: Los Angeles
- Strategic angle: Regulation Risk; Developer Strategy
- Market signal: Rent Growth Signal
- Extracted numbers: 96 apartments; 15 apartments
- Strategic implication: Track rent and vacancy conditions because the article points to demand, occupancy, rent, vacancy, or concession signals in Los Angeles.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 9: Site prep underway for affordable housing at 4301 S. Vermont Ave.

- Quality score: 98
- Quality label: Excellent
- Missing context: None

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Site prep underway for affordable housing at 4301 S. Vermont Ave.
- Source: Urbanize LA
- URL: https://la.urbanize.city/post/site-prep-underway-affordable-housing-4301-s-vermont-ave
- Market focus: Los Angeles
- Strategic angle: Financing Risk; Regulation Risk; Institutional Flow; Developer Strategy
- Market signal: Supply / Starts Signal
- Extracted numbers: $35
- Strategic implication: Monitor financing conditions because the article includes affordable housing, apartment, apartments and $35, which may affect construction loans, refinancing risk, and exit cap rates.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 10: Cypress Equity Investments gets $170M loan for two Santa Monica projects

- Quality score: 90
- Quality label: Excellent
- Missing context: missing market focus

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Cypress Equity Investments gets $170M loan for two Santa Monica projects
- Source: Urbanize LA
- URL: https://la.urbanize.city/post/cypress-equity-investments-gets-170m-loan-two-santa-monica-projects
- Market focus: Other / Unknown
- Strategic angle: Financing Risk; Developer Strategy
- Market signal: Supply / Starts Signal
- Extracted numbers: $170m; $170; 600 apartments; 320 apartments
- Strategic implication: Monitor financing conditions because the article includes affordable housing, apartment, apartments and $170m, $170, 600 apartments, which may affect construction loans, refinancing risk, and exit cap rates.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 11: Metro partners with developer on plans for housing at G Line's Balboa Station

- Quality score: 98
- Quality label: Excellent
- Missing context: None

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Metro partners with developer on plans for housing at G Line's Balboa Station
- Source: Urbanize LA
- URL: https://la.urbanize.city/post/metro-partners-developer-plans-housing-g-lines-balboa-station
- Market focus: California
- Strategic angle: Developer Strategy
- Market signal: Rent Growth Signal
- Extracted numbers: 321 homes; 10,000 homes
- Strategic implication: Track rent and vacancy conditions because the article points to demand, occupancy, rent, vacancy, or concession signals in California.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 12: Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.

- Quality score: 98
- Quality label: Excellent
- Missing context: None

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.
- Source: Urbanize LA
- URL: https://la.urbanize.city/post/onni-group-plans-twin-67-story-towers-5700-wilshire-blvd
- Market focus: Los Angeles
- Strategic angle: Financing Risk; Rent Growth / Demand; Developer Strategy
- Market signal: Supply / Starts Signal
- Extracted numbers: $630 million; 197 apartments
- Strategic implication: Monitor financing conditions because the article includes apartment, apartments, concession and $630 million, 197 apartments, which may affect construction loans, refinancing risk, and exit cap rates.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 13: Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights

- Quality score: 98
- Quality label: Excellent
- Missing context: None

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights
- Source: Urbanize LA
- URL: https://la.urbanize.city/post/wood-framing-takes-shape-affordable-housing-1321-n-mission-rd-lincoln-heights
- Market focus: Los Angeles
- Strategic angle: Developer Strategy
- Market signal: Rent Growth Signal
- Extracted numbers: 150 homes; 885 homes
- Strategic implication: Track rent and vacancy conditions because the article points to demand, occupancy, rent, vacancy, or concession signals in Los Angeles.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 14: Guardian Acquires 332-Unit Ladd Tower Apartment Building in Downtown Portland

- Quality score: 90
- Quality label: Excellent
- Missing context: missing market focus

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Guardian Acquires 332-Unit Ladd Tower Apartment Building in Downtown Portland
- Source: REBusiness Online
- URL: https://rebusinessonline.com/guardian-acquires-332-unit-ladd-tower-apartment-building-in-downtown-portland/
- Market focus: Other / Unknown
- Strategic angle: Financing Risk; Institutional Flow
- Market signal: Financing Cost Signal
- Extracted numbers: 332 apartments
- Strategic implication: Monitor financing conditions because the article includes acquisition, apartment, apartments and 332 apartments, which may affect construction loans, refinancing risk, and exit cap rates.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 15: Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee

- Quality score: 82
- Quality label: Good
- Missing context: missing extracted numbers; missing market signal

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee
- Source: REBusiness Online
- URL: https://rebusinessonline.com/alliance-residential-to-develop-312-unit-apartment-community-in-mt-juliet-tennessee/
- Market focus: Sun Belt
- Strategic angle: Institutional Flow; Developer Strategy
- Market signal: No Clear Numeric Signal
- Extracted numbers: None detected
- Strategic implication: Track this as institutional capital flow because it mentions major capital players, portfolio transactions, deal size, or cap-rate signals.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 16: Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles

- Quality score: 98
- Quality label: Excellent
- Missing context: None

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles
- Source: Yield PRO
- URL: https://yieldpro.com/2026/05/habitat-residences-3/
- Market focus: Los Angeles
- Strategic angle: Financing Risk; Developer Strategy
- Market signal: Financing Cost Signal
- Extracted numbers: $160 million
- Strategic implication: Monitor financing conditions because the article includes construction, debt, development and $160 million, which may affect construction loans, refinancing risk, and exit cap rates.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 17: CFAM, RPM Living Acquire 380-Unit Waterfront Multifamily Community in North Miami

- Quality score: 98
- Quality label: Excellent
- Missing context: None

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: CFAM, RPM Living Acquire 380-Unit Waterfront Multifamily Community in North Miami
- Source: REBusiness Online
- URL: https://rebusinessonline.com/cfam-rpm-living-acquire-380-unit-waterfront-multifamily-community-in-north-miami/
- Market focus: Sun Belt
- Strategic angle: Institutional Flow
- Market signal: Supply / Starts Signal
- Extracted numbers: $151 million; 288 apartments
- Strategic implication: Review this as a supply risk signal because it references new deliveries, starts, pipeline, or permits in Sun Belt.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 18: Multifamily CMBS maturities jumped to 7.71% in April: Trepp

- Quality score: 90
- Quality label: Excellent
- Missing context: missing market focus

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Multifamily CMBS maturities jumped to 7.71% in April: Trepp
- Source: Multifamily Dive
- URL: https://www.multifamilydive.com/news/multifamily-maturities-cmbs-debt-distress/820012/
- Market focus: Other / Unknown
- Strategic angle: Financing Risk; Institutional Flow
- Market signal: Financing Cost Signal
- Extracted numbers: 7.71%; 60%; 56 basis points
- Strategic implication: Monitor financing conditions because the article includes apartment, cmbs, debt and 7.71%, 60%, 56 basis points, which may affect construction loans, refinancing risk, and exit cap rates.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 19: Chozick Realty Arranges $3M Sale of Student Housing Building in Mansfield, Connecticut

- Quality score: 90
- Quality label: Excellent
- Missing context: missing market focus

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Chozick Realty Arranges $3M Sale of Student Housing Building in Mansfield, Connecticut
- Source: REBusiness Online
- URL: https://rebusinessonline.com/chozick-realty-arranges-3m-sale-of-student-housing-building-in-mansfield-connecticut/
- Market focus: Other / Unknown
- Strategic angle: Rent Growth / Demand; Institutional Flow
- Market signal: Vacancy Signal
- Extracted numbers: $3m; $3 million
- Strategic implication: Track rent and vacancy conditions because the article points to demand, occupancy, rent, vacancy, or concession signals in Other / Unknown.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 20: Best Year for Missing Middle Construction Since 2007

- Quality score: 74
- Quality label: Good
- Missing context: missing extracted numbers; missing market focus; missing market signal

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Best Year for Missing Middle Construction Since 2007
- Source: NAHB Eye on Housing - Multifamily
- URL: https://eyeonhousing.org/2026/03/best-year-for-missing-middle-construction-since-2007/
- Market focus: Other / Unknown
- Strategic angle: Supply Pressure; Developer Strategy
- Market signal: No Clear Numeric Signal
- Extracted numbers: None detected
- Strategic implication: Review this as a supply risk signal because it references new deliveries, starts, pipeline, or permits in Other / Unknown.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 21: Missing Middle Weakness

- Quality score: 74
- Quality label: Good
- Missing context: missing extracted numbers; missing market focus; missing market signal

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Missing Middle Weakness
- Source: NAHB Eye on Housing - Multifamily
- URL: https://eyeonhousing.org/2026/01/missing-middle-weakness/
- Market focus: Other / Unknown
- Strategic angle: Supply Pressure; Developer Strategy
- Market signal: No Clear Numeric Signal
- Extracted numbers: None detected
- Strategic implication: Review this as a supply risk signal because it references new deliveries, starts, pipeline, or permits in Other / Unknown.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 22: Aventon Breaks Ground on 270-Unit Residential Development in Tampa

- Quality score: 82
- Quality label: Good
- Missing context: missing extracted numbers; missing market signal

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Aventon Breaks Ground on 270-Unit Residential Development in Tampa
- Source: REBusiness Online
- URL: https://rebusinessonline.com/aventon-breaks-ground-on-270-unit-residential-development-in-tampa/
- Market focus: Sun Belt
- Strategic angle: Developer Strategy
- Market signal: No Clear Numeric Signal
- Extracted numbers: None detected
- Strategic implication: Review for developer strategy because the article may inform site selection, product type, adaptive reuse, build-to-rent, or market entry.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 23: The coasts shine for the multifamily REITs

- Quality score: 82
- Quality label: Good
- Missing context: missing extracted numbers; missing market signal

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: The coasts shine for the multifamily REITs
- Source: Multifamily Dive
- URL: https://www.multifamilydive.com/news/reits-earnings-west-coast-apartments-supply/820266/
- Market focus: California
- Strategic angle: Developer Strategy
- Market signal: No Clear Numeric Signal
- Extracted numbers: None detected
- Strategic implication: Review for developer strategy because the article may inform site selection, product type, adaptive reuse, build-to-rent, or market entry.
- Woomi relevance: Medium relevance to market monitoring

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 24: Multifamily Absorption Rate Remains Below 50%

- Quality score: 90
- Quality label: Excellent
- Missing context: missing market focus

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Multifamily Absorption Rate Remains Below 50%
- Source: NAHB Eye on Housing - Multifamily
- URL: https://eyeonhousing.org/2026/03/multifamily-absorption-rate-remains-below-50/
- Market focus: Other / Unknown
- Strategic angle: Rent Growth / Demand
- Market signal: Supply / Starts Signal
- Extracted numbers: 50%
- Strategic implication: Review this as a supply risk signal because it references new deliveries, starts, pipeline, or permits in Other / Unknown.
- Woomi relevance: Medium relevance to market monitoring

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 25: Bradford Allen Welcomes First Residents to Arbor House Apartments in Arlington Heights Illinois

- Quality score: 82
- Quality label: Good
- Missing context: missing extracted numbers; missing market signal

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Bradford Allen Welcomes First Residents to Arbor House Apartments in Arlington Heights Illinois
- Source: Yield PRO
- URL: https://yieldpro.com/2026/05/arbor-house-3/
- Market focus: Southeast
- Strategic angle: Developer Strategy
- Market signal: No Clear Numeric Signal
- Extracted numbers: None detected
- Strategic implication: Review for developer strategy because the article may inform site selection, product type, adaptive reuse, build-to-rent, or market entry.
- Woomi relevance: Medium relevance to market monitoring

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 26: Shorter Apartment Construction Time in 2024

- Quality score: 74
- Quality label: Good
- Missing context: missing extracted numbers; missing market focus; missing market signal

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Shorter Apartment Construction Time in 2024
- Source: NAHB Eye on Housing - Multifamily
- URL: https://eyeonhousing.org/2025/10/shorter-apartment-construction-time-in-2024/
- Market focus: Other / Unknown
- Strategic angle: Developer Strategy
- Market signal: No Clear Numeric Signal
- Extracted numbers: None detected
- Strategic implication: Review for developer strategy because the article may inform site selection, product type, adaptive reuse, build-to-rent, or market entry.
- Woomi relevance: Medium relevance to market monitoring

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 27: Centralization Associated with Occupancy Uplift

- Quality score: 90
- Quality label: Excellent
- Missing context: missing market focus

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Centralization Associated with Occupancy Uplift
- Source: Multifamily Executive
- URL: https://www.multifamilyexecutive.com/resource/centralization-associated-occupancy-uplift
- Market focus: Other / Unknown
- Strategic angle: Rent Growth / Demand
- Market signal: Vacancy Signal
- Extracted numbers: 1.2%; 2%
- Strategic implication: Track rent and vacancy conditions because the article points to demand, occupancy, rent, vacancy, or concession signals in Other / Unknown.
- Woomi relevance: Medium relevance to market monitoring

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 28: Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale

- Quality score: 98
- Quality label: Excellent
- Missing context: None

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale
- Source: Yield PRO
- URL: https://yieldpro.com/2026/05/upland-village-green/
- Market focus: California
- Strategic angle: Institutional Flow; Developer Strategy
- Market signal: Deal Size Signal
- Extracted numbers: $48.5m; $48.5 million
- Strategic implication: Track this as institutional capital flow because it mentions major capital players, portfolio transactions, deal size, or cap-rate signals.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 29: SakeBrooklyn to Open 7K-SF Brewery at Property Markets Group’s Society Brooklyn

- Quality score: 82
- Quality label: Good
- Missing context: missing extracted numbers; missing market signal

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: SakeBrooklyn to Open 7K-SF Brewery at Property Markets Group’s Society Brooklyn
- Source: Commercial Observer
- URL: https://commercialobserver.com/2026/05/sakebrooklyn-brewery-lease-society-brooklyn/
- Market focus: New York
- Strategic angle: Developer Strategy
- Market signal: No Clear Numeric Signal
- Extracted numbers: None detected
- Strategic implication: Review for developer strategy because the article may inform site selection, product type, adaptive reuse, build-to-rent, or market entry.
- Woomi relevance: Medium relevance to market monitoring

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 30: Absorption Has Been Slow For DFW's Multifamily Oversupply, But Experts Are Optimistic About The Future

- Quality score: 82
- Quality label: Good
- Missing context: missing extracted numbers; missing market signal

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Absorption Has Been Slow For DFW's Multifamily Oversupply, But Experts Are Optimistic About The Future
- Source: Bisnow
- URL: https://www.bisnow.com/dallas-ft-worth/news/multifamily/absorption-has-been-slow-for-dfws-multifamily-oversupply-but-experts-are-optimistic-for-the-future-134587
- Market focus: Sun Belt
- Strategic angle: Supply Pressure; Rent Growth / Demand
- Market signal: No Clear Numeric Signal
- Extracted numbers: None detected
- Strategic implication: Review this as a supply risk signal because it references new deliveries, starts, pipeline, or permits in Sun Belt.
- Woomi relevance: Medium relevance to market monitoring

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 31: Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America

- Quality score: 98
- Quality label: Excellent
- Missing context: None

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America
- Source: Blackstone Real Estate
- URL: https://www.blackstone.com/news/press/ares-acquires-stake-in-rover-pipeline-from-blackstone-energy-transition-partners-to-serve-growing-energy-demand-centers-across-north-america/
- Market focus: New York
- Strategic angle: Supply Pressure; Rent Growth / Demand; Institutional Flow
- Market signal: Supply / Starts Signal
- Extracted numbers: 32.4%
- Strategic implication: Review this as a supply risk signal because it references new deliveries, starts, pipeline, or permits in New York.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```
