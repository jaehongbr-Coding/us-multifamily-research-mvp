# Pipeline Health Report

Generated: 2026-05-18 16:30:54

## Overall Status

- Overall pipeline status: OK
- Total checks: 137
- OK: 133
- Warning: 0
- Error: 0
- Not checked: 4

## Missing Files

- None

## Missing Columns

- None

## Zero-Row Important Outputs

- None

## Recommended Maintenance Actions

- No immediate maintenance action needed.