# Narrative Severity Report

Generated: 2026-05-14 16:21:11

- Top severity regime: Supply Pressure (100)
- Top conviction regime: Developer Strategy Shift (92)

## Severity And Conviction Table

| Regime | Severity | Conviction | Urgency | Risk / Opportunity |
| --- | ---: | ---: | --- | --- |
| Supply Pressure | 100 | 86 | Immediate Attention | Risk |
| Financing Stress | 99 | 86 | Immediate Attention | Risk |
| Selective Capital Re-entry | 95 | 86 | Immediate Attention | Opportunity / Pricing Signal |
| Developer Strategy Shift | 85 | 92 | Immediate Attention | Opportunity / Capability Signal |
| Policy / Entitlement Watch | 57 | 56 | Monitor | Risk / Opportunity |
| Construction Cost Pressure | 10 | 12 | Background | Risk |

## Key Evidence

- Supply Pressure: supporting articles: 8; high-priority supporting articles: 7; supporting articles with extracted numbers: 6; momentum: Stable; Supply Pressure articles: 4; Supply/vacancy/concession signals: 6; Supply matched-keyword articles: 4
- Financing Stress: supporting articles: 9; high-priority supporting articles: 9; supporting articles with extracted numbers: 6; momentum: Stable; Financing Risk articles: 8; Financing/cap-rate market signals: 1; Financing matched-keyword articles: 7
- Selective Capital Re-entry: supporting articles: 8; high-priority supporting articles: 6; supporting articles with extracted numbers: 5; momentum: Stable; Institutional Flow articles: 6; Deal Size Signal articles: 1; Institutional player mentions: 4
- Developer Strategy Shift: supporting articles: 17; high-priority supporting articles: 16; supporting articles with extracted numbers: 11; momentum: Stable; Developer Strategy articles: 17; Developer matched-keyword articles: 3; Must Read articles: 17
- Policy / Entitlement Watch: supporting articles: 4; high-priority supporting articles: 4; supporting articles with extracted numbers: 2; momentum: Stable; Regulation Risk articles: 2; Policy matched-keyword articles: 4; California / Los Angeles focus count: 6
- Construction Cost Pressure: supporting articles: 1; high-priority supporting articles: 1; supporting articles with extracted numbers: 1; momentum: Stable; Cost Control articles: 0; Construction Cost Signal articles: 0; Cost matched-keyword articles: 1

## Implications for Woomi / Woomi Global

- Immediate Attention: watch lease-up, vacancy, concessions, and starts before assuming rent-growth durability.
- Immediate Attention: tighten debt assumptions, refinancing sensitivity, and exit-cap underwriting.
- Immediate Attention: track pricing discovery, acquisitions, GP partners, and institutional capital re-entry.

## Recommended Management Attention Items

### Immediate Attention

- Supply Pressure: severity 100, conviction 86.
- Financing Stress: severity 99, conviction 86.
- Selective Capital Re-entry: severity 95, conviction 86.
- Developer Strategy Shift: severity 85, conviction 92.

### Monitor

- Policy / Entitlement Watch: severity 57, conviction 56.
