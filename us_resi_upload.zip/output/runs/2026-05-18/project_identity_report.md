# Project Identity Resolution Report

Generated: 2026-05-18 16:30:57

- Total raw project references: 405
- Total canonical projects: 100
- Duplicate project clusters: 55
- High-confidence project identities: 405
- Low-confidence identities needing review: 0
- LA / California project references: 241

## Top Repeated Projects

- Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC...: 51 occurrence(s), confidence 80.
- Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC...: 51 occurrence(s), confidence 80.
- Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC...: 51 occurrence(s), confidence 80.
- Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC...: 51 occurrence(s), confidence 80.
- Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC...: 51 occurrence(s), confidence 80.
- Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC...: 51 occurrence(s), confidence 80.
- Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC...: 51 occurrence(s), confidence 80.
- Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC...: 51 occurrence(s), confidence 80.
- Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC...: 51 occurrence(s), confidence 80.
- Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC...: 51 occurrence(s), confidence 80.

## Low-Confidence Identities Needing Review

- No low-confidence identities detected.

## Identity Cleanup Recommendations

- Review low-confidence rows before using them as hard project matches.
- Add known project aliases and address variants when the same LA project appears under multiple titles.
- Use canonical_project_id in lifecycle, opportunity, and relationship review to avoid duplicate project inflation.
