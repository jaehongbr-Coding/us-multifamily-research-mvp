# Developer Network & Relationship Graph Report

Generated: 2026-05-18 16:30:55

- Total relationship edges: 58
- Most connected developer / GP: Quarterra (4 edge(s))
- Most connected lender / debt provider: jll (5 edge(s))
- Most connected market: Los Angeles (11 edge(s))
- Strongest relationship edge: Quarterra -> jll
- Highest Woomi relevance edge: JV / Partnership - Sun Belt - CFAM, RPM Living Acquire 380-Unit Waterfront Multifamily Community in North Miami -> Miami

## Top 10 Relationship Edges

- Quarterra -> jll: Financing Relationship, Los Angeles, score 100. Track GP relationship history.
- Quarterra -> Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Disposition / Seller, Los Angeles, score 84. Track GP relationship history.
- Quarterra -> Los Angeles: Disposition / Seller, Los Angeles, score 84. Track GP relationship history.
- Quarterra -> Southern California: Disposition / Seller, Los Angeles, score 84. Track GP relationship history.
- Alliance Residential -> Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee: Acquisition / Buyer, Sun Belt, score 72. Track GP relationship history.
- Alliance Residential -> Nashville: Acquisition / Buyer, Sun Belt, score 72. Track GP relationship history.
- Alliance Residential -> Sun Belt: Acquisition / Buyer, Sun Belt, score 72. Track GP relationship history.
- Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades -> jll: Financing Relationship, Los Angeles, score 72. Monitor lender activity.
- Blackstone -> blackstone: Capital Flow, New York, score 71. Track GP relationship history.
- Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles -> Los Angeles: Financing Relationship, Los Angeles, score 70. Track LA / California activity.

## Developer / GP Relationship Map

- Quarterra -> jll: Financing Relationship, Los Angeles, score 100. Track GP relationship history.
- Quarterra -> Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Disposition / Seller, Los Angeles, score 84. Track GP relationship history.
- Quarterra -> Los Angeles: Disposition / Seller, Los Angeles, score 84. Track GP relationship history.
- Quarterra -> Southern California: Disposition / Seller, Los Angeles, score 84. Track GP relationship history.
- Alliance Residential -> Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee: Acquisition / Buyer, Sun Belt, score 72. Track GP relationship history.
- Alliance Residential -> Nashville: Acquisition / Buyer, Sun Belt, score 72. Track GP relationship history.
- Alliance Residential -> Sun Belt: Acquisition / Buyer, Sun Belt, score 72. Track GP relationship history.
- Blackstone -> blackstone: Capital Flow, New York, score 71. Track GP relationship history.
- Blackstone -> General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve...: Pricing / Valuation Signal, New York, score 59. Track GP relationship history.
- Blackstone -> New York: Market Expansion, New York, score 57. Track GP relationship history.

## Lender / Debt Provider Relationship Map

- Quarterra -> jll: Financing Relationship, Los Angeles, score 100. Track GP relationship history.
- Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades -> jll: Financing Relationship, Los Angeles, score 72. Monitor lender activity.
- Acquisition - Los Angeles - JLL Arranges Sale of 365,774 SF Industrial Portfolio Near Los Angeles Across Two Separate... -> jll: Financing Relationship, Los Angeles, score 65. Monitor lender activity.
- Acquisition - Other / Unknown - Guardian Acquires 332-Unit Ladd Tower Apartment Building in Downtown Portland -> cbre: Financing Relationship, Other / Unknown, score 65. Monitor lender activity.
- Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC... -> jll: Financing Relationship, Other / Unknown, score 65. Monitor lender activity.
- BTR / Build-to-Rent - National - Cushman & Wakefield Brokers $26.4M Sale of 108-Home Built-to-Rent Multifamily Community Th... -> cushman: Financing Relationship, National, score 64. Monitor lender activity.
- Acquisition - Sun Belt - Outrigger Industrial Sells 1 MSF Building at Generation Park in Northeast Houston -> jll: Financing Relationship, Sun Belt, score 55. Monitor lender activity.

## Capital Partner / Institutional Flow Map

- Blackstone -> blackstone: Capital Flow, New York, score 71. Track GP relationship history.

## Market Relationship Map

- Quarterra -> Los Angeles: Disposition / Seller, Los Angeles, score 84. Track GP relationship history.
- Quarterra -> Southern California: Disposition / Seller, Los Angeles, score 84. Track GP relationship history.
- Alliance Residential -> Nashville: Acquisition / Buyer, Sun Belt, score 72. Track GP relationship history.
- Alliance Residential -> Sun Belt: Acquisition / Buyer, Sun Belt, score 72. Track GP relationship history.
- Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles -> Los Angeles: Financing Relationship, Los Angeles, score 70. Track LA / California activity.
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd. -> L.A.: Entitlement / Permitting, Los Angeles, score 66. Track LA / California activity.
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd. -> Los Angeles: Entitlement / Permitting, Los Angeles, score 66. Track LA / California activity.
- Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave. -> Los Angeles: Entitlement / Permitting, Los Angeles, score 66. Track LA / California activity.
- Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades -> Los Angeles: Financing Relationship, Los Angeles, score 64. Track LA / California activity.
- Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades -> Southern California: Financing Relationship, Los Angeles, score 64. Track LA / California activity.

## California / LA Relationship Signals

- Quarterra -> jll: Financing Relationship, Los Angeles, score 100. Track GP relationship history.
- Quarterra -> Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Disposition / Seller, Los Angeles, score 84. Track GP relationship history.
- Quarterra -> Los Angeles: Disposition / Seller, Los Angeles, score 84. Track GP relationship history.
- Quarterra -> Southern California: Disposition / Seller, Los Angeles, score 84. Track GP relationship history.
- Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades -> jll: Financing Relationship, Los Angeles, score 72. Monitor lender activity.
- Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles -> Los Angeles: Financing Relationship, Los Angeles, score 70. Track LA / California activity.
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd. -> L.A.: Entitlement / Permitting, Los Angeles, score 66. Track LA / California activity.
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd. -> Los Angeles: Entitlement / Permitting, Los Angeles, score 66. Track LA / California activity.
- Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave. -> Los Angeles: Entitlement / Permitting, Los Angeles, score 66. Track LA / California activity.
- Acquisition - Los Angeles - JLL Arranges Sale of 365,774 SF Industrial Portfolio Near Los Angeles Across Two Separate... -> jll: Financing Relationship, Los Angeles, score 65. Monitor lender activity.

## Potential Woomi Partnership Signals

- JV / Partnership - Sun Belt - CFAM, RPM Living Acquire 380-Unit Waterfront Multifamily Community in North Miami -> Miami: JV / Partnership, Sun Belt, score 63. Review potential JV relevance.
- JV / Partnership - Sun Belt - CFAM, RPM Living Acquire 380-Unit Waterfront Multifamily Community in North Miami -> Sun Belt: JV / Partnership, Sun Belt, score 63. Review potential JV relevance.

## Canonical Relationship Map

| Source | Target | Relationship | Confidence |
| --- | --- | --- | ---: |
| Quarterra | JLL | Financing Relationship | 40 |
| Quarterra | Los Angeles | Disposition / Seller | 40 |
| Quarterra | Los Angeles | Disposition / Seller | 40 |
| Quarterra | California | Disposition / Seller | 40 |
| Alliance Residential | Sun Belt | Acquisition / Buyer | 40 |
| Alliance Residential | Sun Belt | Acquisition / Buyer | 40 |
| Alliance Residential | Sun Belt | Acquisition / Buyer | 40 |
| Los Angeles | JLL | Financing Relationship | 60 |
| Blackstone | Blackstone | Capital Flow | 75 |
| Los Angeles | Los Angeles | Financing Relationship | 60 |

## Multi-Source Confirmation Summary

Canonical deal fingerprints are available in `deal_fingerprint_report.md`.
Relationship repeat strength uses unique canonical deal/event counts instead of raw article volume.

## Emerging GP Watchlist Reference

Ranked GP watchlist signals are available in `gp_watchlist_report.md`.
- Quarterra: 75 (Tier 2 High Potential GP), Capital market and pricing discovery reference.
- Blackstone: 58 (Tier 3 Monitoring GP), Potential GP partnership candidate.
- Alliance Residential: 47 (Emerging Watchlist), Capital market and pricing discovery reference.

## GP Source Expansion Summary

Developer / GP source coverage is available in `gp_source_coverage_report.md`.
Better GP, lender, and capital platform feeds should improve relationship graph quality over time.

## Source Activation Summary

Validated source activation scoring is available in `source_activation_report.md`.
Use that report to prioritize source fixes that should improve relationship edge quality.

## Historical Persistence Summary

Recurring relationship tracking is available in `relationship_persistence_report.md`.
Capital-flow memory is available in `capital_flow_report.md`.
Longitudinal memory is available in `historical_memory_report.md`.

## Recommended Executive Follow-Up

- Track GP relationship history: Quarterra -> jll (Financing Relationship).
- Track GP relationship history: Quarterra -> Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments (Disposition / Seller).
- Track GP relationship history: Quarterra -> Los Angeles (Disposition / Seller).
- Track GP relationship history: Quarterra -> Southern California (Disposition / Seller).
- Track GP relationship history: Alliance Residential -> Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee (Acquisition / Buyer).
- Track GP relationship history: Alliance Residential -> Nashville (Acquisition / Buyer).
- Track GP relationship history: Alliance Residential -> Sun Belt (Acquisition / Buyer).
- Monitor lender activity: Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades -> jll (Financing Relationship).



## Persistent Asset Memory Summary

- Raw project references: 405
- Canonical projects: 100
- Duplicate project clusters: 55
- Persistent assets tracked: 100
- LA persistent asset watch items: 65
- See `project_identity_report.md`, `persistent_asset_memory_report.md`, and `la_persistent_asset_watch_report.md` for canonical project tracking.

