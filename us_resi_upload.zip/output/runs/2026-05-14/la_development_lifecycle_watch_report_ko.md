# 한국어 LA 개발 단계 Watch

- 생성 시각: 2026-05-14 16:21:11
- 참고 원문 파일: `la_development_lifecycle_watch_report.md`
- 번역 방식: 규칙 기반 한국어 요약. OpenAI/GPT API는 호출하지 않음.

## 개발 단계별 프로젝트 현황

- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: Los Angeles, 주거복합, 점수 100 (Site Acquisition / Site Control; Monitor lifecycle status for repeated confirmation)
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, 어포더블 하우징, 점수 86 (Vertical Construction; Track construction progress and delivery timeline)
- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Los Angeles, 멀티패밀리, 점수 85 (Refinancing / Recapitalization; Review lender exposure, sponsor stress, and possible JV or rescue-capital angle)
- General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve...: Los Angeles, 일반 주거, 점수 84 (Unknown Stage; Monitor lifecycle status for repeated confirmation)
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Los Angeles, 아파트, 점수 83 (Delivery / Opening; Monitor lifecycle status for repeated confirmation)
- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: Los Angeles, 어포더블 하우징, 점수 82 (Delivery / Opening; Monitor lifecycle status for repeated confirmation)
- New look for affordable housing at 10304 S. Central Ave. in Watts: Los Angeles, 어포더블 하우징, 점수 81 (Site Acquisition / Site Control; Monitor lifecycle status for repeated confirmation)
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Lincoln Heights, 어포더블 하우징, 점수 80 (Vertical Construction; Track construction progress and delivery timeline)
- Entitlement / Permitting - Other / Unknown - Completion nears for mixed-use building at 3557 S. Motor Ave. in Palms: Los Angeles, 어포더블 하우징, 점수 77 (Delivery / Opening; Monitor lifecycle status for repeated confirmation)
- Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek in West Nashville.: Los Angeles, 주거복합, 점수 77 (Site Acquisition / Site Control; Monitor lifecycle status for repeated confirmation)

## 진행 / 정체 / 재등장 신호

- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: Los Angeles, 어포더블 하우징, 점수 78 (Mature / Operating; Mature)
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Los Angeles, 아파트, 점수 78 (Mature / Operating; Mature)
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, 어포더블 하우징, 점수 78 (Same Stage Persistence; Stable)
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Lincoln Heights, 어포더블 하우징, 점수 78 (Same Stage Persistence; Stable)
- Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Los Angeles, 아파트, 점수 77 (Mature / Operating; Mature)
- Completion nears for mixed-use building at 3557 S. Motor Ave. in Palms: Los Angeles, 어포더블 하우징, 점수 69 (Mature / Operating; Mature)
- Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: California, 어포더블 하우징, 점수 69 (Mature / Operating; Mature)
- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Los Angeles, 멀티패밀리, 점수 63 (Same Stage Persistence; Stable)
- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: Los Angeles, 주거복합, 점수 50 (Same Stage Persistence; Stable)
- New look for affordable housing at 10304 S. Central Ave. in Watts: Los Angeles, 어포더블 하우징, 점수 48 (Same Stage Persistence; Stable)

## 인허가 / 착공 / 리스업 타이밍

- Entitled / Approved, Construction Started, Delivery / Opening으로 이동하는 프로젝트는 별도 확인 대상입니다.
- Possible Stall 또는 Same Stage Persistence는 지연 / 재자본화 기회 가능성을 점검합니다.
