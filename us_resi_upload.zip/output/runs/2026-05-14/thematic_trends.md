# Thematic Trends

Generated: 2026-05-14 16:21:11

- Previous archive used: output\runs\2026-05-14
- Latest strategy-briefing articles: 27
- Latest market-signal articles: 19

## Key Thematic Alerts

- No major thematic increase alert was detected in this run.

## Theme Count Details

| Category | Theme | Latest | Previous | Change | Percentage Change | Alert |
| --- | --- | ---: | ---: | ---: | ---: | --- |
| Action Level | Must Read | 17 | 17 | 0 | 0.0% | Stable |
| Action Level | Review | 8 | 8 | 0 | 0.0% | Stable |
| Action Level | Monitor | 2 | 2 | 0 | 0.0% | Stable |
| Decision Use | Track Developer Strategy | 17 | 17 | 0 | 0.0% | Stable |
| Decision Use | Track Financing Conditions | 8 | 8 | 0 | 0.0% | Stable |
| Decision Use | Track Institutional Capital Flow | 6 | 6 | 0 | 0.0% | Stable |
| Decision Use | Track Rent / Vacancy Trend | 6 | 6 | 0 | 0.0% | Stable |
| Decision Use | Track Supply Pipeline | 4 | 4 | 0 | 0.0% | Stable |
| Decision Use | Track Regulation Risk | 2 | 2 | 0 | 0.0% | Stable |
| Market Focus | Other / Unknown | 12 | 12 | 0 | 0.0% | Stable |
| Market Focus | Los Angeles | 5 | 5 | 0 | 0.0% | Stable |
| Market Focus | National | 4 | 4 | 0 | 0.0% | Stable |
| Market Focus | New York | 3 | 3 | 0 | 0.0% | Stable |
| Market Focus | Sun Belt | 2 | 2 | 0 | 0.0% | Stable |
| Market Focus | California | 1 | 1 | 0 | 0.0% | Stable |
| Market Signal | Rent Growth Signal | 11 | 11 | 0 | 0.0% | Stable |
| Market Signal | Supply / Starts Signal | 5 | 5 | 0 | 0.0% | Stable |
| Market Signal | Deal Size Signal | 1 | 1 | 0 | 0.0% | Stable |
| Market Signal | Financing Cost Signal | 1 | 1 | 0 | 0.0% | Stable |
| Market Signal | Vacancy Signal | 1 | 1 | 0 | 0.0% | Stable |
| Strategic Angle | Developer Strategy | 17 | 17 | 0 | 0.0% | Stable |
| Strategic Angle | Financing Risk | 8 | 8 | 0 | 0.0% | Stable |
| Strategic Angle | Institutional Flow | 6 | 6 | 0 | 0.0% | Stable |
| Strategic Angle | Rent Growth / Demand | 6 | 6 | 0 | 0.0% | Stable |
| Strategic Angle | Supply Pressure | 4 | 4 | 0 | 0.0% | Stable |
| Strategic Angle | Regulation Risk | 2 | 2 | 0 | 0.0% | Stable |
| Woomi Relevance | High relevance to US residential developer strategy | 19 | 19 | 0 | 0.0% | Stable |
| Woomi Relevance | Medium relevance to market monitoring | 8 | 8 | 0 | 0.0% | Stable |

## Interpretation for Strategy Team

- No major thematic acceleration was detected, so continue monitoring for repeated patterns.
