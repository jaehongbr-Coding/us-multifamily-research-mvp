# LA / California Entitlement Watch Report

Generated: 2026-05-14 16:21:11

- Total LA / California entitlement watch items: 6

## Top LA / California Entitlement Opportunities

- Los Angeles: Density Bonus / TOC, Unknown Stage, score 48. Monitor density bonus use.
- Los Angeles: Density Bonus / TOC, Unknown Stage, score 48. Monitor density bonus use.
- Los Angeles: Entitlement Approval, Unknown Stage, score 45. Watch affordable housing requirement.
- Los Angeles: Density Bonus / TOC, Unknown Stage, score 38. Monitor density bonus use.
- San Francisco: Entitlement Approval, Unknown Stage, score 35. Track entitlement precedent.
- Los Angeles: CEQA / Environmental Review, Under Review, score 30. Track entitlement precedent.

## Top LA / California Entitlement Risks

- Los Angeles: CEQA / Environmental Review, Under Review, score 65. Track entitlement precedent.
- Los Angeles: Entitlement Approval, Unknown Stage, score 38. Watch affordable housing requirement.
- Los Angeles: Density Bonus / TOC, Unknown Stage, score 28. Monitor density bonus use.
- Los Angeles: Density Bonus / TOC, Unknown Stage, score 28. Monitor density bonus use.
- San Francisco: Entitlement Approval, Unknown Stage, score 28. Track entitlement precedent.
- Los Angeles: Density Bonus / TOC, Unknown Stage, score 28. Monitor density bonus use.

## Submarket Watch Table

| Submarket | Items | Top relevance |
| --- | ---: | ---: |
| Los Angeles | 5 | 65 |
| San Francisco | 1 | 49 |

## Project / Sponsor Watch

- Los Angeles: Entitlement Approval, Unknown Stage, score 65. Watch affordable housing requirement.
- Los Angeles: CEQA / Environmental Review, Under Review, score 52. Track entitlement precedent.
- Los Angeles: Density Bonus / TOC, Unknown Stage, score 49. Monitor density bonus use.
- Los Angeles: Density Bonus / TOC, Unknown Stage, score 49. Monitor density bonus use.
- San Francisco: Entitlement Approval, Unknown Stage, score 49. Track entitlement precedent.
- Los Angeles: Density Bonus / TOC, Unknown Stage, score 35. Monitor density bonus use.

## Office-to-Residential Watch

- None detected.

## Affordable / Density Bonus Watch

- Los Angeles: Entitlement Approval, Unknown Stage, score 65. Watch affordable housing requirement.
- Los Angeles: Density Bonus / TOC, Unknown Stage, score 49. Monitor density bonus use.
- Los Angeles: Density Bonus / TOC, Unknown Stage, score 49. Monitor density bonus use.
- Los Angeles: Density Bonus / TOC, Unknown Stage, score 35. Monitor density bonus use.

## Recommended Local Follow-up Actions

- Track local planning docket, sponsor, submarket, and entitlement precedent: Los Angeles / Entitlement Approval.
- Review CEQA status, appeal risk, and approval timeline: Los Angeles / CEQA / Environmental Review.
- Compare density bonus / TOC precedent with target-site assumptions: Los Angeles / Density Bonus / TOC.
- Compare density bonus / TOC precedent with target-site assumptions: Los Angeles / Density Bonus / TOC.
- Track local planning docket, sponsor, submarket, and entitlement precedent: San Francisco / Entitlement Approval.
- Compare density bonus / TOC precedent with target-site assumptions: Los Angeles / Density Bonus / TOC.

## Submarket / Parcel Intelligence Reference

Submarket-level site strategy detail is available in `submarket_intelligence_report.md` and `la_submarket_watch_report.md`.



## Development Lifecycle Intelligence Summary

- Lifecycle records: 48
- LA lifecycle watch items: 29
- Stage mix: Site Acquisition / Site Control: 5, Vertical Construction: 3, Refinancing / Recapitalization: 4, Unknown Stage: 26, Delivery / Opening: 7
- See `development_lifecycle_report.md` and `la_development_lifecycle_watch_report.md` for project timing, entitlement, permit, construction, delivery, and refinancing stages.

