# Regime Momentum Report

Generated: 2026-05-18 16:30:54

- Top regime by final_score: Supply Pressure (96)
- Second regime by final_score: Financing Stress (81)
- Dominant regime spread: 15

## Momentum Summary

| Regime | Previous Score | Latest Score | Change | Momentum |
| --- | ---: | ---: | ---: | --- |
| Supply Pressure | 96 | 96 | 0 | Stable |
| Financing Stress | 81 | 81 | 0 | Stable |
| Selective Capital Re-entry | 68 | 68 | 0 | Stable |
| Developer Strategy Shift | 59 | 59 | 0 | Stable |
| Policy / Entitlement Watch | 41 | 41 | 0 | Stable |
| Construction Cost Pressure | 0 | 0 | 0 | Stable |
| Stable Monitoring Environment | 0 | 0 | 0 | Stable |

## Concentration Interpretation

- The current regime picture is more concentrated because the top score is clearly ahead.

## Implications for Woomi / Woomi Global

- No regime is accelerating sharply, but strong current scores still deserve monitoring: Supply Pressure, Financing Stress, Selective Capital Re-entry.
