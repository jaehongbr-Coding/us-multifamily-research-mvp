# Trend Alerts

Generated: 2026-05-13 17:23:17

- Latest run timestamp: 2026-05-13 17:23:17
- Previous run timestamp: 2026-05-13 17:19:56

## Trend Metrics

| Metric | Latest | Previous | Change | Percentage Change | Alert |
| --- | ---: | ---: | ---: | ---: | --- |
| Total article volume | 48 | 30 | 18 | 60.0% | Sharp Increase |
| High-priority article volume | 19 | 14 | 5 | 35.7% | Moderate Increase |
| Market-signal article volume | 17 | 15 | 2 | 13.3% | Stable |
| Strategy-briefing article volume | 22 | 16 | 6 | 37.5% | Moderate Increase |

## Interpretation for Strategy Team

- Strategy-briefing articles increased, so more items may require review by the strategy team.
