# Thematic Trends

Generated: 2026-05-13 17:23:17

- Previous archive used: output\runs\2026-05-13
- Latest strategy-briefing articles: 22
- Latest market-signal articles: 17

## Key Thematic Alerts

- Los Angeles focus is New Theme (0 to 1).
- Market signal activity is increasing, led by Supply / Starts Signal (2 to 3).

## Theme Count Details

| Category | Theme | Latest | Previous | Change | Percentage Change | Alert |
| --- | --- | ---: | ---: | ---: | ---: | --- |
| Action Level | Must Read | 10 | 10 | 0 | 0.0% | Stable |
| Action Level | Review | 9 | 4 | 5 | 125.0% | Sharp Increase |
| Action Level | Monitor | 3 | 2 | 1 | 50.0% | Sharp Increase |
| Decision Use | Track Developer Strategy | 11 | 6 | 5 | 83.3% | Sharp Increase |
| Decision Use | Track Institutional Capital Flow | 8 | 7 | 1 | 14.3% | Stable |
| Decision Use | Track Financing Conditions | 7 | 7 | 0 | 0.0% | Stable |
| Decision Use | Track Rent / Vacancy Trend | 3 | 3 | 0 | 0.0% | Stable |
| Decision Use | Track Supply Pipeline | 2 | 2 | 0 | 0.0% | Stable |
| Market Focus | Other / Unknown | 14 | 11 | 3 | 27.3% | Moderate Increase |
| Market Focus | Florida | 2 | 2 | 0 | 0.0% | Stable |
| Market Focus | National | 2 | 2 | 0 | 0.0% | Stable |
| Market Focus | New York | 2 | 1 | 1 | 100.0% | Sharp Increase |
| Market Focus | Los Angeles | 1 | 0 | 1 | 100.0% | New Theme |
| Market Focus | Sun Belt | 1 | 0 | 1 | 100.0% | New Theme |
| Market Signal | Deal Size Signal | 7 | 6 | 1 | 16.7% | Stable |
| Market Signal | Rent Growth Signal | 4 | 4 | 0 | 0.0% | Stable |
| Market Signal | Supply / Starts Signal | 3 | 2 | 1 | 50.0% | Sharp Increase |
| Market Signal | Financing Cost Signal | 2 | 2 | 0 | 0.0% | Stable |
| Market Signal | Vacancy Signal | 1 | 1 | 0 | 0.0% | Stable |
| Strategic Angle | Developer Strategy | 11 | 6 | 5 | 83.3% | Sharp Increase |
| Strategic Angle | Institutional Flow | 8 | 7 | 1 | 14.3% | Stable |
| Strategic Angle | Financing Risk | 7 | 7 | 0 | 0.0% | Stable |
| Strategic Angle | Rent Growth / Demand | 3 | 3 | 0 | 0.0% | Stable |
| Strategic Angle | Supply Pressure | 2 | 2 | 0 | 0.0% | Stable |
| Woomi Relevance | High relevance to US residential developer strategy | 15 | 13 | 2 | 15.4% | Stable |
| Woomi Relevance | Medium relevance to market monitoring | 7 | 3 | 4 | 133.3% | Sharp Increase |

## Interpretation for Strategy Team

- California or Los Angeles focus increased, which is directly relevant to Woomi's California / LA strategy.
