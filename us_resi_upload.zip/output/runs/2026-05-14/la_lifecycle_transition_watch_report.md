# LA Lifecycle Transition Watch Report

Generated: 2026-05-14 16:21:12

- Total LA lifecycle transition watch items: 26

## LA Projects Moving Forward

- None detected.

## LA Projects With Stall Risk

- HUD trims environmental reviews for multifamily projects: Environmental Review / CEQA -> Environmental Review / CEQA, Early entitlement watch.

## LA Permit / Construction Start Watch

- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Vertical Construction -> Vertical Construction, Construction start watch.
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Vertical Construction -> Vertical Construction, Construction start watch.

## LA Refinancing / Recap Timing Watch

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Refinancing / Recapitalization -> Refinancing / Recapitalization, Refinancing / recap timing watch.

## LA Delivery / Lease-Up Benchmarks

- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: Delivery / Opening -> Delivery / Opening, Delivery / lease-up benchmark.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Delivery / Opening -> Delivery / Opening, Delivery / lease-up benchmark.
- Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Delivery / Opening -> Delivery / Opening, Delivery / lease-up benchmark.
- Completion nears for mixed-use building at 3557 S. Motor Ave. in Palms: Delivery / Opening -> Delivery / Opening, Delivery / lease-up benchmark.
- Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: Delivery / Opening -> Delivery / Opening, Delivery / lease-up benchmark.

## Recommended LA Transition Follow-up Actions

- Use as delivery, lease-up, and underwriting benchmark: General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd..
- Use as delivery, lease-up, and underwriting benchmark: General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd..
- Monitor for another run to confirm lifecycle direction: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.
- Monitor for another run to confirm lifecycle direction: Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.
- Use as delivery, lease-up, and underwriting benchmark: Onni Group plans twin 67-story towers at 5700 Wilshire Blvd..
- Use as delivery, lease-up, and underwriting benchmark: Completion nears for mixed-use building at 3557 S. Motor Ave. in Palms.
- Use as delivery, lease-up, and underwriting benchmark: Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd..
- Track maturity, lender, recapitalization need, and potential JV angle: Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village....



## Persistent Asset Memory Summary

- Raw project references: 344
- Canonical projects: 85
- Duplicate project clusters: 46
- Persistent assets tracked: 85
- LA persistent asset watch items: 51
- See `project_identity_report.md`, `persistent_asset_memory_report.md`, and `la_persistent_asset_watch_report.md` for canonical project tracking.

