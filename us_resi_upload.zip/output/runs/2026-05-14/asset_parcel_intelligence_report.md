# Real Asset & Parcel Intelligence Report

Generated: 2026-05-14 16:21:12

- Total asset / parcel signals: 48

## Top Site-Level Opportunities

- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Lease-Up / Delivery, 5700 Wilshire Blvd, asset_opportunity_score 95.
- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: General Asset Signal, 400 San Vicente Blvd, asset_opportunity_score 94.
- General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts: Affordable / Density Bonus Strategy, 10304 S. Central Ave, asset_opportunity_score 94.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Affordable / Density Bonus Strategy, 1321 N. Mission Rd, asset_opportunity_score 94.
- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Affordable / Density Bonus Strategy, 2155 E. Colorado Blvd, asset_opportunity_score 86.
- General Project Signal - Other / Unknown - 22 homes pitched for 1072 E. Villa St. in Pasadena: General Asset Signal, 1072 E. Villa St, asset_opportunity_score 86.
- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Refinancing / Recapitalization, New York, asset_opportunity_score 85.
- General Project Signal - New York - Stagg Group Files Plans for 68 Apartments in Astoria: General Asset Signal, New York, asset_opportunity_score 82.
- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: General Asset Signal, Nashville, asset_opportunity_score 82.
- Entitlement / Permitting - Other / Unknown - Completion nears for mixed-use building at 3557 S. Motor Ave. in Palms: Entitlement Play, 3557 S. Motor Ave, asset_opportunity_score 81.

## Top Site-Level Risks

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Refinancing / Recapitalization, New York, asset_risk_score 57.
- Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal...: Refinancing / Recapitalization, Unknown, asset_risk_score 55.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: Refinancing / Recapitalization, Miami, asset_risk_score 55.
- HUD trims environmental reviews for multifamily projects: General Asset Signal, Los Angeles, asset_risk_score 42.
- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: General Asset Signal, 400 San Vicente Blvd, asset_risk_score 40.
- General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts: Affordable / Density Bonus Strategy, 10304 S. Central Ave, asset_risk_score 40.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Affordable / Density Bonus Strategy, 1321 N. Mission Rd, asset_risk_score 40.
- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Affordable / Density Bonus Strategy, 2155 E. Colorado Blvd, asset_risk_score 40.
- Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: General Asset Signal, 400 San Vicente Blvd, asset_risk_score 40.
- New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Affordable / Density Bonus Strategy, 2155 E. Colorado Blvd, asset_risk_score 40.

## Assets With Address / Location Clues

- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Lease-Up / Delivery, 5700 Wilshire Blvd, asset_opportunity_score 95.
- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: General Asset Signal, 400 San Vicente Blvd, asset_opportunity_score 94.
- General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts: Affordable / Density Bonus Strategy, 10304 S. Central Ave, asset_opportunity_score 94.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Affordable / Density Bonus Strategy, 1321 N. Mission Rd, asset_opportunity_score 94.
- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Affordable / Density Bonus Strategy, 2155 E. Colorado Blvd, asset_opportunity_score 86.
- General Project Signal - Other / Unknown - 22 homes pitched for 1072 E. Villa St. in Pasadena: General Asset Signal, 1072 E. Villa St, asset_opportunity_score 86.
- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Refinancing / Recapitalization, New York, asset_opportunity_score 85.
- General Project Signal - New York - Stagg Group Files Plans for 68 Apartments in Astoria: General Asset Signal, New York, asset_opportunity_score 82.
- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: General Asset Signal, Nashville, asset_opportunity_score 82.
- Entitlement / Permitting - Other / Unknown - Completion nears for mixed-use building at 3557 S. Motor Ave. in Palms: Entitlement Play, 3557 S. Motor Ave, asset_opportunity_score 81.

## Assets With Identified Developers / Sponsors

- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: General Asset Signal, Nashville, asset_opportunity_score 82.
- General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve...: General Asset Signal, New York, asset_opportunity_score 67.

## Assets With Entitlement or Permit Signals

- None detected.

## Assets With Financing / Refinancing Signals

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Refinancing / Recapitalization, New York, asset_risk_score 57.
- Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal...: Refinancing / Recapitalization, Unknown, asset_risk_score 55.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: Refinancing / Recapitalization, Miami, asset_risk_score 55.
- CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Caldwell New Jersey: Refinancing / Recapitalization, 780 Passaic Avenue, asset_risk_score 34.

## Office-to-Residential Asset Signals

- None detected.

## Affordable / Density Bonus Asset Signals

- General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts: Affordable / Density Bonus Strategy, 10304 S. Central Ave, asset_opportunity_score 94.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Affordable / Density Bonus Strategy, 1321 N. Mission Rd, asset_opportunity_score 94.
- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Affordable / Density Bonus Strategy, 2155 E. Colorado Blvd, asset_opportunity_score 86.
- New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Affordable / Density Bonus Strategy, 2155 E. Colorado Blvd, asset_opportunity_score 75.
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Affordable / Density Bonus Strategy, 1321 N. Mission Rd, asset_opportunity_score 75.
- New look for affordable housing at 10304 S. Central Ave. in Watts: Affordable / Density Bonus Strategy, 10304 S. Central Ave, asset_opportunity_score 75.
- Formal Permits For 375 Laguna Honda Boulevard, San Francisco: Affordable / Density Bonus Strategy, 375 Laguna Honda Boulevard, asset_opportunity_score 63.
- Affordable Senior Housing Community Southernside West Set to Break Ground in Greenvillen South Carolina: Affordable / Density Bonus Strategy, 846 West Washington Street, asset_opportunity_score 53.
- JV / Partnership - Other / Unknown - Affordable Senior Housing Community Southernside West Set to Break Ground in Greenvillen S...: Affordable / Density Bonus Strategy, Unknown, asset_opportunity_score 52.

## Implications for Woomi / Woomi Global

- Asset and parcel intelligence helps connect strategy signals to specific sites, sponsors, permits, financing events, and construction stages.
- Rows with addresses, named projects, entitlement status, or site control clues should feed underwriting, local sponsor mapping, and site-screening conversations.

## Recommended Asset-Level Follow-up Actions

- Review site details, sponsor, entitlement path, and local precedent: General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd..
- Review site details, sponsor, entitlement path, and local precedent: General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd..
- Review site details, sponsor, entitlement path, and local precedent: General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts.
- Review site details, sponsor, entitlement path, and local precedent: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.
- Review site details, sponsor, entitlement path, and local precedent: Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena.
- Monitor asset-level signal for repeated confirmation: General Project Signal - Other / Unknown - 22 homes pitched for 1072 E. Villa St. in Pasadena.
- Review acquisition, financing, ownership, and comparable transaction details: Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village....
- Monitor asset-level signal for repeated confirmation: General Project Signal - New York - Stagg Group Files Plans for 68 Apartments in Astoria.



## Development Lifecycle Intelligence Summary

- Lifecycle records: 48
- LA lifecycle watch items: 29
- Stage mix: Site Acquisition / Site Control: 5, Vertical Construction: 3, Refinancing / Recapitalization: 4, Unknown Stage: 26, Delivery / Opening: 7
- See `development_lifecycle_report.md` and `la_development_lifecycle_watch_report.md` for project timing, entitlement, permit, construction, delivery, and refinancing stages.




## Lifecycle Transition Summary

- Lifecycle transitions analyzed: 48
- Newly detected projects: 0
- Forward progression projects: 0
- Possible stalled projects: 0
- LA lifecycle transition watch items: 26
- See `lifecycle_transition_report.md` and `la_lifecycle_transition_watch_report.md` for multi-run project movement and timing signals.




## Persistent Asset Memory Summary

- Raw project references: 344
- Canonical projects: 85
- Duplicate project clusters: 46
- Persistent assets tracked: 85
- LA persistent asset watch items: 51
- See `project_identity_report.md`, `persistent_asset_memory_report.md`, and `la_persistent_asset_watch_report.md` for canonical project tracking.

