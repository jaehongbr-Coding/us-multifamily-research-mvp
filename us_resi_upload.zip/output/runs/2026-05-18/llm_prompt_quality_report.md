# LLM Prompt Quality Report

Generated: 2026-05-18 16:30:54

- Total prompts reviewed: 31
- Average prompt quality score: 89.0
- Excellent prompts: 18
- Good prompts: 13
- Needs Improvement prompts: 0
- Poor prompts: 0

## Top 5 Strongest Prompts

- 98 (Excellent): Cushman & Wakefield Brokers $26.4M Sale of 108-Home Built-to-Rent Multifamily Community The Manors at Brookmere in Matteson Illinois
- 98 (Excellent): Quarterra Seeks Buyers For Almost 4,000 Apartments
- 98 (Excellent): Core Spaces Secures $1.64B Fundraise for Student Housing Development, Investment
- 98 (Excellent): 96 apartments + retail proposed at 8871 W. Venice Blvd.
- 98 (Excellent): Site prep underway for affordable housing at 4301 S. Vermont Ave.

## Top 5 Weakest Prompts

- 74 (Good): Best Year for Missing Middle Construction Since 2007 - Missing: missing extracted numbers; missing market focus; missing market signal
- 74 (Good): Missing Middle Weakness - Missing: missing extracted numbers; missing market focus; missing market signal
- 74 (Good): Shorter Apartment Construction Time in 2024 - Missing: missing extracted numbers; missing market focus; missing market signal
- 82 (Good): The Market Data that Matters for the rest of 2026: A Chat with Zillow’s Chief Economist - Missing: missing extracted numbers; missing market signal
- 82 (Good): Institutional Property Advisors Closes Sale and Arranges Financing for Dallas Multifamily Asset Sylvan Thirty - Missing: missing extracted numbers; missing market signal

## Common Missing Context Issues

- missing market signal: 13
- missing extracted numbers: 12
- missing market focus: 10
