# Thematic Trends

Generated: 2026-05-18 16:30:54

- Previous archive used: output\runs\2026-05-18
- Latest strategy-briefing articles: 31
- Latest market-signal articles: 23

## Key Thematic Alerts

- No major thematic increase alert was detected in this run.

## Theme Count Details

| Category | Theme | Latest | Previous | Change | Percentage Change | Alert |
| --- | --- | ---: | ---: | ---: | ---: | --- |
| Action Level | Must Read | 22 | 22 | 0 | 0.0% | Stable |
| Action Level | Review | 8 | 8 | 0 | 0.0% | Stable |
| Action Level | Monitor | 1 | 1 | 0 | 0.0% | Stable |
| Decision Use | Track Developer Strategy | 20 | 20 | 0 | 0.0% | Stable |
| Decision Use | Track Institutional Capital Flow | 13 | 13 | 0 | 0.0% | Stable |
| Decision Use | Track Financing Conditions | 9 | 9 | 0 | 0.0% | Stable |
| Decision Use | Track Rent / Vacancy Trend | 7 | 7 | 0 | 0.0% | Stable |
| Decision Use | Track Supply Pipeline | 5 | 5 | 0 | 0.0% | Stable |
| Decision Use | Track Regulation Risk | 2 | 2 | 0 | 0.0% | Stable |
| Market Focus | Other / Unknown | 10 | 10 | 0 | 0.0% | Stable |
| Market Focus | Los Angeles | 7 | 7 | 0 | 0.0% | Stable |
| Market Focus | Sun Belt | 6 | 6 | 0 | 0.0% | Stable |
| Market Focus | California | 3 | 3 | 0 | 0.0% | Stable |
| Market Focus | National | 2 | 2 | 0 | 0.0% | Stable |
| Market Focus | New York | 2 | 2 | 0 | 0.0% | Stable |
| Market Focus | Southeast | 1 | 1 | 0 | 0.0% | Stable |
| Market Signal | Rent Growth Signal | 9 | 9 | 0 | 0.0% | Stable |
| Market Signal | Supply / Starts Signal | 7 | 7 | 0 | 0.0% | Stable |
| Market Signal | Financing Cost Signal | 3 | 3 | 0 | 0.0% | Stable |
| Market Signal | Vacancy Signal | 3 | 3 | 0 | 0.0% | Stable |
| Market Signal | Deal Size Signal | 1 | 1 | 0 | 0.0% | Stable |
| Strategic Angle | Developer Strategy | 20 | 20 | 0 | 0.0% | Stable |
| Strategic Angle | Institutional Flow | 13 | 13 | 0 | 0.0% | Stable |
| Strategic Angle | Financing Risk | 9 | 9 | 0 | 0.0% | Stable |
| Strategic Angle | Rent Growth / Demand | 7 | 7 | 0 | 0.0% | Stable |
| Strategic Angle | Supply Pressure | 5 | 5 | 0 | 0.0% | Stable |
| Strategic Angle | Regulation Risk | 2 | 2 | 0 | 0.0% | Stable |
| Woomi Relevance | High relevance to US residential developer strategy | 24 | 24 | 0 | 0.0% | Stable |
| Woomi Relevance | Medium relevance to market monitoring | 7 | 7 | 0 | 0.0% | Stable |

## Interpretation for Strategy Team

- No major thematic acceleration was detected, so continue monitoring for repeated patterns.
