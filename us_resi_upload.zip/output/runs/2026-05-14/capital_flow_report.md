# Capital Flow Memory Report

Generated: 2026-05-14 16:21:11

## Debt-Market Stress Summary

- Fannie Mae (Recurring Lender): Stable capital pattern, 24 observation(s), importance 100.
- New York (Market-Level Capital Concentration): Stable capital pattern, 29 observation(s), importance 100.

## Capital Migration Patterns

- Blackstone (Institutional Capital Flow): Stable capital pattern, 24 observation(s), importance 100.
- Blackstone (Recurring Capital Partner): Stable capital pattern, 24 observation(s), importance 100.
- Crescent Communities (Institutional Capital Flow): Stable capital pattern, 24 observation(s), importance 100.

## Recurring Construction Lending Activity

- CBRE (Recurring Lender): Stable capital pattern, 24 observation(s), importance 100.
- Other / Unknown (Market-Level Capital Concentration): Stable capital pattern, 72 observation(s), importance 100.

## Agency Financing Patterns

- Fannie Mae (Recurring Lender): Stable capital pattern, 24 observation(s), importance 100.

## Refinancing Hotspots

- Fannie Mae (Recurring Lender): Stable capital pattern, 24 observation(s), importance 100.
- New York (Market-Level Capital Concentration): Stable capital pattern, 29 observation(s), importance 100.

## Institutional Capital Concentration

- California (Market-Level Capital Concentration): Stable capital pattern, 24 observation(s), importance 100.
- California (Market-Level Capital Concentration): Capital flow fading, 22 observation(s), importance 100.
- Los Angeles (Market-Level Capital Concentration): Stable capital pattern, 24 observation(s), importance 100.
- Los Angeles (Market-Level Capital Concentration): Stable capital pattern, 96 observation(s), importance 100.
- National (Market-Level Capital Concentration): Stable capital pattern, 24 observation(s), importance 100.
- National (Market-Level Capital Concentration): Stable capital pattern, 48 observation(s), importance 100.
- New York (Market-Level Capital Concentration): Stable capital pattern, 24 observation(s), importance 100.
- New York (Market-Level Capital Concentration): Stable capital pattern, 46 observation(s), importance 100.
- New York (Market-Level Capital Concentration): Stable capital pattern, 29 observation(s), importance 100.
- Sun Belt (Market-Level Capital Concentration): Stable capital pattern, 24 observation(s), importance 100.

## Opportunity / Distress Radar

Opportunity radar is available in `opportunity_radar_report.md`.
Distress watchlist is available in `distress_watchlist_report.md`.
Canonical deal fingerprints are available in `deal_fingerprint_report.md`.
Opportunity deduplication is available in `opportunity_deduplication_report.md`.
Timing intelligence is available in `timing_intelligence_report.md`.
Market entry window scoring is available in `market_entry_window_report.md`.
