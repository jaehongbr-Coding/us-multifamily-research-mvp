# Submarket Intelligence Report

Generated: 2026-05-18 16:30:55

- Total submarkets detected: 26

## Top Submarkets By Opportunity Score

- Los Angeles (Los Angeles): submarket_opportunity_score 90, Monitor entitlement precedent.
- Inland Empire (Inland Empire): submarket_opportunity_score 86, Review potential acquisition pipeline.
- Venice (Los Angeles): submarket_opportunity_score 70, Monitor entitlement precedent.
- Wilshire (Los Angeles): submarket_opportunity_score 63, Review potential acquisition pipeline.
- DTLA (Los Angeles): submarket_opportunity_score 62, Review potential acquisition pipeline.
- Santa Monica (Los Angeles): submarket_opportunity_score 61, Review potential acquisition pipeline.
- Lincoln Heights (Los Angeles): submarket_opportunity_score 57, Monitor only.
- Houston (Texas): submarket_opportunity_score 48, Monitor only.
- New York (New York): submarket_opportunity_score 48, Track local GP / sponsor activity.
- Phoenix (Arizona): submarket_opportunity_score 47, Monitor only.

## Top Submarkets By Risk Score

- Inland Empire (Inland Empire): submarket_risk_score 52, Review potential acquisition pipeline.
- Santa Monica (Los Angeles): submarket_risk_score 46, Review potential acquisition pipeline.
- Los Angeles (Los Angeles): submarket_risk_score 21, Monitor entitlement precedent.
- Venice (Los Angeles): submarket_risk_score 11, Monitor entitlement precedent.
- Wilshire (Los Angeles): submarket_risk_score 0, Review potential acquisition pipeline.
- DTLA (Los Angeles): submarket_risk_score 0, Review potential acquisition pipeline.
- Lincoln Heights (Los Angeles): submarket_risk_score 0, Monitor only.
- Houston (Texas): submarket_risk_score 0, Monitor only.
- New York (New York): submarket_risk_score 0, Track local GP / sponsor activity.
- Phoenix (Arizona): submarket_risk_score 0, Monitor only.

## Highest Execution Complexity Submarkets

- Los Angeles (Los Angeles): execution_complexity_score 52, Monitor entitlement precedent.
- Inland Empire (Inland Empire): execution_complexity_score 30, Review potential acquisition pipeline.
- Venice (Los Angeles): execution_complexity_score 30, Monitor entitlement precedent.
- Wilshire (Los Angeles): execution_complexity_score 30, Review potential acquisition pipeline.
- DTLA (Los Angeles): execution_complexity_score 30, Review potential acquisition pipeline.
- Santa Monica (Los Angeles): execution_complexity_score 30, Review potential acquisition pipeline.
- Lincoln Heights (Los Angeles): execution_complexity_score 30, Monitor only.
- Culver City (Los Angeles): execution_complexity_score 30, Monitor only.
- Downtown Los Angeles (Los Angeles): execution_complexity_score 30, Monitor only.
- Ontario (Inland Empire): execution_complexity_score 30, Monitor only.

## Sector Themes By Submarket

- Los Angeles: Mixed-Use Residential, Mixed-use corridor.
- Inland Empire: General Residential, Hospital-adjacent.
- Venice: Mixed-Use Residential, Mixed-use corridor.
- Wilshire: Apartment, Mixed-use corridor.
- DTLA: General Residential, Downtown infill.
- Santa Monica: Affordable Housing, Mixed-use corridor.
- Lincoln Heights: Affordable Housing, Hospital-adjacent.
- Houston: BTR / Single-Family Rental, General submarket monitoring.
- New York: General Residential, Transit-oriented development.
- Phoenix: BTR / Single-Family Rental, General submarket monitoring.
- Miami: Apartment, Waterfront redevelopment.
- Dallas: Mixed-Use Residential, Suburban growth corridor.

## Timing and Entitlement Signals By Submarket

- Los Angeles: 0 timing signal(s), 2 entitlement signal(s).
- Inland Empire: 1 timing signal(s), 0 entitlement signal(s).
- Venice: 1 timing signal(s), 1 entitlement signal(s).
- Wilshire: 1 timing signal(s), 0 entitlement signal(s).
- DTLA: 1 timing signal(s), 0 entitlement signal(s).
- Santa Monica: 1 timing signal(s), 0 entitlement signal(s).
- Lincoln Heights: 0 timing signal(s), 0 entitlement signal(s).
- Houston: 1 timing signal(s), 0 entitlement signal(s).
- New York: 0 timing signal(s), 0 entitlement signal(s).
- Phoenix: 1 timing signal(s), 0 entitlement signal(s).
- Miami: 0 timing signal(s), 0 entitlement signal(s).
- Dallas: 1 timing signal(s), 0 entitlement signal(s).

## Implications for Woomi / Woomi Global

- Submarket intelligence helps turn broad regional monitoring into site-screening and local execution watchlists.
- LA / California submarkets with entitlement or execution complexity should be reviewed before sourcing or underwriting assumptions are finalized.
- Asset / parcel-level site clues are available in `asset_parcel_intelligence_report.md` and `la_asset_watch_report.md`.

## Recommended Submarket Follow-up Actions

- Monitor entitlement precedent: Los Angeles (High relevance to Woomi site strategy).
- Review potential acquisition pipeline: Inland Empire (High relevance to Woomi site strategy).
- Monitor entitlement precedent: Venice (High relevance to Woomi site strategy).
- Review potential acquisition pipeline: Wilshire (High relevance to Woomi site strategy).
- Review potential acquisition pipeline: DTLA (High relevance to Woomi site strategy).
- Review potential acquisition pipeline: Santa Monica (High relevance to Woomi site strategy).
- Monitor only: Lincoln Heights (High relevance to Woomi site strategy).
- Monitor only: Houston (Strategic watch submarket).



## Development Lifecycle Intelligence Summary

- Lifecycle records: 54
- LA lifecycle watch items: 32
- Stage mix: Unknown Stage: 28, Vertical Construction: 4, Site Acquisition / Site Control: 8, Delivery / Opening: 9, Early Site Signal: 4
- See `development_lifecycle_report.md` and `la_development_lifecycle_watch_report.md` for project timing, entitlement, permit, construction, delivery, and refinancing stages.

