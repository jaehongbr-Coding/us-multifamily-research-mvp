# 한국어 LA 개발 단계 Watch

- 생성 시각: 2026-05-18 16:30:54
- 참고 원문 파일: `la_development_lifecycle_watch_report.md`
- 번역 방식: 규칙 기반 한국어 요약. OpenAI/GPT API는 호출하지 않음.

## 개발 단계별 프로젝트 현황

- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Los Angeles, 아파트, 점수 100 (Unknown Stage; Monitor lifecycle status for repeated confirmation)
- Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave.: Los Angeles, 어포더블 하우징, 점수 88 (Site Acquisition / Site Control; Monitor lifecycle status for repeated confirmation)
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, 어포더블 하우징, 점수 87 (Vertical Construction; Track construction progress and delivery timeline)
- General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve...: Los Angeles, 일반 주거, 점수 84 (Unknown Stage; Monitor lifecycle status for repeated confirmation)
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Los Angeles, 아파트, 점수 83 (Delivery / Opening; Monitor lifecycle status for repeated confirmation)
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: Los Angeles, 주거복합, 점수 81 (Early Site Signal; Monitor lifecycle status for repeated confirmation)
- Site prep underway for affordable housing at 4301 S. Vermont Ave.: Los Angeles, 어포더블 하우징, 점수 81 (Site Acquisition / Site Control; Monitor lifecycle status for repeated confirmation)
- Disposition / Exit - California - Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale: Los Angeles, 멀티패밀리, 점수 81 (Site Acquisition / Site Control; Monitor lifecycle status for repeated confirmation)
- Cypress Equity Investments gets $170M loan for two Santa Monica projects: Los Angeles, 어포더블 하우징, 점수 80 (Refinancing / Recapitalization; Review lender exposure, sponsor stress, and possible JV or rescue-capital angle)
- Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles: Los Angeles, 주거복합, 점수 80 (Delivery / Opening; Monitor lifecycle status for repeated confirmation)

## 진행 / 정체 / 재등장 신호

- Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles: Los Angeles, 주거복합, 점수 78 (Mature / Operating; Mature)
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Los Angeles, 아파트, 점수 78 (Mature / Operating; Mature)
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, 어포더블 하우징, 점수 78 (Same Stage Persistence; Stable)
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Lincoln Heights, 어포더블 하우징, 점수 78 (Same Stage Persistence; Stable)
- Development Start - Los Angeles - The Broad's $100M expansion tops out in DTLA: Los Angeles, 일반 주거, 점수 78 (Same Stage Persistence; Stable)
- Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Los Angeles, 아파트, 점수 77 (Mature / Operating; Mature)
- Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles: Los Angeles, 주거복합, 점수 76 (Mature / Operating; Mature)
- BTR / Build-to-Rent - Sun Belt - NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino: Los Angeles, BTR / 단독주택 임대, 점수 76 (Mature / Operating; Mature)
- Disposition / Exit - Sun Belt - Institutional Property Advisors Closes Sale and Arranges Financing for Dallas Multifamily...: Los Angeles, 주거복합, 점수 75 (Mature / Operating; Mature)
- NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino: Los Angeles, BTR / 단독주택 임대, 점수 75 (Mature / Operating; Mature)

## 인허가 / 착공 / 리스업 타이밍

- Entitled / Approved, Construction Started, Delivery / Opening으로 이동하는 프로젝트는 별도 확인 대상입니다.
- Possible Stall 또는 Same Stage Persistence는 지연 / 재자본화 기회 가능성을 점검합니다.
