# 한국어 GP Watchlist

- 생성 시각: 2026-05-18 16:30:54
- 참고 원문 파일: `gp_watchlist_report.md`
- 번역 방식: 규칙 기반 한국어 요약. OpenAI/GPT API는 호출하지 않음.

## 주요 GP Watchlist

- Quarterra: 기타 / 미확인, 일반 주거, 점수 75 (Tier 2 High Potential GP; Capital market and pricing discovery reference)
- Blackstone: 기타 / 미확인, 일반 주거, 점수 58 (Tier 3 Monitoring GP; Potential GP partnership candidate)
- Alliance Residential: 기타 / 미확인, 일반 주거, 점수 47 (Emerging Watchlist; Capital market and pricing discovery reference)

## 기관자본 연결성

- Quarterra: 기타 / 미확인, 아파트, 점수 99 (Capital Inflow; GP Capability Benchmark Signal)
- Blackstone: 기타 / 미확인, 일반 주거, 점수 88 (Capital Inflow; Potential JV / Partnership Signal)
- Alliance Residential: 기타 / 미확인, 주거복합, 점수 81 (Capital Inflow; No Clear Relationship Signal)

## JV / Partnership 가능성

- JV / Partnership - Sun Belt - CFAM, RPM Living Acquire 380-Unit Waterfront Multifamily Community in North Miami → Miami: JV / Partnership, 점수 63
- JV / Partnership - Sun Belt - CFAM, RPM Living Acquire 380-Unit Waterfront Multifamily Community in North Miami → Sun Belt: JV / Partnership, 점수 63

## 우미 파트너십 관점

- GP 신호는 자본 파트너, 시장, 프로젝트 단계, 반복 출현 여부와 함께 검토합니다.
- LA / California 또는 기관자본 연결성이 있는 GP는 우선 Watch 대상입니다.
