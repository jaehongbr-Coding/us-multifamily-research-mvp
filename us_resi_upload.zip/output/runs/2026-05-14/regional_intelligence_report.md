# Regional Intelligence Report

Generated: 2026-05-14 16:21:11

## Top 5 Markets By Relevance

- Los Angeles: Core Watch Market, 9 article(s), average relevance 93.6.
- California: Core Watch Market, 2 article(s), average relevance 63.5.
- National / Other: General Monitoring, 28 article(s), average relevance 73.6.
- New York: General Monitoring, 4 article(s), average relevance 76.8.
- Southeast: Strategic Watch Market, 2 article(s), average relevance 92.5.

## LA / California Focus

- Los Angeles: 9 article(s), 7 market signal(s), Core Watch Market. Track LA / California entitlement and zoning updates.
- California: 2 article(s), 2 market signal(s), Core Watch Market. Track LA / California entitlement and zoning updates.

## Sun Belt / Texas / Southeast

- Southeast: 2 article(s), 1 market signal(s), Strategic Watch Market. Watch GP / developer partnership opportunities.
- Sun Belt: 3 article(s), 1 market signal(s), Strategic Watch Market. Review development underwriting assumptions.
- Florida: 1 article(s), 0 market signal(s), Strategic Watch Market. Review development underwriting assumptions.
- Texas: 2 article(s), 1 market signal(s), Strategic Watch Market. Monitor only.

## Coastal Markets

- New York: 4 article(s), 2 market signal(s), General Monitoring. Review development underwriting assumptions.

## National Market Signals

- National / Other: 28 article(s), 10 market signal(s), General Monitoring. Watch GP / developer partnership opportunities.

## Deal / Project Intelligence

Market-level deal and project signals are available in `deal_pipeline_report.md`.
- New York: Refinancing, Capital market signal.
- Los Angeles: General Project Signal, Capital market signal.
- Los Angeles: Entitlement / Permitting, Entitlement / zoning watch.
- Los Angeles: General Project Signal, Entitlement / zoning watch.
- Los Angeles: General Project Signal, Entitlement / zoning watch.

## Relationship Graph Intelligence

Market-level relationship edges are available in `relationship_graph_report.md`.
- Sun Belt: Crescent Communities -> Nashville (JV / Partnership).
- Sun Belt: Crescent Communities -> Sun Belt (JV / Partnership).
- New York: Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village... -> New York (Financing Relationship).
- Los Angeles: General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd. -> Los Angeles (Market Expansion).
- Los Angeles: Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena -> Los Angeles (Entitlement / Permitting).

## Canonical Deal Summary

Historical memory uses unique canonical deal/event rows from `deal_fingerprint_report.md` where available.
This reduces article-count inflation in recurring entity and relationship observations.

## Opportunity / Distress Radar

Opportunity radar is available in `opportunity_radar_report.md`.
Distress watchlist is available in `distress_watchlist_report.md`.
Canonical deal fingerprints are available in `deal_fingerprint_report.md`.
Opportunity deduplication is available in `opportunity_deduplication_report.md`.

## Implications for Woomi / Woomi Global

- Core watch markets have current signals, so LA / California monitoring should stay linked to underwriting and entitlement review.
- Strategic watch markets have current signals, so the team should compare supply, capital flow, and partnership opportunities by region.

## Recommended Regional Follow-up Actions

- Los Angeles: Track LA / California entitlement and zoning updates
- California: Track LA / California entitlement and zoning updates
- Southeast: Watch GP / developer partnership opportunities
- Sun Belt: Review development underwriting assumptions
- Florida: Review development underwriting assumptions
- Texas: Monitor only
