# Pipeline Manifest

Generated: 2026-05-14 16:21:11

This file is the output index for the single-file MVP. It helps you see what was generated, who should read it, and where each output fits in the research workflow.

## Summary

- Total tracked outputs: 56
- Generated outputs: 56
- Missing outputs: 0
- First file to open: `executive_dashboard_brief.md`

## Output Index

| File | Type | Category | Status | Rows / Sections | Reader |
|---|---|---|---|---:|---|
| `articles.csv` | CSV | Raw Collection | Generated | 43 | Strategy Team |
| `high_priority_articles.csv` | CSV | Strategy Briefing | Generated | 25 | Executive |
| `market_signals.csv` | CSV | Strategy Briefing | Generated | 19 | Strategy Team |
| `strategy_briefing.csv` | CSV | Strategy Briefing | Generated | 27 | Executive |
| `daily_strategy_briefing.md` | Markdown | Strategy Briefing | Generated | 95 | Executive |
| `weekly_strategy_memo.md` | Markdown | Strategy Briefing | Generated | 39 | Executive |
| `executive_dashboard_brief.md` | Markdown | Executive Dashboard | Generated | 11 | Executive |
| `executive_dashboard_brief_ko.md` | Markdown | Executive Dashboard | Generated | 7 | Executive |
| `weekly_strategy_memo_ko.md` | Markdown | Strategy Briefing | Generated | 6 | Executive |
| `executive_priority_brief_ko.md` | Markdown | Executive Dashboard | Generated | 4 | Executive |
| `opportunity_radar_report_ko.md` | Markdown | Opportunity / Distress | Generated | 5 | Investment Team |
| `distress_watchlist_report_ko.md` | Markdown | Opportunity / Distress | Generated | 5 | Investment Team |
| `high_confidence_watchlist_report_ko.md` | Markdown | Quality Control | Generated | 4 | Executive |
| `la_asset_watch_report_ko.md` | Markdown | Deal / Asset Intelligence | Generated | 5 | US Local Team |
| `la_entitlement_watch_report_ko.md` | Markdown | Entitlement / Lifecycle Intelligence | Generated | 5 | US Local Team |
| `la_development_lifecycle_watch_report_ko.md` | Markdown | Entitlement / Lifecycle Intelligence | Generated | 4 | US Local Team |
| `gp_watchlist_report_ko.md` | Markdown | GP / Institutional Intelligence | Generated | 5 | Strategy Team |
| `korean_reporting_index.md` | Markdown | Strategy Briefing | Generated | 4 | Executive |
| `dashboard_summary.csv` | CSV | Executive Dashboard | Generated | 1 | Technical / Maintenance |
| `dashboard_cards.csv` | CSV | Executive Dashboard | Generated | 33 | Technical / Maintenance |
| `dashboard_watchlists.csv` | CSV | Executive Dashboard | Generated | 82 | Technical / Maintenance |
| `high_confidence_watchlist.csv` | CSV | Quality Control | Generated | 14 | Executive |
| `signal_quality.csv` | CSV | Quality Control | Generated | 85 | Strategy Team |
| `source_health.csv` | CSV | Source Management | Generated | 127 | Technical / Maintenance |
| `source_activation.csv` | CSV | Source Management | Generated | 127 | Technical / Maintenance |
| `source_health_report.md` | Markdown | Source Management | Generated | 9 | Technical / Maintenance |
| `source_activation_report.md` | Markdown | Source Management | Generated | 11 | Technical / Maintenance |
| `opportunity_radar.csv` | CSV | Opportunity / Distress | Generated | 26 | Investment Team |
| `distress_watchlist.csv` | CSV | Opportunity / Distress | Generated | 3 | Investment Team |
| `deal_pipeline.csv` | CSV | Deal / Asset Intelligence | Generated | 31 | Investment Team |
| `asset_parcel_intelligence.csv` | CSV | Deal / Asset Intelligence | Generated | 48 | Development Team |
| `la_asset_watch.csv` | CSV | Deal / Asset Intelligence | Generated | 28 | US Local Team |
| `project_identity.csv` | CSV | Deal / Asset Intelligence | Generated | 344 | Technical / Maintenance |
| `persistent_asset_memory.csv` | CSV | Historical Memory | Generated | 85 | Development Team |
| `la_persistent_asset_watch.csv` | CSV | Historical Memory | Generated | 51 | US Local Team |
| `entitlement_intelligence.csv` | CSV | Entitlement / Lifecycle Intelligence | Generated | 9 | Development Team |
| `la_entitlement_watch.csv` | CSV | Entitlement / Lifecycle Intelligence | Generated | 6 | US Local Team |
| `development_lifecycle.csv` | CSV | Entitlement / Lifecycle Intelligence | Generated | 48 | Development Team |
| `lifecycle_transition.csv` | CSV | Entitlement / Lifecycle Intelligence | Generated | 48 | Development Team |
| `timing_intelligence.csv` | CSV | Entitlement / Lifecycle Intelligence | Generated | 18 | Strategy Team |
| `market_entry_window.csv` | CSV | Strategy Briefing | Generated | 8 | Investment Team |
| `gp_watchlist.csv` | CSV | GP / Institutional Intelligence | Generated | 2 | Strategy Team |
| `gp_intelligence.csv` | CSV | GP / Institutional Intelligence | Generated | 2 | Strategy Team |
| `institutional_relationships.csv` | CSV | GP / Institutional Intelligence | Generated | 2 | Strategy Team |
| `relationship_graph.csv` | CSV | GP / Institutional Intelligence | Generated | 40 | Strategy Team |
| `regional_intelligence.csv` | CSV | Strategy Briefing | Generated | 13 | US Local Team |
| `residential_sector_intelligence.csv` | CSV | Strategy Briefing | Generated | 11 | Strategy Team |
| `historical_memory.csv` | CSV | Historical Memory | Generated | 129 | Strategy Team |
| `capital_flow_memory.csv` | CSV | Historical Memory | Generated | 30 | Finance / Treasury |
| `relationship_persistence.csv` | CSV | Historical Memory | Generated | 43 | Strategy Team |
| `pipeline_manifest.csv` | CSV | Quality Control | Generated | 56 | Technical / Maintenance |
| `pipeline_manifest.md` | Markdown | Quality Control | Generated | 3 | Technical / Maintenance |
| `pipeline_health.csv` | CSV | Quality Control | Generated | 133 | Technical / Maintenance |
| `pipeline_health_report.md` | Markdown | Quality Control | Generated | 6 | Technical / Maintenance |
| `error_log.csv` | CSV | Quality Control | Generated | 462 | Technical / Maintenance |
| `run_summary.md` | Markdown | Quality Control | Generated | 5 | Executive |