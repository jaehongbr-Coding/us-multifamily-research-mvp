# Executive Priority Brief

Generated: 2026-05-13 17:23:17

## Top 3 Executive Priorities

- Rank 1: Financing Stress (100, Tier 1 Executive Attention)
- Rank 2: Selective Capital Re-entry (100, Tier 1 Executive Attention)
- Rank 3: Supply Pressure (94, Tier 2 Strategic Review)

## Full Priority Table

| Rank | Regime | Score | Tier | Owner | Timing |
| ---: | --- | ---: | --- | --- | --- |
| 1 | Financing Stress | 100 | Tier 1 Executive Attention | Finance / Treasury; Investment Team; Executive Committee; US Local Team | This Week |
| 2 | Selective Capital Re-entry | 100 | Tier 1 Executive Attention | Investment Team; Strategy Team; Executive Committee; US Local Team | This Week |
| 3 | Supply Pressure | 94 | Tier 2 Strategic Review | Investment Team; Development Team; US Local Team | This Week |
| 4 | Developer Strategy Shift | 90 | Tier 2 Strategic Review | Strategy Team; Development Team; US Local Team | This Week |
| 5 | Construction Cost Pressure | 18 | Background | Development Team; Investment Team; US Local Team | Background Tracking |
| 6 | Policy / Entitlement Watch | 15 | Background | Development Team; US Local Team; Strategy Team | Background Tracking |

## Tier 1 Executive Attention

- Rank 1: Financing Stress (100). Debt market pressure should be reviewed because it may affect construction loan sizing, refinancing assumptions, and exit cap rates. Owner: Finance / Treasury; Investment Team; Executive Committee; US Local Team. Timing: This Week.
- Rank 2: Selective Capital Re-entry (100). Institutional capital movement should be tracked because it may indicate pricing discovery and partner activity. Owner: Investment Team; Strategy Team; Executive Committee; US Local Team. Timing: This Week.

## Tier 2 Strategic Review

- Rank 3: Supply Pressure (94). Supply and lease-up signals should be monitored because they may affect rent growth, vacancy, and development timing. Owner: Investment Team; Development Team; US Local Team. Timing: This Week.
- Rank 4: Developer Strategy Shift (90). Developer strategy signals should be reviewed because they may reveal capability needs in product, operations, partnerships, or delivery model. Owner: Strategy Team; Development Team; US Local Team. Timing: This Week.

## Monitoring Items

- Rank 5: Construction Cost Pressure (18). Construction cost signals should be reviewed because they may affect feasibility, contingencies, and value engineering. Owner: Development Team; Investment Team; US Local Team. Timing: Background Tracking.
- Rank 6: Policy / Entitlement Watch (15). Policy and entitlement signals should be monitored because they may affect approvals, zoning strategy, and local development feasibility. Owner: Development Team; US Local Team; Strategy Team. Timing: Background Tracking.

## Scenario Context

Base, Bull, and Bear planning scenarios are available in `strategy_scenario_report.md`.
Use that report to pressure-test the executive priorities against upside and downside market paths.

## Regional Considerations

Regional intelligence is available in `regional_intelligence_report.md`.
LA / California signals appear in the current data and should be reviewed for entitlement, zoning, underwriting, or market-entry implications.
Sun Belt, Texas, Southeast, or related growth-market signals appear in the current data and should be reviewed for supply, lease-up, and partnership implications.

## Recommended Management Agenda

- Review financing assumptions and debt sensitivity for the US residential development pipeline.
- Track institutional capital activity, pricing discovery, and potential GP or capital partner signals.
- Review supply pressure, lease-up, vacancy, concession, and rent-growth assumptions in relevant multifamily markets.
- Discuss developer capability priorities across BTR, modular construction, operations technology, and amenity strategy.
