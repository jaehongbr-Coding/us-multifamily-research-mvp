# LA / Southern California Submarket Watch Report

Generated: 2026-05-14 16:21:11

- Total LA / Southern California submarkets detected: 6

## Top LA / Southern California Submarkets

- Pasadena: opportunity 92, risk 52, Pasadena entitlement precedent watch.
- Wilshire: opportunity 63, risk 30, Koreatown multifamily watch.
- Lincoln Heights: opportunity 57, risk 30, Monitor only.
- Watts: opportunity 57, risk 30, Monitor only.
- Los Angeles: opportunity 50, risk 44, LA affordable / density bonus watch.
- Beverly Grove: opportunity 12, risk 30, Monitor only.

## Koreatown / Wilshire Watch

- Wilshire: opportunity 63, risk 30, Koreatown multifamily watch.

## DTLA / Adaptive Reuse Watch

- None detected.

## Hollywood / Transit-Oriented Watch

- None detected.

## Pasadena / Entitlement Precedent Watch

- Pasadena: opportunity 92, risk 52, Pasadena entitlement precedent watch.

## Long Beach / Mixed-Use Watch

- None detected.

## Orange County / Suburban Apartment Watch

- None detected.

## Inland Empire / BTR Watch

- None detected.

## LA Density Bonus / TOC Watch

- Los Angeles: opportunity 50, risk 44, LA affordable / density bonus watch.

## LA CEQA / Entitlement Risk Watch

- None detected.

## Recommended Local Follow-up Actions

- Track local planning docket and entitlement precedent: Pasadena / Pasadena entitlement precedent watch.
- Review potential acquisition pipeline: Wilshire / Koreatown multifamily watch.
- Review potential acquisition pipeline: Lincoln Heights / Monitor only.
- Review potential acquisition pipeline: Watts / Monitor only.
- Track local planning docket and entitlement precedent: Los Angeles / LA affordable / density bonus watch.
- Monitor only: Beverly Grove / Monitor only.

## Asset / Parcel Intelligence Reference

Asset / parcel-level site clues are available in `asset_parcel_intelligence_report.md` and `la_asset_watch_report.md`.



## Development Lifecycle Intelligence Summary

- Lifecycle records: 48
- LA lifecycle watch items: 29
- Stage mix: Site Acquisition / Site Control: 5, Vertical Construction: 3, Refinancing / Recapitalization: 4, Unknown Stage: 26, Delivery / Opening: 7
- See `development_lifecycle_report.md` and `la_development_lifecycle_watch_report.md` for project timing, entitlement, permit, construction, delivery, and refinancing stages.

