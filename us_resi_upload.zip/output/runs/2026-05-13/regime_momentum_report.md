# Regime Momentum Report

Generated: 2026-05-13 17:23:17

- Top regime by final_score: Selective Capital Re-entry (89)
- Second regime by final_score: Financing Stress (75)
- Dominant regime spread: 14

## Momentum Summary

| Regime | Previous Score | Latest Score | Change | Momentum |
| --- | ---: | ---: | ---: | --- |
| Selective Capital Re-entry | 86 | 89 | 3 | Stable |
| Financing Stress | 75 | 75 | 0 | Stable |
| Supply Pressure | 45 | 51 | 6 | Improving |
| Developer Strategy Shift | 48 | 48 | 0 | Stable |
| Policy / Entitlement Watch | 3 | 5 | 2 | Stable |
| Construction Cost Pressure | 3 | 3 | 0 | Stable |
| Stable Monitoring Environment | 0 | 0 | 0 | Stable |

## Concentration Interpretation

- The current regime picture is more concentrated because the top score is clearly ahead.

## Implications for Woomi / Woomi Global

- No regime is accelerating sharply, but strong current scores still deserve monitoring: Selective Capital Re-entry, Financing Stress.
