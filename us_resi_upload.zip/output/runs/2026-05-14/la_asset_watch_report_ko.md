# 한국어 LA 자산 / 프로젝트 Watch

- 생성 시각: 2026-05-14 16:21:11
- 참고 원문 파일: `la_asset_watch_report.md`
- 번역 방식: 규칙 기반 한국어 요약. OpenAI/GPT API는 호출하지 않음.

## LA / Southern California 자산 Watch

- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Los Angeles, 어포더블 하우징, 점수 100 (Unknown; Review parcel clue, entitlement path, sponsor, and comparable sites)
- General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts: Los Angeles, 어포더블 하우징, 점수 100 (Unknown; Review parcel clue, entitlement path, sponsor, and comparable sites)
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, 어포더블 하우징, 점수 100 (Unknown; Review parcel clue, entitlement path, sponsor, and comparable sites)
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Los Angeles, 아파트, 점수 100 (Delivered / Lease-Up; Review parcel clue, entitlement path, sponsor, and comparable sites)
- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: Los Angeles, 어포더블 하우징, 점수 99 (Unknown; Review parcel clue, entitlement path, sponsor, and comparable sites)
- General Project Signal - Other / Unknown - 22 homes pitched for 1072 E. Villa St. in Pasadena: Los Angeles, 아파트, 점수 91 (Unknown; Monitor asset for repeated local confirmation)
- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Los Angeles, 멀티패밀리, 점수 90 (Unknown; Track lender, maturity, owner, and recapitalization path)
- New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Los Angeles, 어포더블 하우징, 점수 90 (Unknown; Review parcel clue, entitlement path, sponsor, and comparable sites)
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, 어포더블 하우징, 점수 90 (Unknown; Review parcel clue, entitlement path, sponsor, and comparable sites)
- New look for affordable housing at 10304 S. Central Ave. in Watts: Los Angeles, 어포더블 하우징, 점수 90 (Site Search / Early Signal; Review parcel clue, entitlement path, sponsor, and comparable sites)

## 프로젝트 / 부지 단서

- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: 2155 E. Colorado Blvd, Los Angeles
- General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts: 10304 S. Central Ave, Los Angeles
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: 1321 N. Mission Rd, Los Angeles
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: 5700 Wilshire Blvd, Los Angeles
- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: 400 San Vicente Blvd, Los Angeles

## 인허가 / 개발 단계

- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Los Angeles, 아파트, 점수 95 (Unknown Stage; Monitor for repeated project updates)
- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: Los Angeles, 어포더블 하우징, 점수 94 (Unknown Stage; Monitor for repeated project updates)
- General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts: Los Angeles, 어포더블 하우징, 점수 94 (Unknown Stage; Monitor for repeated project updates)
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, 어포더블 하우징, 점수 94 (Unknown Stage; Monitor for repeated project updates)
- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Los Angeles, 어포더블 하우징, 점수 86 (Unknown Stage; Monitor for repeated project updates)

## 추천 현지 확인 사항

- 주소 단서, 스폰서, site control, 인허가 단계, financing signal을 함께 확인합니다.
