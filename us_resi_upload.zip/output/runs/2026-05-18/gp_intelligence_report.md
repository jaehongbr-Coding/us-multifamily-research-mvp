# GP / Developer Intelligence Report

Generated: 2026-05-18 16:30:54

## Top Institutional Signals

- Blackstone: acquisition; refinancing; JV / partnership; capital raise, New York, sources: Developer / GP Newsrooms, strength 84. potential JV partnership signal; monitor JV activity.
- Quarterra: acquisition; disposition / exit; operational technology / AI adoption, Los Angeles, sources: Core Multifamily News, strength 83. competitive pressure indicator; review LA / California development activity.
- Alliance Residential: acquisition, Sun Belt, sources: Site / Parcel Source Expansion, strength 63. benchmark underwriting assumptions; monitor only.

## Major GP Strategic Movements

- Blackstone: acquisition; refinancing; JV / partnership; capital raise, New York, sources: Developer / GP Newsrooms, strength 84. potential JV partnership signal; monitor JV activity.
- Quarterra: acquisition; disposition / exit; operational technology / AI adoption, Los Angeles, sources: Core Multifamily News, strength 83. competitive pressure indicator; review LA / California development activity.
- Alliance Residential: acquisition, Sun Belt, sources: Site / Parcel Source Expansion, strength 63. benchmark underwriting assumptions; monitor only.

## California / LA Developer Activity

- Quarterra: acquisition; disposition / exit; operational technology / AI adoption, Los Angeles, sources: Core Multifamily News, strength 83. competitive pressure indicator; review LA / California development activity.

## Sun Belt Expansion Watch

- Alliance Residential: acquisition, Sun Belt, sources: Site / Parcel Source Expansion, strength 63. benchmark underwriting assumptions; monitor only.

## BTR / Modular / Innovation Watch

- Quarterra: acquisition; disposition / exit; operational technology / AI adoption, Los Angeles, sources: Core Multifamily News, strength 83. competitive pressure indicator; review LA / California development activity.

## Distressed / Refinancing Watch

- Blackstone: acquisition; refinancing; JV / partnership; capital raise, New York, sources: Developer / GP Newsrooms, strength 84. potential JV partnership signal; monitor JV activity.

## Potential Partnership Signals

- Blackstone: acquisition; refinancing; JV / partnership; capital raise, New York, sources: Developer / GP Newsrooms, strength 84. potential JV partnership signal; monitor JV activity.

## Institutional Relationship Layer

Firm-tier weighting, capital-flow inference, and relationship scoring are available in `institutional_relationship_report.md`.

- Quarterra: Tier 3 / Growth and Market Signal Watch, Capital Inflow, GP Capability Benchmark Signal.
- Blackstone: Tier 1 / Immediate Strategic Importance, Capital Inflow, Potential JV / Partnership Signal.
- Alliance Residential: Tier 3 / Growth and Market Signal Watch, Capital Inflow, No Clear Relationship Signal.

## Deal / Project Pipeline Context

Deal and project extraction is available in `deal_pipeline_report.md`.
- Quarterra: Disposition / Exit, Los Angeles, Entitlement / zoning watch.
- Alliance Residential: Acquisition, Sun Belt, Monitor only.
- Blackstone: General Project Signal, New York, Monitor only.

## Relationship Graph Context

Developer and GP relationship edges are available in `relationship_graph_report.md`.
- Quarterra -> jll: Financing Relationship.
- Quarterra -> Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Disposition / Seller.
- Quarterra -> Los Angeles: Disposition / Seller.
- Quarterra -> Southern California: Disposition / Seller.
- Alliance Residential -> Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee: Acquisition / Buyer.

## Competitive Landscape Implications for Woomi

- Immediate Watch platforms may provide pricing discovery, capital-market sentiment, or competitive signals for Woomi.
- Partnership signals should be reviewed for possible GP relationship mapping.
- California / LA GP activity should be compared against Woomi's local entitlement and development strategy.

## Recommended Executive Follow-Up

- Blackstone: monitor JV activity
- Quarterra: review LA / California development activity
- Alliance Residential: monitor only
