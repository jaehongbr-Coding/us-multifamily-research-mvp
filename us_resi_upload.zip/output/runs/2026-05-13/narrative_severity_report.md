# Narrative Severity Report

Generated: 2026-05-13 17:23:17

- Top severity regime: Selective Capital Re-entry (100)
- Top conviction regime: Selective Capital Re-entry (100)

## Severity And Conviction Table

| Regime | Severity | Conviction | Urgency | Risk / Opportunity |
| --- | ---: | ---: | --- | --- |
| Selective Capital Re-entry | 100 | 100 | Immediate Attention | Opportunity / Pricing Signal |
| Financing Stress | 100 | 86 | Immediate Attention | Risk |
| Supply Pressure | 79 | 87 | Review This Week | Risk |
| Developer Strategy Shift | 73 | 92 | Review This Week | Opportunity / Capability Signal |
| Construction Cost Pressure | 10 | 12 | Background | Risk |
| Policy / Entitlement Watch | 9 | 10 | Background | Risk / Opportunity |

## Key Evidence

- Selective Capital Re-entry: supporting articles: 10; high-priority supporting articles: 8; supporting articles with extracted numbers: 9; momentum: Stable; Institutional Flow articles: 8; Deal Size Signal articles: 7; Institutional player mentions: 4
- Financing Stress: supporting articles: 8; high-priority supporting articles: 8; supporting articles with extracted numbers: 6; momentum: Stable; Financing Risk articles: 7; Financing/cap-rate market signals: 2; Financing matched-keyword articles: 7
- Supply Pressure: supporting articles: 6; high-priority supporting articles: 5; supporting articles with extracted numbers: 4; momentum: Improving; Supply Pressure articles: 2; Supply/vacancy/concession signals: 4; Supply matched-keyword articles: 2
- Developer Strategy Shift: supporting articles: 11; high-priority supporting articles: 10; supporting articles with extracted numbers: 5; momentum: Stable; Developer Strategy articles: 11; Developer matched-keyword articles: 1; Must Read articles: 10
- Construction Cost Pressure: supporting articles: 1; high-priority supporting articles: 1; supporting articles with extracted numbers: 1; momentum: Stable; Cost Control articles: 0; Construction Cost Signal articles: 0; Cost matched-keyword articles: 1
- Policy / Entitlement Watch: supporting articles: 1; high-priority supporting articles: 1; supporting articles with extracted numbers: 0; momentum: Stable; Regulation Risk articles: 0; Policy matched-keyword articles: 1; California / Los Angeles focus count: 1

## Implications for Woomi / Woomi Global

- Immediate Attention: track pricing discovery, acquisitions, GP partners, and institutional capital re-entry.
- Immediate Attention: tighten debt assumptions, refinancing sensitivity, and exit-cap underwriting.
- Review This Week: watch lease-up, vacancy, concessions, and starts before assuming rent-growth durability.

## Recommended Management Attention Items

### Immediate Attention

- Selective Capital Re-entry: severity 100, conviction 100.
- Financing Stress: severity 100, conviction 86.

### Review This Week

- Supply Pressure: severity 79, conviction 87.
- Developer Strategy Shift: severity 73, conviction 92.
