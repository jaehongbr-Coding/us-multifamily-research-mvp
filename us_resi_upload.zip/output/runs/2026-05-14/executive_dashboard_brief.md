# Executive Dashboard Brief

Generated: 2026-05-14 16:21:11

## Executive Snapshot

- Total articles reviewed: 43
- High-confidence signals: 14
- Institutional-grade signals: 4
- Opportunities: 26
- Distress signals: 3
- Recommended executive focus: Review Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village... and related high-confidence project signals.

## Top 5 Things to Review Today

- Berkadia (Capital Flow, Critical): Track capital flow pattern and related relationships.
- Blackstone (Capital Flow, Critical): Track capital flow pattern and related relationships.
- Blackstone (Capital Flow, Critical): Track capital flow pattern and related relationships.
- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena (LA Asset Watch, Critical): Review parcel clue, entitlement path, sponsor, and comparable sites.
- General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts (LA Asset Watch, Critical): Review parcel clue, entitlement path, sponsor, and comparable sites.

## Immediate Watch Items

- Berkadia: Stable Action: Track capital flow pattern and related relationships.
- Blackstone: Stable Action: Track capital flow pattern and related relationships.
- Blackstone: Stable Action: Track capital flow pattern and related relationships.
- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Benchmark density bonus use Action: Review parcel clue, entitlement path, sponsor, and comparable sites.
- General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts: Benchmark density bonus use Action: Review parcel clue, entitlement path, sponsor, and comparable sites.

## LA / California Watch

- Blackstone: Stable Action: Track capital flow pattern and related relationships.
- Blackstone: Stable Action: Track capital flow pattern and related relationships.
- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Benchmark density bonus use Action: Review parcel clue, entitlement path, sponsor, and comparable sites.
- General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts: Benchmark density bonus use Action: Review parcel clue, entitlement path, sponsor, and comparable sites.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Monitor only Action: Review parcel clue, entitlement path, sponsor, and comparable sites.

## GP / Capital Partner Watch

- Berkadia: Stable Action: Track capital flow pattern and related relationships.
- Blackstone: Stable Action: Track capital flow pattern and related relationships.
- Blackstone: Stable Action: Track capital flow pattern and related relationships.
- Crescent Communities: Institutional-backed regional expansion Action: Track JV and capital partner activity.
- Blackstone: Selective residential growth Action: Track JV and capital partner activity.

## Opportunity / Distress Watch

- JV / Partnership Gap: JV / Partnership Gap may create a pricing, capital, partnership, or pipeline opening in Sun Belt. Action: Map GP, capital partner, and relationship history.
- GP Capability Partnership Opportunity: GP Capability Partnership Opportunity may create a pricing, capital, partnership, or pipeline opening in New York. Action: Map GP, capital partner, and relationship history.
- Refinancing Gap: Refinancing Gap may create a pricing, capital, partnership, or pipeline opening in New York. Action: Track debt stack, maturity, lender, and recapitalization details.
- LA / California Entitlement Opportunity: LA / California Entitlement Opportunity may create a pricing, capital, partnership, or pipeline opening in Los Angeles. Action: Review entitlement, zoning, permitting, and local sponsor context.
- refinancing stress: Refinancing; refinancing Action: Track debt maturity, lender exposure, sponsor stress, and recapitalization options.

## Development Lifecycle Watch

- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Benchmark density bonus use Action: Review parcel clue, entitlement path, sponsor, and comparable sites.
- General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts: Benchmark density bonus use Action: Review parcel clue, entitlement path, sponsor, and comparable sites.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Monitor only Action: Review parcel clue, entitlement path, sponsor, and comparable sites.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Benchmark density bonus use Action: Review parcel clue, entitlement path, sponsor, and comparable sites.
- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: Monitor only Action: Review parcel clue, entitlement path, sponsor, and comparable sites.

## Capital Flow Watch

- Berkadia: Stable Action: Track capital flow pattern and related relationships.
- Blackstone: Stable Action: Track capital flow pattern and related relationships.
- Blackstone: Stable Action: Track capital flow pattern and related relationships.

## Source Health Notes

- Critical source validation warnings: 13 source(s) failed validation. Action: Review failed critical feeds and manual-review queue.

## Recommended Management Actions

- Track capital flow pattern and related relationships (capital_flow_report.md).
- Track capital flow pattern and related relationships (capital_flow_report.md).
- Track capital flow pattern and related relationships (capital_flow_report.md).
- Review parcel clue, entitlement path, sponsor, and comparable sites (la_asset_watch_report.md).
- Review parcel clue, entitlement path, sponsor, and comparable sites (la_asset_watch_report.md).


## Korean Report Reference

- Korean executive reports are available in `korean_reporting_index.md`.
- Start with `executive_dashboard_brief_ko.md` for a Korean executive briefing.

