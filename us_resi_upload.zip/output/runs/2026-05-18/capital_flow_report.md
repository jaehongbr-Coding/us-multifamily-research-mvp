# Capital Flow Memory Report

Generated: 2026-05-18 16:30:55

## Debt-Market Stress Summary

- Fannie Mae (Recurring Lender): Capital flow fading, 24 observation(s), importance 100.
- New York (Market-Level Capital Concentration): Capital flow fading, 30 observation(s), importance 100.

## Capital Migration Patterns

- Alliance Residential (Institutional Capital Flow): Stable capital pattern, 17 observation(s), importance 100.
- Blackstone (Recurring Capital Partner): Stable capital pattern, 43 observation(s), importance 100.
- Blackstone (Institutional Capital Flow): Stable capital pattern, 43 observation(s), importance 100.
- Crescent Communities (Institutional Capital Flow): Capital flow fading, 24 observation(s), importance 100.
- Quarterra (Institutional Capital Flow): Stable capital pattern, 19 observation(s), importance 100.

## Recurring Construction Lending Activity

- CBRE (Recurring Lender): Capital flow fading, 24 observation(s), importance 100.
- JLL (Recurring Lender): Stable capital pattern, 19 observation(s), importance 100.
- JLL (Recurring Lender): Stable capital pattern, 36 observation(s), importance 100.
- Los Angeles (Market-Level Capital Concentration): Stable capital pattern, 55 observation(s), importance 100.
- Los Angeles (Market-Level Capital Concentration): Stable capital pattern, 58 observation(s), importance 100.
- Other / Unknown (Market-Level Capital Concentration): Stable capital pattern, 91 observation(s), importance 100.
- Other / Unknown (Market-Level Capital Concentration): Stable capital pattern, 252 observation(s), importance 100.

## Agency Financing Patterns

- Fannie Mae (Recurring Lender): Capital flow fading, 24 observation(s), importance 100.

## Refinancing Hotspots

- Fannie Mae (Recurring Lender): Capital flow fading, 24 observation(s), importance 100.
- New York (Market-Level Capital Concentration): Capital flow fading, 30 observation(s), importance 100.

## Institutional Capital Concentration

- California (Market-Level Capital Concentration): Stable capital pattern, 19 observation(s), importance 100.
- California (Market-Level Capital Concentration): Capital flow fading, 22 observation(s), importance 100.
- California (Market-Level Capital Concentration): Stable capital pattern, 37 observation(s), importance 100.
- California (Market-Level Capital Concentration): Capital flow fading, 24 observation(s), importance 100.
- Florida (Market-Level Capital Concentration): Stable capital pattern, 19 observation(s), importance 100.
- Los Angeles (Market-Level Capital Concentration): Stable capital pattern, 19 observation(s), importance 100.
- Los Angeles (Market-Level Capital Concentration): Stable capital pattern, 55 observation(s), importance 100.
- Los Angeles (Market-Level Capital Concentration): Stable capital pattern, 62 observation(s), importance 100.
- Los Angeles (Market-Level Capital Concentration): Stable capital pattern, 134 observation(s), importance 100.
- Los Angeles (Market-Level Capital Concentration): Stable capital pattern, 58 observation(s), importance 100.

## Opportunity / Distress Radar

Opportunity radar is available in `opportunity_radar_report.md`.
Distress watchlist is available in `distress_watchlist_report.md`.
Canonical deal fingerprints are available in `deal_fingerprint_report.md`.
Opportunity deduplication is available in `opportunity_deduplication_report.md`.
Timing intelligence is available in `timing_intelligence_report.md`.
Market entry window scoring is available in `market_entry_window_report.md`.
