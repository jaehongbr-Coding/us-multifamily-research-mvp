# Emerging GP Ranking & Watchlist Report

Generated: 2026-05-14 16:21:11

- GP/developer candidates reviewed: 2
- Tier 1 Strategic GPs: 0
- Tier 2 High Potential GPs: 0

## Top Emerging GPs

- Crescent Communities: 66 (Tier 3 Monitoring GP), Sun Belt, Institutional-backed regional expansion.
- Blackstone: 58 (Tier 3 Monitoring GP), New York, Selective residential growth.

## Tier 1 Strategic GP

- No current GP signal detected.

## Tier 2 High Potential GP

- No current GP signal detected.

## California / LA GP Activity

- Crescent Communities: score 66, Tier 3 Monitoring GP, Sun Belt, Potential GP partnership candidate. Track JV and capital partner activity.

## BTR / SFR GP Activity

- No current GP signal detected.

## Affordable Housing GP Activity

- No current GP signal detected.

## Student Housing GP Activity

- No current GP signal detected.

## Innovation-Oriented GP Activity

- No current GP signal detected.

## Institutional Capital Magnet

- Crescent Communities: score 66, Tier 3 Monitoring GP, Sun Belt, Potential GP partnership candidate. Track JV and capital partner activity.
- Blackstone: score 58, Tier 3 Monitoring GP, New York, Potential GP partnership candidate. Track JV and capital partner activity.

## Potential Woomi Partnership Candidates

- Crescent Communities: score 66, Tier 3 Monitoring GP, Sun Belt, Potential GP partnership candidate. Track JV and capital partner activity.
- Blackstone: score 58, Tier 3 Monitoring GP, New York, Potential GP partnership candidate. Track JV and capital partner activity.

## GP Source Expansion Summary

Developer / GP source coverage is available in `gp_source_coverage_report.md`.
Use that report to identify missing GP, lender, BTR, student housing, and senior housing feeds that would improve this watchlist.

## Source Activation Summary

Validated source activation scoring is available in `source_activation_report.md`.
Use that report to prioritize working GP feeds and failed critical feeds before expanding the watchlist further.

## Historical Persistence Summary

Longitudinal GP and signal memory is available in `historical_memory_report.md`.
Capital-flow memory is available in `capital_flow_report.md`.
Recurring relationship tracking is available in `relationship_persistence_report.md`.

## Opportunity / Distress Radar

Opportunity radar is available in `opportunity_radar_report.md`.
Distress watchlist is available in `distress_watchlist_report.md`.
Canonical deal fingerprints are available in `deal_fingerprint_report.md`.
Opportunity deduplication is available in `opportunity_deduplication_report.md`.
Timing intelligence is available in `timing_intelligence_report.md`.
Market entry window scoring is available in `market_entry_window_report.md`.

## Recommended Management Meeting Targets

- Crescent Communities: Track JV and capital partner activity (Medium confidence).
- Blackstone: Track JV and capital partner activity (Medium confidence).

## Recommended Strategic Follow-up Actions

- Crescent Communities: Track JV and capital partner activity.
- Blackstone: Track JV and capital partner activity.



## Signal Quality / Confidence Summary

- Signals evaluated: 85
- Institutional-grade signals: 4
- High-confidence signals: 14
- Weak/noisy signals: 61
- High-confidence watchlist items: 14
- See `signal_quality_report.md` and `high_confidence_watchlist_report.md` before using signals for executive decisions.

