# LLM Prompt Pack for US Multifamily Strategy Analysis

Generated: 2026-05-13 17:23:17

## Instructions

This file prepares prompts for a future GPT-based analysis layer.
The current MVP does not call a paid LLM API.
Copy one prompt at a time into an LLM, or use this file later as input for an API workflow.

Prompt count: 22

## Prompt 1: The Market Data that Matters for the rest of 2026: A Chat with Zillow’s Chief Economist

- Quality score: 82
- Quality label: Good
- Missing context: missing extracted numbers; missing market signal

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: The Market Data that Matters for the rest of 2026: A Chat with Zillow’s Chief Economist
- Source: Multifamily Executive
- URL: https://www.multifamilyexecutive.com/premium/webinar/752676
- Market focus: National
- Strategic angle: Financing Risk; Rent Growth / Demand
- Market signal: No Clear Numeric Signal
- Extracted numbers: None detected
- Strategic implication: Monitor financing conditions because the article includes concession, concessions, construction and no specific number, which may affect construction loans, refinancing risk, and exit cap rates.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 2: JLL Worked on Behalf of Seller on $40.85M Sale of Multifamily Portfolio in New Haven Connecticut

- Quality score: 90
- Quality label: Excellent
- Missing context: missing market focus

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: JLL Worked on Behalf of Seller on $40.85M Sale of Multifamily Portfolio in New Haven Connecticut
- Source: Yield PRO
- URL: https://yieldpro.com/2026/05/traymore-apartments/
- Market focus: Other / Unknown
- Strategic angle: Institutional Flow
- Market signal: Deal Size Signal
- Extracted numbers: $40.85m; $20.6 million
- Strategic implication: Track this as institutional capital flow because it mentions major capital players, portfolio transactions, deal size, or cap-rate signals.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 3: Cushman & Wakefield and Greystone Close $20.8M FHA/HUD Loan for HELIO Apartments Refinance in Kearny New Jersey

- Quality score: 90
- Quality label: Excellent
- Missing context: missing market focus

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Cushman & Wakefield and Greystone Close $20.8M FHA/HUD Loan for HELIO Apartments Refinance in Kearny New Jersey
- Source: Yield PRO
- URL: https://yieldpro.com/2026/05/helio-apartments/
- Market focus: Other / Unknown
- Strategic angle: Financing Risk
- Market signal: Financing Cost Signal
- Extracted numbers: $20.8m; $20,766,500
- Strategic implication: Monitor financing conditions because the article includes apartment, apartments, cushman and $20.8m, $20,766,500, which may affect construction loans, refinancing risk, and exit cap rates.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 4: JLL Arranges $58M Refinancing for Newly Constructed Mixed-Use Multifamily Property in Brooklyn New York

- Quality score: 98
- Quality label: Excellent
- Missing context: None

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: JLL Arranges $58M Refinancing for Newly Constructed Mixed-Use Multifamily Property in Brooklyn New York
- Source: Yield PRO
- URL: https://yieldpro.com/2026/05/1333-broadway/
- Market focus: New York
- Strategic angle: Financing Risk; Institutional Flow; Developer Strategy
- Market signal: Deal Size Signal
- Extracted numbers: $58m; $58 million
- Strategic implication: Monitor financing conditions because the article includes capital markets, development, financing and $58m, $58 million, which may affect construction loans, refinancing risk, and exit cap rates.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 5: Multifamily CMBS maturities jumped to 7.71% in April: Trepp

- Quality score: 90
- Quality label: Excellent
- Missing context: missing market focus

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Multifamily CMBS maturities jumped to 7.71% in April: Trepp
- Source: Multifamily Dive
- URL: https://www.multifamilydive.com/news/multifamily-maturities-cmbs-debt-distress/820012/
- Market focus: Other / Unknown
- Strategic angle: Financing Risk; Institutional Flow
- Market signal: Financing Cost Signal
- Extracted numbers: 7.71%; 60%; 56 basis points
- Strategic implication: Monitor financing conditions because the article includes apartment, cmbs, debt and 7.71%, 60%, 56 basis points, which may affect construction loans, refinancing risk, and exit cap rates.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 6: Joint Venture Secure $68M Refinance for Suburban Denver Apartment Community

- Quality score: 90
- Quality label: Excellent
- Missing context: missing market focus

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Joint Venture Secure $68M Refinance for Suburban Denver Apartment Community
- Source: Yield PRO
- URL: https://yieldpro.com/2026/05/fillmore/
- Market focus: Other / Unknown
- Strategic angle: Financing Risk; Institutional Flow
- Market signal: Deal Size Signal
- Extracted numbers: $68m; $68.3 million
- Strategic implication: Monitor financing conditions because the article includes apartment, bridge loan, capital markets and $68m, $68.3 million, which may affect construction loans, refinancing risk, and exit cap rates.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 7: Housing Trust Group Breaks Ground on Affordable Housing Community for Serving Veterans and Military Families in Jacksonville

- Quality score: 82
- Quality label: Good
- Missing context: missing extracted numbers; missing market signal

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Housing Trust Group Breaks Ground on Affordable Housing Community for Serving Veterans and Military Families in Jacksonville
- Source: Yield PRO
- URL: https://yieldpro.com/2026/05/normandy-cove/
- Market focus: Florida
- Strategic angle: Financing Risk; Developer Strategy
- Market signal: No Clear Numeric Signal
- Extracted numbers: None detected
- Strategic implication: Monitor financing conditions because the article includes affordable housing, apartment, apartments and no specific number, which may affect construction loans, refinancing risk, and exit cap rates.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 8: Best Year for Missing Middle Construction Since 2007

- Quality score: 74
- Quality label: Good
- Missing context: missing extracted numbers; missing market focus; missing market signal

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Best Year for Missing Middle Construction Since 2007
- Source: NAHB Eye on Housing - Multifamily
- URL: https://eyeonhousing.org/2026/03/best-year-for-missing-middle-construction-since-2007/
- Market focus: Other / Unknown
- Strategic angle: Supply Pressure; Developer Strategy
- Market signal: No Clear Numeric Signal
- Extracted numbers: None detected
- Strategic implication: Review this as a supply risk signal because it references new deliveries, starts, pipeline, or permits in Other / Unknown.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 9: Missing Middle Weakness

- Quality score: 74
- Quality label: Good
- Missing context: missing extracted numbers; missing market focus; missing market signal

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Missing Middle Weakness
- Source: NAHB Eye on Housing - Multifamily
- URL: https://eyeonhousing.org/2026/01/missing-middle-weakness/
- Market focus: Other / Unknown
- Strategic angle: Supply Pressure; Developer Strategy
- Market signal: No Clear Numeric Signal
- Extracted numbers: None detected
- Strategic implication: Review this as a supply risk signal because it references new deliveries, starts, pipeline, or permits in Other / Unknown.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 10: Albion Residential Completes Construction on Luxury Apartments Albion Lawrenceville in Pittsburgh

- Quality score: 90
- Quality label: Excellent
- Missing context: missing market focus

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Albion Residential Completes Construction on Luxury Apartments Albion Lawrenceville in Pittsburgh
- Source: Yield PRO
- URL: https://yieldpro.com/2026/05/lawrenceville/
- Market focus: Other / Unknown
- Strategic angle: Developer Strategy
- Market signal: Supply / Starts Signal
- Extracted numbers: 267 units
- Strategic implication: Review this as a supply risk signal because it references new deliveries, starts, pipeline, or permits in Other / Unknown.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 11: Moinian Begins Manhattan Office-to-Residential Project

- Quality score: 82
- Quality label: Good
- Missing context: missing extracted numbers; missing market signal

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Moinian Begins Manhattan Office-to-Residential Project
- Source: Multi-Housing News
- URL: https://www.multihousingnews.com/moinian-begins-lower-manhattan-office-to-residential-project/
- Market focus: New York
- Strategic angle: Developer Strategy
- Market signal: No Clear Numeric Signal
- Extracted numbers: None detected
- Strategic implication: Review for developer strategy because the article may inform site selection, product type, adaptive reuse, build-to-rent, or market entry.
- Woomi relevance: Medium relevance to market monitoring

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 12: Multifamily Absorption Rate Remains Below 50%

- Quality score: 90
- Quality label: Excellent
- Missing context: missing market focus

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Multifamily Absorption Rate Remains Below 50%
- Source: NAHB Eye on Housing - Multifamily
- URL: https://eyeonhousing.org/2026/03/multifamily-absorption-rate-remains-below-50/
- Market focus: Other / Unknown
- Strategic angle: Rent Growth / Demand
- Market signal: Supply / Starts Signal
- Extracted numbers: 50%
- Strategic implication: Review this as a supply risk signal because it references new deliveries, starts, pipeline, or permits in Other / Unknown.
- Woomi relevance: Medium relevance to market monitoring

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 13: Shorter Apartment Construction Time in 2024

- Quality score: 74
- Quality label: Good
- Missing context: missing extracted numbers; missing market focus; missing market signal

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Shorter Apartment Construction Time in 2024
- Source: NAHB Eye on Housing - Multifamily
- URL: https://eyeonhousing.org/2025/10/shorter-apartment-construction-time-in-2024/
- Market focus: Other / Unknown
- Strategic angle: Developer Strategy
- Market signal: No Clear Numeric Signal
- Extracted numbers: None detected
- Strategic implication: Review for developer strategy because the article may inform site selection, product type, adaptive reuse, build-to-rent, or market entry.
- Woomi relevance: Medium relevance to market monitoring

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 14: Centralization Associated with Occupancy Uplift

- Quality score: 90
- Quality label: Excellent
- Missing context: missing market focus

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Centralization Associated with Occupancy Uplift
- Source: Multifamily Executive
- URL: https://www.multifamilyexecutive.com/resource/centralization-associated-occupancy-uplift
- Market focus: Other / Unknown
- Strategic angle: Rent Growth / Demand
- Market signal: Vacancy Signal
- Extracted numbers: 1.2%; 2%
- Strategic implication: Track rent and vacancy conditions because the article points to demand, occupancy, rent, vacancy, or concession signals in Other / Unknown.
- Woomi relevance: Medium relevance to market monitoring

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 15: San Fernando Valley Apartments Trade for $28M

- Quality score: 82
- Quality label: Good
- Missing context: missing market focus; missing market signal

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: San Fernando Valley Apartments Trade for $28M
- Source: Multi-Housing News
- URL: https://www.multihousingnews.com/san-fernando-valley-apartments-trade-for-28m/
- Market focus: Other / Unknown
- Strategic angle: Developer Strategy
- Market signal: No Clear Numeric Signal
- Extracted numbers: $28m
- Strategic implication: Review for developer strategy because the article may inform site selection, product type, adaptive reuse, build-to-rent, or market entry.
- Woomi relevance: Medium relevance to market monitoring

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 16: Senior Residents Living at Beacon House in Boston to See Improvements and Extension of Affordability with $26.4M in MassHousing Financing

- Quality score: 90
- Quality label: Excellent
- Missing context: missing market focus

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Senior Residents Living at Beacon House in Boston to See Improvements and Extension of Affordability with $26.4M in MassHousing Financing
- Source: Yield PRO
- URL: https://yieldpro.com/2026/05/beacon-house/
- Market focus: Other / Unknown
- Strategic angle: Financing Risk; Institutional Flow
- Market signal: Deal Size Signal
- Extracted numbers: $26.4m; $26.4 million
- Strategic implication: Monitor financing conditions because the article includes financing, joint venture, multifamily and $26.4m, $26.4 million, which may affect construction loans, refinancing risk, and exit cap rates.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 17: ECI, ApexOne Launch $500M Multifamily Fund

- Quality score: 90
- Quality label: Excellent
- Missing context: missing market signal

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: ECI, ApexOne Launch $500M Multifamily Fund
- Source: Multi-Housing News
- URL: https://www.multihousingnews.com/eci-apexone-launch-500m-multifamily-fund/
- Market focus: Sun Belt
- Strategic angle: Developer Strategy
- Market signal: No Clear Numeric Signal
- Extracted numbers: $500m
- Strategic implication: Review for developer strategy because the article may inform site selection, product type, adaptive reuse, build-to-rent, or market entry.
- Woomi relevance: Medium relevance to market monitoring

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 18: Kilroy Sells 2 Hollywood High-Rises for $202M

- Quality score: 98
- Quality label: Excellent
- Missing context: None

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Kilroy Sells 2 Hollywood High-Rises for $202M
- Source: Multi-Housing News
- URL: https://www.multihousingnews.com/kilroy-sells-two-hollywood-high-rises-for-202m/
- Market focus: Los Angeles
- Strategic angle: Institutional Flow
- Market signal: Deal Size Signal
- Extracted numbers: $202m
- Strategic implication: Track this as institutional capital flow because it mentions major capital players, portfolio transactions, deal size, or cap-rate signals.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 19: Why Senior Housing’s Recovery Is Gaining Traction

- Quality score: 74
- Quality label: Good
- Missing context: missing extracted numbers; missing market focus; missing market signal

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Why Senior Housing’s Recovery Is Gaining Traction
- Source: Multi-Housing News
- URL: https://www.multihousingnews.com/why-senior-housings-recovery-is-gaining-traction/
- Market focus: Other / Unknown
- Strategic angle: Developer Strategy
- Market signal: No Clear Numeric Signal
- Extracted numbers: None detected
- Strategic implication: Review for developer strategy because the article may inform site selection, product type, adaptive reuse, build-to-rent, or market entry.
- Woomi relevance: Medium relevance to market monitoring

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 20: DealPoint Merrill Obtains $55M for Mall Site Redevelopment

- Quality score: 90
- Quality label: Excellent
- Missing context: missing market focus

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: DealPoint Merrill Obtains $55M for Mall Site Redevelopment
- Source: Multi-Housing News
- URL: https://www.multihousingnews.com/dealpoint-merrill-obtains-55m-for-mall-site-redevelopment/
- Market focus: Other / Unknown
- Strategic angle: Developer Strategy
- Market signal: Supply / Starts Signal
- Extracted numbers: $55m
- Strategic implication: Review this as a supply risk signal because it references new deliveries, starts, pipeline, or permits in Other / Unknown.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 21: Guardian and PCCP Joint Venture Acquire 23-Story Multifamily Community Ladd Tower in Downtown Portland

- Quality score: 98
- Quality label: Excellent
- Missing context: None

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: Guardian and PCCP Joint Venture Acquire 23-Story Multifamily Community Ladd Tower in Downtown Portland
- Source: Yield PRO
- URL: https://yieldpro.com/2026/05/ladd-tower/
- Market focus: National
- Strategic angle: Institutional Flow
- Market signal: Deal Size Signal
- Extracted numbers: $63 million; $79 million
- Strategic implication: Track this as institutional capital flow because it mentions major capital players, portfolio transactions, deal size, or cap-rate signals.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```

## Prompt 22: ECI Group, ApexOne partner on $500M multifamily fund

- Quality score: 98
- Quality label: Excellent
- Missing context: None

```text
You are a strategic research analyst for Woomi / Woomi Global.
Analyze the following US multifamily housing article for developer strategy.

Article context:
- Title: ECI Group, ApexOne partner on $500M multifamily fund
- Source: Multifamily Dive
- URL: https://www.multifamilydive.com/news/value-add-fund-multifamily-investment-strategy/819624/
- Market focus: Florida
- Strategic angle: Institutional Flow
- Market signal: Deal Size Signal
- Extracted numbers: $500m
- Strategic implication: Track this as institutional capital flow because it mentions major capital players, portfolio transactions, deal size, or cap-rate signals.
- Woomi relevance: High relevance to US residential developer strategy

Please answer in concise bullet points:
1. Why does this article matter for a US multifamily developer?
2. What is the implication for Woomi / Woomi Global?
3. What risk or opportunity does this indicate?
4. What follow-up question should the strategy team ask?
```
