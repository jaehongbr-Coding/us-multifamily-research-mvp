# Regime Transition Report

Generated: 2026-05-14 16:21:12

## Summary

- Current primary regime: Developer Strategy Shift
- Previous primary regime: Developer Strategy Shift
- Regime changed: No
- Consecutive runs in current regime: 29
- Confidence direction: stable
- Market signals direction: stable
- Transition label: Persistent Regime

## Recent Regime History

| Run Timestamp | Primary Regime | Secondary Regime | Confidence | Market Signals | Top Strategic Angle | Top Market Focus | Top Market Signal |
| --- | --- | --- | --- | ---: | --- | --- | --- |
| 2026-05-14 15:41:34 | Developer Strategy Shift | None | High | 19 | Developer Strategy | Other / Unknown | Rent Growth Signal |
| 2026-05-14 15:59:16 | Developer Strategy Shift | None | High | 19 | Developer Strategy | Other / Unknown | Rent Growth Signal |
| 2026-05-14 16:03:03 | Developer Strategy Shift | None | High | 19 | Developer Strategy | Other / Unknown | Rent Growth Signal |
| 2026-05-14 16:18:01 | Developer Strategy Shift | None | High | 19 | Developer Strategy | Other / Unknown | Rent Growth Signal |
| 2026-05-14 16:21:11 | Developer Strategy Shift | None | High | 19 | Developer Strategy | Other / Unknown | Rent Growth Signal |

## Historical Persistence Summary

Regime and signal memory is available in `historical_memory_report.md`.
Capital-flow memory is available in `capital_flow_report.md`.
Recurring relationship tracking is available in `relationship_persistence_report.md`.

## Strategy Interpretation

- Developer Strategy Shift persistence may indicate changes in product strategy, partnerships, adaptive reuse, or delivery models.
- Market-signal volume is stable compared with the previous run.
