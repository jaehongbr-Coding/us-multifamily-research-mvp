# Executive Priority Brief

Generated: 2026-05-18 16:30:54

## Top 3 Executive Priorities

- Rank 1: Financing Stress (100, Tier 1 Executive Attention)
- Rank 2: Selective Capital Re-entry (100, Tier 1 Executive Attention)
- Rank 3: Supply Pressure (100, Tier 2 Strategic Review)

## Full Priority Table

| Rank | Regime | Score | Tier | Owner | Timing |
| ---: | --- | ---: | --- | --- | --- |
| 1 | Financing Stress | 100 | Tier 1 Executive Attention | Finance / Treasury; Investment Team; Executive Committee; US Local Team | This Week |
| 2 | Selective Capital Re-entry | 100 | Tier 1 Executive Attention | Investment Team; Strategy Team; Executive Committee; US Local Team | This Week |
| 3 | Supply Pressure | 100 | Tier 2 Strategic Review | Investment Team; Development Team; US Local Team | This Week |
| 4 | Developer Strategy Shift | 98 | Tier 2 Strategic Review | Strategy Team; Development Team; US Local Team | This Week |
| 5 | Policy / Entitlement Watch | 69 | Tier 3 Monitoring | Development Team; US Local Team; Strategy Team | Next IC / Strategy Meeting |
| 6 | Construction Cost Pressure | 9 | Background | Development Team; Investment Team; US Local Team | Background Tracking |

## Tier 1 Executive Attention

- Rank 1: Financing Stress (100). Debt market pressure should be reviewed because it may affect construction loan sizing, refinancing assumptions, and exit cap rates. Owner: Finance / Treasury; Investment Team; Executive Committee; US Local Team. Timing: This Week.
- Rank 2: Selective Capital Re-entry (100). Institutional capital movement should be tracked because it may indicate pricing discovery and partner activity. Owner: Investment Team; Strategy Team; Executive Committee; US Local Team. Timing: This Week.

## Tier 2 Strategic Review

- Rank 3: Supply Pressure (100). Supply and lease-up signals should be monitored because they may affect rent growth, vacancy, and development timing. Owner: Investment Team; Development Team; US Local Team. Timing: This Week.
- Rank 4: Developer Strategy Shift (98). Developer strategy signals should be reviewed because they may reveal capability needs in product, operations, partnerships, or delivery model. Owner: Strategy Team; Development Team; US Local Team. Timing: This Week.

## Monitoring Items

- Rank 5: Policy / Entitlement Watch (69). Policy and entitlement signals should be monitored because they may affect approvals, zoning strategy, and local development feasibility. Owner: Development Team; US Local Team; Strategy Team. Timing: Next IC / Strategy Meeting.
- Rank 6: Construction Cost Pressure (9). Construction cost signals should be reviewed because they may affect feasibility, contingencies, and value engineering. Owner: Development Team; Investment Team; US Local Team. Timing: Background Tracking.

## Scenario Context

Base, Bull, and Bear planning scenarios are available in `strategy_scenario_report.md`.
Use that report to pressure-test the executive priorities against upside and downside market paths.

## Regional Considerations

Regional intelligence is available in `regional_intelligence_report.md`.
LA / California signals appear in the current data and should be reviewed for entitlement, zoning, underwriting, or market-entry implications.
Sun Belt, Texas, Southeast, or related growth-market signals appear in the current data and should be reviewed for supply, lease-up, and partnership implications.

## GP / Developer Intelligence

Developer and GP platform intelligence is available in `gp_intelligence_report.md`.
- Blackstone: Immediate Watch, acquisition; refinancing; JV / partnership; capital raise, monitor JV activity.
- Quarterra: Immediate Watch, acquisition; disposition / exit; operational technology / AI adoption, review LA / California development activity.
- Alliance Residential: Strategic Watch, acquisition, monitor only.

## Institutional Relationship Context

Institutional relationship and capital-flow intelligence is available in `institutional_relationship_report.md`.
Use that report to compare GP partnership, pricing discovery, and capital partner tracking signals.

- Quarterra: GP Capability Benchmark Signal, Capital Inflow, score 99.
- Blackstone: Potential JV / Partnership Signal, Capital Inflow, score 88.
- Alliance Residential: No Clear Relationship Signal, Capital Inflow, score 81.

## Deal / Project Pipeline Context

Deal and project extraction is available in `deal_pipeline_report.md`.
- Disposition / Exit in Los Angeles: Entitlement / zoning watch (High Deal Intelligence).
- JV / Partnership in Sun Belt: Pricing benchmark (Useful Deal Signal).
- Construction Financing in Los Angeles: Capital market signal (Useful Deal Signal).

## Relationship Graph Context

Developer, lender, capital partner, market, and deal connections are available in `relationship_graph_report.md`.
- Quarterra -> jll: Financing Relationship (Relevant to LA / California strategy).
- Quarterra -> Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Disposition / Seller (Relevant to LA / California strategy).
- Quarterra -> Los Angeles: Disposition / Seller (Relevant to LA / California strategy).

## Residential Sector Coverage Context

Sector-level residential coverage is available in `residential_sector_report.md`.
- Affordable Housing: Track LA / California affordability, entitlement, and public-private partnership signals.
- Student Housing: Monitor university-market demand and partnership signals.
- BTR / Single-Family Rental: Monitor BTR / SFR operators, capital flows, and target markets.

## Emerging GP Watchlist Summary

Emerging GP ranking and partnership watchlist signals are available in `gp_watchlist_report.md`.
- Quarterra: Tier 2 High Potential GP, score 75, Capital market and pricing discovery reference.
- Blackstone: Tier 3 Monitoring GP, score 58, Potential GP partnership candidate.
- Alliance Residential: Emerging Watchlist, score 47, Capital market and pricing discovery reference.

## Historical Persistence Summary

Longitudinal memory is available in `historical_memory_report.md`.
Capital-flow memory is available in `capital_flow_report.md`.
Recurring relationship tracking is available in `relationship_persistence_report.md`.

## Opportunity / Distress Radar

Opportunity radar is available in `opportunity_radar_report.md`.
Distress watchlist is available in `distress_watchlist_report.md`.
Canonical deal fingerprints are available in `deal_fingerprint_report.md`.
Opportunity deduplication is available in `opportunity_deduplication_report.md`.
Timing intelligence is available in `timing_intelligence_report.md`.
Market entry window scoring is available in `market_entry_window_report.md`.
Entitlement intelligence is available in `entitlement_intelligence_report.md`.
LA entitlement watch is available in `la_entitlement_watch_report.md`.
Submarket intelligence is available in `submarket_intelligence_report.md`.
LA submarket watch is available in `la_submarket_watch_report.md`.

## Recommended Management Agenda

- Review financing assumptions and debt sensitivity for the US residential development pipeline.
- Track institutional capital activity, pricing discovery, and potential GP or capital partner signals.
- Review supply pressure, lease-up, vacancy, concession, and rent-growth assumptions in relevant multifamily markets.
- Discuss developer capability priorities across BTR, modular construction, operations technology, and amenity strategy.



## Development Lifecycle Intelligence Summary

- Lifecycle records: 54
- LA lifecycle watch items: 32
- Stage mix: Unknown Stage: 28, Vertical Construction: 4, Site Acquisition / Site Control: 8, Delivery / Opening: 9, Early Site Signal: 4
- See `development_lifecycle_report.md` and `la_development_lifecycle_watch_report.md` for project timing, entitlement, permit, construction, delivery, and refinancing stages.




## Lifecycle Transition Summary

- Lifecycle transitions analyzed: 54
- Newly detected projects: 0
- Forward progression projects: 0
- Possible stalled projects: 0
- LA lifecycle transition watch items: 30
- See `lifecycle_transition_report.md` and `la_lifecycle_transition_watch_report.md` for multi-run project movement and timing signals.




## Persistent Asset Memory Summary

- Raw project references: 405
- Canonical projects: 100
- Duplicate project clusters: 55
- Persistent assets tracked: 100
- LA persistent asset watch items: 65
- See `project_identity_report.md`, `persistent_asset_memory_report.md`, and `la_persistent_asset_watch_report.md` for canonical project tracking.




## Signal Quality / Confidence Summary

- Signals evaluated: 100
- Institutional-grade signals: 7
- High-confidence signals: 19
- Weak/noisy signals: 72
- High-confidence watchlist items: 19
- See `signal_quality_report.md` and `high_confidence_watchlist_report.md` before using signals for executive decisions.




## Dashboard Summary

- Dashboard cards: 35
- Dashboard watchlist items: 79
- Recommended focus: Review Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments and related high-confidence project signals.
- Start with `executive_dashboard_brief.md`, then review `dashboard_cards.csv` and `dashboard_watchlists.csv` for future dashboard inputs.

