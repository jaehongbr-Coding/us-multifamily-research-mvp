# Entitlement Intelligence Report

Generated: 2026-05-18 16:30:55

- Total entitlement signals detected: 4

## Top Entitlement Opportunities

- Entitlement Approval in Unknown: Unknown Stage, entitlement_opportunity_score 48. Track construction-ready pipeline and comparable sponsor execution.
- Entitlement Approval in L.A.: Early Planning, entitlement_opportunity_score 45. Track local planning filings, approval body, sponsor, and entitlement precedent.
- Entitlement Approval in Los Angeles: Unknown Stage, entitlement_opportunity_score 45. Track local planning filings, approval body, sponsor, and entitlement precedent.
- Entitlement Approval in Unknown: Unknown Stage, entitlement_opportunity_score 30. Track construction-ready pipeline and comparable sponsor execution.

## Top Entitlement Risks

- Entitlement Approval in Los Angeles: Unknown Stage, entitlement_risk_score 38. Track local planning filings, approval body, sponsor, and entitlement precedent.
- Entitlement Approval in Unknown: Unknown Stage, entitlement_risk_score 28. Track construction-ready pipeline and comparable sponsor execution.
- Entitlement Approval in Unknown: Unknown Stage, entitlement_risk_score 28. Track construction-ready pipeline and comparable sponsor execution.
- Entitlement Approval in L.A.: Early Planning, entitlement_risk_score 20. Track local planning filings, approval body, sponsor, and entitlement precedent.

## Planning / Approval Signals

- Entitlement Approval in Unknown: Unknown Stage, entitlement_opportunity_score 48. Track construction-ready pipeline and comparable sponsor execution.
- Entitlement Approval in L.A.: Early Planning, entitlement_opportunity_score 45. Track local planning filings, approval body, sponsor, and entitlement precedent.
- Entitlement Approval in Los Angeles: Unknown Stage, entitlement_opportunity_score 45. Track local planning filings, approval body, sponsor, and entitlement precedent.
- Entitlement Approval in Unknown: Unknown Stage, entitlement_opportunity_score 30. Track construction-ready pipeline and comparable sponsor execution.

## Density Bonus / TOC Signals

- None detected.

## CEQA / Environmental Review Signals

- None detected.

## Affordable Housing Requirement Signals

- Entitlement Approval in Los Angeles: Unknown Stage, entitlement_opportunity_score 45. Track local planning filings, approval body, sponsor, and entitlement precedent.

## Office-to-Residential Conversion Signals

- None detected.

## Implications for Woomi / Woomi Global

- Entitlement intelligence helps track project approval precedent, local policy risk, and construction-ready pipeline timing.
- LA / California signals should feed site strategy, sponsor mapping, and entitlement-risk assumptions.
- Submarket-level site strategy detail is available in `submarket_intelligence_report.md` and `la_submarket_watch_report.md`.

## Recommended Entitlement Follow-up Actions

- Track construction-ready pipeline and comparable sponsor execution: Entitlement Approval in Unknown.
- Track local planning filings, approval body, sponsor, and entitlement precedent: Entitlement Approval in L.A..
- Track local planning filings, approval body, sponsor, and entitlement precedent: Entitlement Approval in Los Angeles.
- Track construction-ready pipeline and comparable sponsor execution: Entitlement Approval in Unknown.



## Development Lifecycle Intelligence Summary

- Lifecycle records: 54
- LA lifecycle watch items: 32
- Stage mix: Unknown Stage: 28, Vertical Construction: 4, Site Acquisition / Site Control: 8, Delivery / Opening: 9, Early Site Signal: 4
- See `development_lifecycle_report.md` and `la_development_lifecycle_watch_report.md` for project timing, entitlement, permit, construction, delivery, and refinancing stages.

