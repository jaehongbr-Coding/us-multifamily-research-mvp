# Timing Intelligence Report

Generated: 2026-05-14 16:21:11

- Total timing signals detected: 18

## Top Timing Signals

- Entitlement / Permitting in Other / Unknown: in 2024, score 78, Weekly monitoring. Track entitlement, zoning, permitting, and public-agency milestones.
- Entitlement / Permitting in Los Angeles: No explicit timing reference, score 73, Biweekly monitoring. Track entitlement, zoning, permitting, and public-agency milestones.
- Construction Completion / Delivery in Los Angeles: No explicit timing reference, score 71, Biweekly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Refinancing / Maturity Window in New York: No explicit timing reference, score 71, Biweekly monitoring. Track maturity, refinancing options, lender appetite, and recapitalization timing.
- Construction Start in Other / Unknown: 2025, score 70, Weekly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Construction Start in Other / Unknown: in 2025, score 70, Weekly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Construction Start in Other / Unknown: 2025, score 70, Weekly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Entitlement / Permitting in Other / Unknown: No explicit timing reference, score 64, Monthly monitoring. Track entitlement, zoning, permitting, and public-agency milestones.
- Construction Start in National: No explicit timing reference, score 63, Monthly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Entitlement / Permitting in California: No explicit timing reference, score 62, Monthly monitoring. Track entitlement, zoning, permitting, and public-agency milestones.

## Refinancing / Maturity Timing Watch

- Refinancing / Maturity Window in New York: No explicit timing reference, score 71, Biweekly monitoring. Track maturity, refinancing options, lender appetite, and recapitalization timing.

## Construction Start / Delivery Watch

- Construction Completion / Delivery in Los Angeles: No explicit timing reference, score 71, Biweekly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Construction Start in Other / Unknown: 2025, score 70, Weekly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Construction Start in Other / Unknown: in 2025, score 70, Weekly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Construction Start in Other / Unknown: 2025, score 70, Weekly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Construction Start in National: No explicit timing reference, score 63, Monthly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Construction Start in Other / Unknown: No explicit timing reference, score 58, Monthly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Construction Completion / Delivery in Other / Unknown: No explicit timing reference, score 53, Monthly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.

## Entitlement / Permitting Timing Watch

- Entitlement / Permitting in Other / Unknown: in 2024, score 78, Weekly monitoring. Track entitlement, zoning, permitting, and public-agency milestones.
- Entitlement / Permitting in Los Angeles: No explicit timing reference, score 73, Biweekly monitoring. Track entitlement, zoning, permitting, and public-agency milestones.
- Entitlement / Permitting in Other / Unknown: No explicit timing reference, score 64, Monthly monitoring. Track entitlement, zoning, permitting, and public-agency milestones.
- Entitlement / Permitting in California: No explicit timing reference, score 62, Monthly monitoring. Track entitlement, zoning, permitting, and public-agency milestones.
- Entitlement / Permitting in Other / Unknown: No explicit timing reference, score 50, Monthly monitoring. Track entitlement, zoning, permitting, and public-agency milestones.

## Acquisition / Capital Re-entry Timing Watch

- Acquisition Window in Other / Unknown: No explicit timing reference, score 45, Monitor Only monitoring. Monitor pricing evidence and possible acquisition outreach timing.

## LA / California Timing Signals

- Entitlement / Permitting in Los Angeles: No explicit timing reference, score 73, Biweekly monitoring. Track entitlement, zoning, permitting, and public-agency milestones.
- Construction Completion / Delivery in Los Angeles: No explicit timing reference, score 71, Biweekly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Entitlement / Permitting in California: No explicit timing reference, score 62, Monthly monitoring. Track entitlement, zoning, permitting, and public-agency milestones.

## BTR / SFR Timing Signals

- BTR / SFR Expansion Timing in National: No explicit timing reference, score 50, Monthly monitoring. Monitor sector-specific platform timing and potential partnership relevance.

## Recommended Monitoring Cadence

- Monthly: 10 timing signal(s)
- Weekly: 4 timing signal(s)
- Biweekly: 3 timing signal(s)
- Monitor Only: 1 timing signal(s)

## Implications for Woomi / Woomi Global

- Timing intelligence helps separate immediate watch items from longer-cycle monitoring items.
- Refinancing, entitlement, delivery, and capital re-entry timing should feed weekly strategy and sourcing cadence decisions.
- Permit and entitlement detail is available in `entitlement_intelligence_report.md` and `la_entitlement_watch_report.md`.



## Development Lifecycle Intelligence Summary

- Lifecycle records: 48
- LA lifecycle watch items: 29
- Stage mix: Site Acquisition / Site Control: 5, Vertical Construction: 3, Refinancing / Recapitalization: 4, Unknown Stage: 26, Delivery / Opening: 7
- See `development_lifecycle_report.md` and `la_development_lifecycle_watch_report.md` for project timing, entitlement, permit, construction, delivery, and refinancing stages.




## Lifecycle Transition Summary

- Lifecycle transitions analyzed: 48
- Newly detected projects: 0
- Forward progression projects: 0
- Possible stalled projects: 0
- LA lifecycle transition watch items: 26
- See `lifecycle_transition_report.md` and `la_lifecycle_transition_watch_report.md` for multi-run project movement and timing signals.

