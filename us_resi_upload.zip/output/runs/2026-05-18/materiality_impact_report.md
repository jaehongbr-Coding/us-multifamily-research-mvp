# Materiality / Impact Report

Generated: 2026-05-18 16:30:54

- Top materiality regime: Developer Strategy Shift (100)
- Top impact regime: Developer Strategy Shift (100)

## Materiality And Impact Table

| Regime | Materiality | Impact | Impact Label | Business Area Impact | Recommended Action |
| --- | ---: | ---: | --- | --- | --- |
| Developer Strategy Shift | 100 | 100 | Critical Business Impact | GP Partnership; Cost Management; Leasing / Operations; Strategic Monitoring; LA / California Strategy | Add to weekly strategy memo |
| Financing Stress | 100 | 100 | Critical Business Impact | Underwriting; Financing; Capital Markets; LA / California Strategy | Tighten underwriting assumptions |
| Selective Capital Re-entry | 100 | 100 | Critical Business Impact | GP Partnership; Capital Markets; Strategic Monitoring; LA / California Strategy | Track capital partner activity |
| Supply Pressure | 100 | 100 | Critical Business Impact | Underwriting; Land / Pipeline; Leasing / Operations; LA / California Strategy | Review supply pipeline assumptions |
| Policy / Entitlement Watch | 86 | 74 | High Business Impact | Land / Pipeline; LA / California Strategy; Strategic Monitoring | Monitor LA / California entitlement changes |
| Construction Cost Pressure | 2 | 17 | Low Business Impact | Underwriting; Cost Management; LA / California Strategy | Review construction cost assumptions |

## Key Business Risks / Opportunities

- Developer Strategy Shift: Changes in developer strategy may reveal capability gaps or opportunities in BTR, modular, technology, and product design.
- Financing Stress: Debt cost and credit availability may affect construction loan sizing, refinancing assumptions, and exit cap rates.
- Selective Capital Re-entry: Institutional capital re-entry may provide pricing discovery and GP partnership signals.
- Supply Pressure: New supply, concessions, and vacancy pressure may affect lease-up assumptions and rent growth underwriting.
- Policy / Entitlement Watch: Entitlement, zoning, permitting, or housing policy changes may create both approval risk and development opportunity.
- Construction Cost Pressure: Labor, materials, and construction cost pressure may affect feasibility, contingencies, and value engineering.

## Implications for Woomi / Woomi Global

- Critical impact regimes should be discussed in management review before major underwriting, capital partner, or pipeline decisions.
- Financing Stress has elevated business impact, so debt sizing, refinancing, and exit-cap assumptions should be revisited.
- Selective Capital Re-entry has elevated impact, so GP partner tracking and institutional pricing signals deserve attention.
- LA / California strategy appears in elevated-impact regimes, so local entitlement and market monitoring should stay active.

## Recommended Management Actions

- Developer Strategy Shift: Add to weekly strategy memo (Critical Business Impact).
- Financing Stress: Tighten underwriting assumptions (Critical Business Impact).
- Selective Capital Re-entry: Track capital partner activity (Critical Business Impact).
- Supply Pressure: Review supply pipeline assumptions (Critical Business Impact).
- Policy / Entitlement Watch: Monitor LA / California entitlement changes (High Business Impact).
