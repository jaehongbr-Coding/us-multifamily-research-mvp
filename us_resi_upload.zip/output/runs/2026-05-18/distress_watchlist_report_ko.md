# 한국어 스트레스 / 부실 Watchlist

- 생성 시각: 2026-05-18 16:30:54
- 참고 원문 파일: `distress_watchlist_report.md`
- 번역 방식: 규칙 기반 한국어 요약. OpenAI/GPT API는 호출하지 않음.

## 리파이낸싱 압박

- 해당 신호 없음

## 공사금융 갭

- construction loan gap: Los Angeles, 주거복합, 점수 69 (Track debt maturity, lender exposure, sponsor stress, and recapitalization options)
- construction loan gap: Los Angeles, 일반 주거, 점수 68 (Track debt maturity, lender exposure, sponsor stress, and recapitalization options)
- construction loan gap: 기타 / 미확인, 어포더블 하우징, 점수 56 (Monitor for repeated distress signals)
- construction loan gap: 기타 / 미확인, 멀티패밀리, 점수 56 (Monitor for repeated distress signals)

## 부실 / 지연 프로젝트

- construction loan gap: Los Angeles, 주거복합, 점수 69 (High Distress Watch)
- construction loan gap: Los Angeles, 일반 주거, 점수 68 (High Distress Watch)
- construction loan gap: 기타 / 미확인, 어포더블 하우징, 점수 56 (Monitor)
- construction loan gap: 기타 / 미확인, 멀티패밀리, 점수 56 (Monitor)

## 우미 관점 기회 가능성

- 부실 신호는 단순 위기보다 가격 조정, rescue capital, JV gap 가능성 관점에서 확인합니다.
