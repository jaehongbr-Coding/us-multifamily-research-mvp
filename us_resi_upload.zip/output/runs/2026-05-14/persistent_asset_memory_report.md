# Persistent Asset Memory Report

Generated: 2026-05-14 16:21:12

- Total persistent assets tracked: 85
- Newly detected assets: 65
- Progressing assets: 0
- Possible stalled assets: 4

## Highest Priority Asset Watch Items

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Priority Asset Watch, Refinancing / Recapitalization, score 89.
- Disposition / Exit - Other / Unknown - Marcus & Millichap Arranges Sale of 64-Unit Multifamily Property Waterview Apartments in L...: Priority Asset Watch, Delivery / Opening, score 85.
- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: Priority Asset Watch, Site Acquisition / Site Control, score 85.
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: Priority Asset Watch, Unknown Stage, score 80.
- Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek in West Nashville.: Priority Asset Watch, Site Acquisition / Site Control, score 78.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Priority Asset Watch, Vertical Construction, score 77.
- BTR / Build-to-Rent - National - Trump Pushes House To Pass Housing Bill With BTR Forced-Sale Provision: Strategic Asset Watch, Vertical Construction, score 71.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: Strategic Asset Watch, Refinancing / Recapitalization, score 69.
- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco: Strategic Asset Watch, Unknown Stage, score 68.
- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco: Strategic Asset Watch, Unknown Stage, score 68.

## Assets With Repeated Financing Signals

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Priority Asset Watch, Refinancing / Recapitalization, score 89.
- Disposition / Exit - Other / Unknown - Marcus & Millichap Arranges Sale of 64-Unit Multifamily Property Waterview Apartments in L...: Priority Asset Watch, Delivery / Opening, score 85.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: Strategic Asset Watch, Refinancing / Recapitalization, score 69.
- Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal...: Strategic Asset Watch, Refinancing / Recapitalization, score 67.
- Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal...: Strategic Asset Watch, Delivery / Opening, score 67.
- Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal...: Strategic Asset Watch, Unknown Stage, score 64.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: Strategic Asset Watch, Unknown Stage, score 60.
- CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Caldwell New Jersey: General Asset Monitoring, Unknown Stage, score 48.
- Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village in Central Islip New York: Low Priority, Unknown Stage, score 26.
- Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village in Central Islip New York: Low Priority, Unknown Stage, score 26.

## Assets With Repeated Entitlement Signals

- Disposition / Exit - Other / Unknown - Marcus & Millichap Arranges Sale of 64-Unit Multifamily Property Waterview Apartments in L...: Priority Asset Watch, Delivery / Opening, score 85.
- Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek in West Nashville.: Priority Asset Watch, Site Acquisition / Site Control, score 78.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Priority Asset Watch, Vertical Construction, score 77.
- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco: Strategic Asset Watch, Unknown Stage, score 68.
- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco: Strategic Asset Watch, Unknown Stage, score 68.
- Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal...: Strategic Asset Watch, Refinancing / Recapitalization, score 67.
- Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal...: Strategic Asset Watch, Delivery / Opening, score 67.
- Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal...: Strategic Asset Watch, Unknown Stage, score 64.
- Crypto rewards eye renters who want to save for a down payment: Strategic Asset Watch, Unknown Stage, score 64.
- Swedish Investor Selling 1,500-Unit Northern Virginia Portfolio: Strategic Asset Watch, Unknown Stage, score 64.

## Recurring Asset Signals

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Priority Asset Watch, Refinancing / Recapitalization, score 89.
- Disposition / Exit - Other / Unknown - Marcus & Millichap Arranges Sale of 64-Unit Multifamily Property Waterview Apartments in L...: Priority Asset Watch, Delivery / Opening, score 85.
- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: Priority Asset Watch, Site Acquisition / Site Control, score 85.
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: Priority Asset Watch, Unknown Stage, score 80.
- Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek in West Nashville.: Priority Asset Watch, Site Acquisition / Site Control, score 78.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Priority Asset Watch, Vertical Construction, score 77.
- BTR / Build-to-Rent - National - Trump Pushes House To Pass Housing Bill With BTR Forced-Sale Provision: Strategic Asset Watch, Vertical Construction, score 71.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: Strategic Asset Watch, Refinancing / Recapitalization, score 69.
- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco: Strategic Asset Watch, Unknown Stage, score 68.
- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco: Strategic Asset Watch, Unknown Stage, score 68.

## Implications for Woomi / Woomi Global

- Persistent asset memory helps convert article flow into a durable watchlist of recurring projects, sponsors, lifecycle stages, and risk signals.
- High-scoring assets should be reviewed for potential site precedent, GP outreach, underwriting comparables, or timing windows.

## Recommended Asset Memory Follow-up

- Create or refresh a project watch file with sponsor, site, entitlement, financing, and timing notes: Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village....
- Create or refresh a project watch file with sponsor, site, entitlement, financing, and timing notes: Disposition / Exit - Other / Unknown - Marcus & Millichap Arranges Sale of 64-Unit Multifamily Property Waterview Apartments in L....
- Create or refresh a project watch file with sponsor, site, entitlement, financing, and timing notes: JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek....
- Create or refresh a project watch file with sponsor, site, entitlement, financing, and timing notes: Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America.
- Create or refresh a project watch file with sponsor, site, entitlement, financing, and timing notes: Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek in West Nashville..
- Create or refresh a project watch file with sponsor, site, entitlement, financing, and timing notes: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.
- Benchmark construction, delivery, lease-up, and operating assumptions: BTR / Build-to-Rent - National - Trump Pushes House To Pass Housing Bill With BTR Forced-Sale Provision.
- Monitor for repeated project updates: General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl....



## Signal Quality / Confidence Summary

- Signals evaluated: 85
- Institutional-grade signals: 4
- High-confidence signals: 14
- Weak/noisy signals: 61
- High-confidence watchlist items: 14
- See `signal_quality_report.md` and `high_confidence_watchlist_report.md` before using signals for executive decisions.

