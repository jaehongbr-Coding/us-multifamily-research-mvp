# 한국어 LA / California 인허가 Watch

- 생성 시각: 2026-05-18 16:30:54
- 참고 원문 파일: `la_entitlement_watch_report.md`
- 번역 방식: 규칙 기반 한국어 요약. OpenAI/GPT API는 호출하지 않음.

## LA / California 인허가 Watch

- Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave.: Los Angeles, 어포더블 하우징, 점수 65 (Unknown Stage; Track local planning docket, sponsor, submarket, and entitlement precedent)
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: L.A., 주거복합, 점수 61 (Early Planning; Track local planning docket, sponsor, submarket, and entitlement precedent)

## Density Bonus / TOC

- 해당 신호 없음

## CEQA / Environmental Review

- 해당 신호 없음

## Planning / Permit Signals

- 해당 신호 없음
