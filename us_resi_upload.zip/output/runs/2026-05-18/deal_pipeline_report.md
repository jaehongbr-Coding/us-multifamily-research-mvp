# Deal & Project Pipeline Report

Generated: 2026-05-18 16:30:55

- Total deal/project signals found: 39
- High deal intelligence count: 1

## Top 10 Deal / Project Signals

- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Disposition / Exit, Los Angeles, score 89. Entitlement / zoning watch.
- JV / Partnership - Sun Belt - CFAM, RPM Living Acquire 380-Unit Waterfront Multifamily Community in North Miami: JV / Partnership, Sun Belt, score 74. Pricing benchmark.
- Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles: Construction Financing, Los Angeles, score 73. Capital market signal.
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: Entitlement / Permitting, Los Angeles, score 73. Entitlement / zoning watch.
- Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave.: Entitlement / Permitting, Los Angeles, score 73. Capital market signal.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: General Project Signal, Los Angeles, score 73. Capital market signal.
- Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades: Construction Financing, Los Angeles, score 70. Capital market signal.
- BTR / Build-to-Rent - Los Angeles - Core Spaces Secures $1.64B Fundraise for Student Housing Development, Investment: BTR / Build-to-Rent, Los Angeles, score 69. Pipeline / supply signal.
- Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee: Acquisition, Sun Belt, score 67. Monitor only.
- Construction Financing - Other / Unknown - Cypress Equity Investments gets $170M loan for two Santa Monica projects: Construction Financing, Other / Unknown, score 65. Capital market signal.

## California / LA Deal Watch

- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Disposition / Exit, Los Angeles, score 89. Entitlement / zoning watch.
- Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles: Construction Financing, Los Angeles, score 73. Capital market signal.
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: Entitlement / Permitting, Los Angeles, score 73. Entitlement / zoning watch.
- Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave.: Entitlement / Permitting, Los Angeles, score 73. Capital market signal.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: General Project Signal, Los Angeles, score 73. Capital market signal.
- Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades: Construction Financing, Los Angeles, score 70. Capital market signal.
- BTR / Build-to-Rent - Los Angeles - Core Spaces Secures $1.64B Fundraise for Student Housing Development, Investment: BTR / Build-to-Rent, Los Angeles, score 69. Pipeline / supply signal.
- General Project Signal - California - Metro partners with developer on plans for housing at G Line's Balboa Station: General Project Signal, California, score 63. Entitlement / zoning watch.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: General Project Signal, Los Angeles, score 63. Entitlement / zoning watch.
- Disposition / Exit - California - Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale: Disposition / Exit, California, score 60. Entitlement / zoning watch.

## GP / Developer Activity

- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Disposition / Exit, Los Angeles, score 89. Entitlement / zoning watch.
- Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee: Acquisition, Sun Belt, score 67. Monitor only.
- General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve...: General Project Signal, New York, score 48. Monitor only.

## Financing / Refinancing Signals

- Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles: Construction Financing, Los Angeles, score 73. Capital market signal.
- Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave.: Entitlement / Permitting, Los Angeles, score 73. Capital market signal.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: General Project Signal, Los Angeles, score 73. Capital market signal.
- Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades: Construction Financing, Los Angeles, score 70. Capital market signal.
- Construction Financing - Other / Unknown - Cypress Equity Investments gets $170M loan for two Santa Monica projects: Construction Financing, Other / Unknown, score 65. Capital market signal.
- Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC...: Construction Financing, Other / Unknown, score 63. Capital market signal.

## Project Pipeline / Supply Signals

- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Disposition / Exit, Los Angeles, score 89. Entitlement / zoning watch.
- JV / Partnership - Sun Belt - CFAM, RPM Living Acquire 380-Unit Waterfront Multifamily Community in North Miami: JV / Partnership, Sun Belt, score 74. Pricing benchmark.
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: Entitlement / Permitting, Los Angeles, score 73. Entitlement / zoning watch.
- Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave.: Entitlement / Permitting, Los Angeles, score 73. Capital market signal.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: General Project Signal, Los Angeles, score 73. Capital market signal.
- Construction Financing - Other / Unknown - Cypress Equity Investments gets $170M loan for two Santa Monica projects: Construction Financing, Other / Unknown, score 65. Capital market signal.
- Acquisition - Other / Unknown - Guardian Acquires 332-Unit Ladd Tower Apartment Building in Downtown Portland: Acquisition, Other / Unknown, score 63. Underwriting benchmark.
- General Project Signal - California - Metro partners with developer on plans for housing at G Line's Balboa Station: General Project Signal, California, score 63. Entitlement / zoning watch.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: General Project Signal, Los Angeles, score 63. Entitlement / zoning watch.
- Development Start - Los Angeles - The Broad's $100M expansion tops out in DTLA: Development Start, Los Angeles, score 56. Pipeline / supply signal.

## BTR / Modular / Innovation Signals

- BTR / Build-to-Rent - Los Angeles - Core Spaces Secures $1.64B Fundraise for Student Housing Development, Investment: BTR / Build-to-Rent, Los Angeles, score 69. Pipeline / supply signal.
- BTR / Build-to-Rent - National - Cushman & Wakefield Brokers $26.4M Sale of 108-Home Built-to-Rent Multifamily Community Th...: BTR / Build-to-Rent, National, score 59. Pipeline / supply signal.
- BTR / Build-to-Rent - Sun Belt - NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino: BTR / Build-to-Rent, Sun Belt, score 37. Pipeline / supply signal.
- BTR / Build-to-Rent - Florida - Adam America Real Estate and Stellar Communities Deliver First Homes at Havens at Palm Bay...: BTR / Build-to-Rent, Florida, score 35. Pipeline / supply signal.
- BTR / Build-to-Rent - Other / Unknown - Build-to-rent sale mandate cut from House’s ROAD to Housing bill: BTR / Build-to-Rent, Other / Unknown, score 24. Pipeline / supply signal.

## Pricing / Cap Rate / Valuation Signals

- JV / Partnership - Sun Belt - CFAM, RPM Living Acquire 380-Unit Waterfront Multifamily Community in North Miami: JV / Partnership, Sun Belt, score 74. Pricing benchmark.
- Acquisition - Other / Unknown - Chozick Realty Arranges $3M Sale of Student Housing Building in Mansfield, Connecticut: Acquisition, Other / Unknown, score 52. Pricing benchmark.
- Acquisition - National - Core Spaces Closes $1.6B Student Housing Fund: Acquisition, National, score 43. Pricing benchmark.

## Deal / Project Signals By Residential Sector

- Multifamily: 10 deal/project signal(s)
- Apartment: 8 deal/project signal(s)
- Mixed-Use Residential: 5 deal/project signal(s)
- BTR / Single-Family Rental: 5 deal/project signal(s)
- Affordable Housing: 4 deal/project signal(s)
- General Residential: 4 deal/project signal(s)
- Student Housing: 3 deal/project signal(s)

## Canonical Deal Summary

Canonical deal fingerprints are available in `deal_fingerprint_report.md`.
Opportunity deduplication is available in `opportunity_deduplication_report.md`.
Use those reports to separate repeated coverage from genuinely separate events.

## Relationship Graph Intelligence

Developer, lender, capital partner, market, and deal edges are available in `relationship_graph_report.md`.
- Quarterra -> jll: Financing Relationship, score 100.
- Quarterra -> Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Disposition / Seller, score 84.
- Quarterra -> Los Angeles: Disposition / Seller, score 84.
- Quarterra -> Southern California: Disposition / Seller, score 84.
- Alliance Residential -> Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee: Acquisition / Buyer, score 72.

## Implications for Woomi / Woomi Global

- Pricing and cap-rate deal signals should be used as valuation benchmarks for underwriting discussions.
- Financing and refinancing rows can help track lender appetite, debt sizing, and capital-market conditions.
- California / LA project rows should feed entitlement, zoning, and local supply monitoring.

## Recommended Follow-up Actions

- Entitlement / zoning watch: read `Quarterra Seeks Buyers For Almost 4,000 Apartments` from Bisnow. Canonical market: Los Angeles.
- Pricing benchmark: read `CFAM, RPM Living Acquire 380-Unit Waterfront Multifamily Community in North Miami` from REBusiness Online. Canonical market: Sun Belt.
- Capital market signal: read `Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles` from Yield PRO. Canonical market: Los Angeles.
- Entitlement / zoning watch: read `96 apartments + retail proposed at 8871 W. Venice Blvd.` from Urbanize LA. Canonical market: Los Angeles.
- Capital market signal: read `Site prep underway for affordable housing at 4301 S. Vermont Ave.` from Urbanize LA. Canonical market: Los Angeles.
- Capital market signal: read `Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.` from Urbanize LA. Canonical market: Los Angeles.
- Capital market signal: read `Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades` from Commercial Observer. Canonical market: Los Angeles.
- Pipeline / supply signal: read `Core Spaces Secures $1.64B Fundraise for Student Housing Development, Investment` from Commercial Observer. Canonical market: Los Angeles.
