# 한국어 스트레스 / 부실 Watchlist

- 생성 시각: 2026-05-19 10:10:15
- 참고 원문 파일: `distress_watchlist_report.md`
- 번역 방식: 규칙 기반 한국어 요약. OpenAI/GPT API는 호출하지 않음.

## 리파이낸싱 압박

- refinancing stress: New York, 멀티패밀리, 점수 67 (Track debt maturity, lender exposure, sponsor stress, and recapitalization options)
- refinancing stress: New York, 아파트, 점수 63 (Track debt maturity, lender exposure, sponsor stress, and recapitalization options)
- refinancing stress: New York, 어포더블 하우징, 점수 60 (Track debt maturity, lender exposure, sponsor stress, and recapitalization options)

## 공사금융 갭

- construction loan gap: New York, 어포더블 하우징, 점수 57 (Monitor for repeated distress signals)
- construction loan gap: 기타 / 미확인, 어포더블 하우징, 점수 56 (Monitor for repeated distress signals)

## 부실 / 지연 프로젝트

- refinancing stress: New York, 멀티패밀리, 점수 67 (High Distress Watch)
- refinancing stress: New York, 아파트, 점수 63 (High Distress Watch)
- refinancing stress: New York, 어포더블 하우징, 점수 60 (High Distress Watch)
- construction loan gap: New York, 어포더블 하우징, 점수 57 (Monitor)
- construction loan gap: 기타 / 미확인, 어포더블 하우징, 점수 56 (Monitor)

## 우미 관점 기회 가능성

- 부실 신호는 단순 위기보다 가격 조정, rescue capital, JV gap 가능성 관점에서 확인합니다.
