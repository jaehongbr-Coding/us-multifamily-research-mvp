# Opportunity Radar Report

Generated: 2026-05-14 16:21:11

- Total opportunities detected: 26

## Top 10 Opportunities

- JV / Partnership Gap in Sun Belt: JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek..., score 74. Map GP, capital partner, and relationship history.
- GP Capability Partnership Opportunity in New York: General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve..., score 72. Map GP, capital partner, and relationship history.
- Refinancing Gap in New York: Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village..., score 68. Track debt stack, maturity, lender, and recapitalization details.
- LA / California Entitlement Opportunity in Los Angeles: General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd., score 66. Review entitlement, zoning, permitting, and local sponsor context.
- Construction Financing Gap in Other / Unknown: Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal..., score 63. Track debt stack, maturity, lender, and recapitalization details.
- LA / California Entitlement Opportunity in Los Angeles: Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena, score 63. Review entitlement, zoning, permitting, and local sponsor context.
- LA / California Entitlement Opportunity in Los Angeles: General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd., score 63. Review entitlement, zoning, permitting, and local sponsor context.
- LA / California Entitlement Opportunity in Los Angeles: General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts, score 63. Review entitlement, zoning, permitting, and local sponsor context.
- LA / California Entitlement Opportunity in Los Angeles: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights, score 63. Review entitlement, zoning, permitting, and local sponsor context.
- Land / Pipeline Opportunity in Sun Belt: General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl..., score 63. Monitor for repeated signals.

## LA / California Opportunities

- LA / California Entitlement Opportunity in Los Angeles: General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd., score 66. Review entitlement, zoning, permitting, and local sponsor context.
- LA / California Entitlement Opportunity in Los Angeles: Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena, score 63. Review entitlement, zoning, permitting, and local sponsor context.
- LA / California Entitlement Opportunity in Los Angeles: General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd., score 63. Review entitlement, zoning, permitting, and local sponsor context.
- LA / California Entitlement Opportunity in Los Angeles: General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts, score 63. Review entitlement, zoning, permitting, and local sponsor context.
- LA / California Entitlement Opportunity in Los Angeles: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights, score 63. Review entitlement, zoning, permitting, and local sponsor context.
- LA / California Entitlement Opportunity in California: Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco, score 61. Review entitlement, zoning, permitting, and local sponsor context.

## Acquisition / Recapitalization Opportunities

- Acquisition Opportunity in Other / Unknown: Acquisition - Other / Unknown - Mapletree Pays $100M for 97-Acre Future Logistics Site in Central Jersey, score 55. Research owner, basis, pricing, and transaction history.

## Distressed / Rescue Capital Opportunities

- Refinancing Gap in New York: Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village..., score 68. Track debt stack, maturity, lender, and recapitalization details.

## BTR / SFR Opportunities

- BTR / SFR Platform Opportunity in National: BTR / Build-to-Rent - National - Trump Pushes House To Pass Housing Bill With BTR Forced-Sale Provision, score 51. Monitor for repeated signals.

## Office-to-Residential Opportunities

- None detected.

## Affordable / Workforce Opportunities

- Construction Financing Gap in Other / Unknown: Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal..., score 63. Track debt stack, maturity, lender, and recapitalization details.
- LA / California Entitlement Opportunity in Los Angeles: Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena, score 63. Review entitlement, zoning, permitting, and local sponsor context.
- LA / California Entitlement Opportunity in Los Angeles: General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd., score 63. Review entitlement, zoning, permitting, and local sponsor context.
- LA / California Entitlement Opportunity in Los Angeles: General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts, score 63. Review entitlement, zoning, permitting, and local sponsor context.
- LA / California Entitlement Opportunity in Los Angeles: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights, score 63. Review entitlement, zoning, permitting, and local sponsor context.
- LA / California Entitlement Opportunity in Other / Unknown: Entitlement / Permitting - Other / Unknown - Completion nears for mixed-use building at 3557 S. Motor Ave. in Palms, score 60. Review entitlement, zoning, permitting, and local sponsor context.
- Affordable / Workforce Housing Opportunity in Other / Unknown: Disposition / Exit - Other / Unknown - Marcus & Millichap Arranges Sale of 64-Unit Multifamily Property Waterview Apartments in L..., score 54. Monitor for repeated signals.

## Potential GP Partnership Opportunities

- JV / Partnership Gap in Sun Belt: JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek..., score 74. Map GP, capital partner, and relationship history.
- GP Capability Partnership Opportunity in New York: General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve..., score 72. Map GP, capital partner, and relationship history.
- JV / Partnership Gap in Other / Unknown: JV / Partnership - Other / Unknown - Affordable Senior Housing Community Southernside West Set to Break Ground in Greenvillen S..., score 53. Map GP, capital partner, and relationship history.

## Timing / Market Entry Window Summary

Timing intelligence is available in `timing_intelligence_report.md`.
Market entry window scoring is available in `market_entry_window_report.md`.

## Deduplicated Opportunity Summary

Canonical event cleanup is available in `opportunity_deduplication_report.md`.
Deal fingerprints are available in `deal_fingerprint_report.md`.
Opportunity rows use canonical fingerprints so repeated article coverage does not inflate the radar.

## Multi-Source Confirmation Summary

Repeat coverage increases confirmation only when it maps to the same canonical event fingerprint.

## Implications for Woomi / Woomi Global

- Use Immediate and Strategic Opportunity Watch rows as a first-pass agenda for acquisition, recapitalization, JV, and market-entry discussion.
- Cross-check top rows against relationship persistence and capital-flow memory before outreach or underwriting work.

## Recommended Executive Follow-up

- Map GP, capital partner, and relationship history: JV / Partnership Gap in Sun Belt.
- Map GP, capital partner, and relationship history: GP Capability Partnership Opportunity in New York.
- Track debt stack, maturity, lender, and recapitalization details: Refinancing Gap in New York.
- Review entitlement, zoning, permitting, and local sponsor context: LA / California Entitlement Opportunity in Los Angeles.
- Track debt stack, maturity, lender, and recapitalization details: Construction Financing Gap in Other / Unknown.



## Development Lifecycle Intelligence Summary

- Lifecycle records: 48
- LA lifecycle watch items: 29
- Stage mix: Site Acquisition / Site Control: 5, Vertical Construction: 3, Refinancing / Recapitalization: 4, Unknown Stage: 26, Delivery / Opening: 7
- See `development_lifecycle_report.md` and `la_development_lifecycle_watch_report.md` for project timing, entitlement, permit, construction, delivery, and refinancing stages.




## Lifecycle Transition Summary

- Lifecycle transitions analyzed: 48
- Newly detected projects: 0
- Forward progression projects: 0
- Possible stalled projects: 0
- LA lifecycle transition watch items: 26
- See `lifecycle_transition_report.md` and `la_lifecycle_transition_watch_report.md` for multi-run project movement and timing signals.




## Persistent Asset Memory Summary

- Raw project references: 344
- Canonical projects: 85
- Duplicate project clusters: 46
- Persistent assets tracked: 85
- LA persistent asset watch items: 51
- See `project_identity_report.md`, `persistent_asset_memory_report.md`, and `la_persistent_asset_watch_report.md` for canonical project tracking.




## Signal Quality / Confidence Summary

- Signals evaluated: 85
- Institutional-grade signals: 4
- High-confidence signals: 14
- Weak/noisy signals: 61
- High-confidence watchlist items: 14
- See `signal_quality_report.md` and `high_confidence_watchlist_report.md` before using signals for executive decisions.

