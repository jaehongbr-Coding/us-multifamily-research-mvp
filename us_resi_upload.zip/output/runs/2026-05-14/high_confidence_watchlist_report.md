# High Confidence Watchlist Report

Generated: 2026-05-14 16:21:12

- Total high-confidence watchlist items: 14

## Top Institutional-Grade Opportunities

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Refinancing opportunity, quality 94, action: Review immediately.
- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: Institutional capital movement, quality 92, action: Review immediately.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: Refinancing opportunity, quality 88, action: Review immediately.
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: Institutional capital movement, quality 88, action: Review immediately.
- Disposition / Exit - Other / Unknown - Marcus & Millichap Arranges Sale of 64-Unit Multifamily Property Waterview Apartments in L...: LA urban infill opportunity, quality 82, action: Maintain on strategic radar.
- Operational / Property Management Tech - Texas - Crypto rewards eye renters who want to save for a down payment: Institutional capital movement, quality 80, action: Maintain on strategic radar.
- Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek in West Nashville.: LA urban infill opportunity, quality 78, action: Maintain on strategic radar.
- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco: Entitlement progression, quality 77, action: Track entitlement progression.
- BTR / Build-to-Rent - National - Trump Pushes House To Pass Housing Bill With BTR Forced-Sale Provision: Construction start pipeline, quality 75, action: Monitor construction execution.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Construction start pipeline, quality 72, action: Monitor construction execution.

## Top Institutional-Grade Risks

- None detected.

## Strongest LA / Southern California Watch Items

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Refinancing opportunity, quality 94, action: Review immediately.
- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: Institutional capital movement, quality 92, action: Review immediately.
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: Institutional capital movement, quality 88, action: Review immediately.
- Disposition / Exit - Other / Unknown - Marcus & Millichap Arranges Sale of 64-Unit Multifamily Property Waterview Apartments in L...: LA urban infill opportunity, quality 82, action: Maintain on strategic radar.
- Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek in West Nashville.: LA urban infill opportunity, quality 78, action: Maintain on strategic radar.
- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco: Entitlement progression, quality 77, action: Track entitlement progression.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Construction start pipeline, quality 72, action: Monitor construction execution.
- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: Institutional capital movement, quality 72, action: Monitor sponsor relationship.
- Crypto rewards eye renters who want to save for a down payment: LA urban infill opportunity, quality 70, action: Maintain on strategic radar.
- Swedish Investor Selling 1,500-Unit Northern Virginia Portfolio: LA urban infill opportunity, quality 70, action: Maintain on strategic radar.

## Strongest GP / Developer Signals

- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: Institutional capital movement, quality 92, action: Review immediately.
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: Institutional capital movement, quality 88, action: Review immediately.
- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: Institutional capital movement, quality 72, action: Monitor sponsor relationship.

## Strongest Capital Flow Signals

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Refinancing opportunity, quality 94, action: Review immediately.
- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: Institutional capital movement, quality 92, action: Review immediately.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: Refinancing opportunity, quality 88, action: Review immediately.
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: Institutional capital movement, quality 88, action: Review immediately.
- Operational / Property Management Tech - Texas - Crypto rewards eye renters who want to save for a down payment: Institutional capital movement, quality 80, action: Maintain on strategic radar.
- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: Institutional capital movement, quality 72, action: Monitor sponsor relationship.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: Refinancing opportunity, quality 71, action: Watch refinancing timing.

## Strongest Refinancing Opportunities

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Refinancing opportunity, quality 94, action: Review immediately.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: Refinancing opportunity, quality 88, action: Review immediately.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: Refinancing opportunity, quality 71, action: Watch refinancing timing.

## Strongest Construction-Ready Opportunities

- BTR / Build-to-Rent - National - Trump Pushes House To Pass Housing Bill With BTR Forced-Sale Provision: Construction start pipeline, quality 75, action: Monitor construction execution.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Construction start pipeline, quality 72, action: Monitor construction execution.

## Recommended Executive Actions

- Review immediately: Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village....
- Review immediately: JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek....
- Review immediately: General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl....
- Review immediately: Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America.
- Maintain on strategic radar: Disposition / Exit - Other / Unknown - Marcus & Millichap Arranges Sale of 64-Unit Multifamily Property Waterview Apartments in L....
- Maintain on strategic radar: Operational / Property Management Tech - Texas - Crypto rewards eye renters who want to save for a down payment.
- Maintain on strategic radar: Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek in West Nashville..
- Track entitlement progression: Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco.
