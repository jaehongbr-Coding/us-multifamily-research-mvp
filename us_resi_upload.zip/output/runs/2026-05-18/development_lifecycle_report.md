# Development Lifecycle Report

Generated: 2026-05-18 16:30:57

- Total lifecycle records: 54

## Lifecycle Stage Distribution

- Unknown Stage: 28
- Delivery / Opening: 9
- Site Acquisition / Site Control: 8
- Vertical Construction: 4
- Early Site Signal: 4
- Refinancing / Recapitalization: 1

## Top Development Timing Opportunities

- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Unknown Stage, Southern California, lifecycle_opportunity_score 100.
- Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee: Vertical Construction, Nashville, lifecycle_opportunity_score 91.
- Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave.: Site Acquisition / Site Control, Los Angeles, lifecycle_opportunity_score 88.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Vertical Construction, Los Angeles, lifecycle_opportunity_score 87.
- General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve...: Unknown Stage, New York, lifecycle_opportunity_score 84.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Delivery / Opening, Los Angeles, lifecycle_opportunity_score 83.
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: Early Site Signal, L.A., lifecycle_opportunity_score 81.
- Site prep underway for affordable housing at 4301 S. Vermont Ave.: Site Acquisition / Site Control, Los Angeles, lifecycle_opportunity_score 81.
- Disposition / Exit - California - Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale: Site Acquisition / Site Control, California, lifecycle_opportunity_score 81.
- Cypress Equity Investments gets $170M loan for two Santa Monica projects: Refinancing / Recapitalization, Los Angeles, lifecycle_opportunity_score 80.

## Top Lifecycle Risks

- Construction Financing - Other / Unknown - Cypress Equity Investments gets $170M loan for two Santa Monica projects: Unknown Stage, Unknown, lifecycle_risk_score 53.
- Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC...: Unknown Stage, Unknown, lifecycle_risk_score 53.
- Cypress Equity Investments gets $170M loan for two Santa Monica projects: Refinancing / Recapitalization, Los Angeles, lifecycle_risk_score 52.
- Acquisition - Los Angeles - JLL Arranges Sale of 365,774 SF Industrial Portfolio Near Los Angeles Across Two Separate...: Unknown Stage, Los Angeles, lifecycle_risk_score 52.
- Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles: Delivery / Opening, Los Angeles, lifecycle_risk_score 49.
- Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades: Site Acquisition / Site Control, Southern California, lifecycle_risk_score 46.
- JLL Arranges Sale of 365,774 SF Industrial Portfolio Near Los Angeles Across Two Separate Transactions: Unknown Stage, Orange County, lifecycle_risk_score 46.
- Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles: Delivery / Opening, Unknown, lifecycle_risk_score 40.
- BTR / Build-to-Rent - Los Angeles - Core Spaces Secures $1.64B Fundraise for Student Housing Development, Investment: Unknown Stage, Los Angeles, lifecycle_risk_score 34.
- BTR / Build-to-Rent - National - Cushman & Wakefield Brokers $26.4M Sale of 108-Home Built-to-Rent Multifamily Community Th...: Unknown Stage, National, lifecycle_risk_score 32.

## Projects Under Entitlement / Planning

- None detected.

## Construction-Ready / Construction-Start Signals

- Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee: Vertical Construction, Nashville, lifecycle_opportunity_score 91.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Vertical Construction, Los Angeles, lifecycle_opportunity_score 87.
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Vertical Construction, Lincoln Heights, lifecycle_opportunity_score 80.
- Development Start - Los Angeles - The Broad's $100M expansion tops out in DTLA: Vertical Construction, Los Angeles, lifecycle_opportunity_score 80.

## Delivery / Lease-Up Signals

- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Delivery / Opening, Los Angeles, lifecycle_opportunity_score 83.
- Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles: Delivery / Opening, Los Angeles, lifecycle_opportunity_score 80.
- Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Delivery / Opening, Los Angeles, lifecycle_opportunity_score 76.
- Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee: Delivery / Opening, Nashville, lifecycle_opportunity_score 71.
- BTR / Build-to-Rent - Sun Belt - NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino: Delivery / Opening, Phoenix, lifecycle_opportunity_score 70.
- Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles: Delivery / Opening, Unknown, lifecycle_opportunity_score 69.
- NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino: Delivery / Opening, Phoenix, lifecycle_opportunity_score 63.
- Disposition / Exit - Sun Belt - Institutional Property Advisors Closes Sale and Arranges Financing for Dallas Multifamily...: Delivery / Opening, Dallas, lifecycle_opportunity_score 61.
- General Project Signal - Other / Unknown - Multifamily Absorption Rate Remains Below 50%: Delivery / Opening, Unknown, lifecycle_opportunity_score 47.

## Distressed / Stalled Lifecycle Signals

- None detected.

## Refinancing / Recapitalization Lifecycle Signals

- Cypress Equity Investments gets $170M loan for two Santa Monica projects: Refinancing / Recapitalization, Los Angeles, lifecycle_risk_score 52.

## Implications for Woomi / Woomi Global

- Lifecycle intelligence helps translate site-level clues into timing decisions: watch, prepare, underwrite, partner, or wait.
- LA / California rows with planning, CEQA, permit, construction-ready, or stalled signals should be reviewed alongside entitlement and asset reports.

## Recommended Lifecycle Follow-up Actions

- Monitor lifecycle signal for repeated confirmation: Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments.
- Benchmark construction timeline, sponsor execution, and delivery risk: Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee.
- Monitor lifecycle signal for repeated confirmation: Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave..
- Benchmark construction timeline, sponsor execution, and delivery risk: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.
- Monitor lifecycle signal for repeated confirmation: General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve....
- Benchmark delivery, lease-up, occupancy, and rent assumptions: General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd..
- Monitor lifecycle signal for repeated confirmation: Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd..
- Monitor lifecycle signal for repeated confirmation: Site prep underway for affordable housing at 4301 S. Vermont Ave..



## Lifecycle Transition Summary

- Lifecycle transitions analyzed: 54
- Newly detected projects: 0
- Forward progression projects: 0
- Possible stalled projects: 0
- LA lifecycle transition watch items: 30
- See `lifecycle_transition_report.md` and `la_lifecycle_transition_watch_report.md` for multi-run project movement and timing signals.




## Persistent Asset Memory Summary

- Raw project references: 405
- Canonical projects: 100
- Duplicate project clusters: 55
- Persistent assets tracked: 100
- LA persistent asset watch items: 65
- See `project_identity_report.md`, `persistent_asset_memory_report.md`, and `la_persistent_asset_watch_report.md` for canonical project tracking.




## Signal Quality / Confidence Summary

- Signals evaluated: 100
- Institutional-grade signals: 7
- High-confidence signals: 19
- Weak/noisy signals: 72
- High-confidence watchlist items: 19
- See `signal_quality_report.md` and `high_confidence_watchlist_report.md` before using signals for executive decisions.

