# Submarket Intelligence Report

Generated: 2026-05-14 16:21:11

- Total submarkets detected: 16

## Top Submarkets By Opportunity Score

- New York (New York): submarket_opportunity_score 100, Review potential acquisition pipeline.
- Pasadena (Los Angeles): submarket_opportunity_score 92, Monitor entitlement precedent.
- Wilshire (Los Angeles): submarket_opportunity_score 63, Review potential acquisition pipeline.
- Lincoln Heights (Los Angeles): submarket_opportunity_score 57, Monitor only.
- Watts (Los Angeles): submarket_opportunity_score 57, Monitor only.
- Nashville (Southeast): submarket_opportunity_score 56, Monitor entitlement precedent.
- Los Angeles (Los Angeles): submarket_opportunity_score 50, Monitor entitlement precedent.
- San Francisco (National / Other): submarket_opportunity_score 27, Monitor entitlement precedent.
- National (National / Other): submarket_opportunity_score 16, Monitor only.
- Beverly Grove (Los Angeles): submarket_opportunity_score 12, Monitor only.

## Top Submarkets By Risk Score

- New York (New York): submarket_risk_score 51, Review potential acquisition pipeline.
- Los Angeles (Los Angeles): submarket_risk_score 44, Monitor entitlement precedent.
- Pasadena (Los Angeles): submarket_risk_score 21, Monitor entitlement precedent.
- Nashville (Southeast): submarket_risk_score 15, Monitor entitlement precedent.
- San Francisco (National / Other): submarket_risk_score 15, Monitor entitlement precedent.
- Wilshire (Los Angeles): submarket_risk_score 0, Review potential acquisition pipeline.
- Lincoln Heights (Los Angeles): submarket_risk_score 0, Monitor only.
- Watts (Los Angeles): submarket_risk_score 0, Monitor only.
- National (National / Other): submarket_risk_score 0, Monitor only.
- Beverly Grove (Los Angeles): submarket_risk_score 0, Monitor only.

## Highest Execution Complexity Submarkets

- Pasadena (Los Angeles): execution_complexity_score 52, Monitor entitlement precedent.
- Los Angeles (Los Angeles): execution_complexity_score 40, Monitor entitlement precedent.
- Wilshire (Los Angeles): execution_complexity_score 30, Review potential acquisition pipeline.
- Lincoln Heights (Los Angeles): execution_complexity_score 30, Monitor only.
- Watts (Los Angeles): execution_complexity_score 30, Monitor only.
- Nashville (Southeast): execution_complexity_score 30, Monitor entitlement precedent.
- San Francisco (National / Other): execution_complexity_score 30, Monitor entitlement precedent.
- Beverly Grove (Los Angeles): execution_complexity_score 30, Monitor only.
- New York (New York): execution_complexity_score 20, Review potential acquisition pipeline.
- National (National / Other): execution_complexity_score 20, Monitor only.

## Sector Themes By Submarket

- New York: Multifamily, Transit-oriented development.
- Pasadena: Affordable Housing, General submarket monitoring.
- Wilshire: Apartment, General submarket monitoring.
- Lincoln Heights: Affordable Housing, Hospital-adjacent.
- Watts: Affordable Housing, General submarket monitoring.
- Nashville: Mixed-Use Residential, Mixed-use corridor.
- Los Angeles: Affordable Housing, Mixed-use corridor.
- San Francisco: Senior Housing, General submarket monitoring.
- National: Apartment, General submarket monitoring.
- Beverly Grove: Affordable Housing, Mixed-use corridor.
- Miami: Multifamily, Waterfront redevelopment.
- Southeast: Affordable Housing, Mixed-use corridor.

## Timing and Entitlement Signals By Submarket

- New York: 2 timing signal(s), 0 entitlement signal(s).
- Pasadena: 1 timing signal(s), 1 entitlement signal(s).
- Wilshire: 1 timing signal(s), 0 entitlement signal(s).
- Lincoln Heights: 0 timing signal(s), 0 entitlement signal(s).
- Watts: 0 timing signal(s), 0 entitlement signal(s).
- Nashville: 0 timing signal(s), 1 entitlement signal(s).
- Los Angeles: 0 timing signal(s), 3 entitlement signal(s).
- San Francisco: 0 timing signal(s), 1 entitlement signal(s).
- National: 0 timing signal(s), 0 entitlement signal(s).
- Beverly Grove: 0 timing signal(s), 0 entitlement signal(s).
- Miami: 0 timing signal(s), 0 entitlement signal(s).
- Southeast: 0 timing signal(s), 0 entitlement signal(s).

## Implications for Woomi / Woomi Global

- Submarket intelligence helps turn broad regional monitoring into site-screening and local execution watchlists.
- LA / California submarkets with entitlement or execution complexity should be reviewed before sourcing or underwriting assumptions are finalized.
- Asset / parcel-level site clues are available in `asset_parcel_intelligence_report.md` and `la_asset_watch_report.md`.

## Recommended Submarket Follow-up Actions

- Review potential acquisition pipeline: New York (Strategic watch submarket).
- Monitor entitlement precedent: Pasadena (High relevance to Woomi site strategy).
- Review potential acquisition pipeline: Wilshire (High relevance to Woomi site strategy).
- Monitor only: Lincoln Heights (High relevance to Woomi site strategy).
- Monitor only: Watts (High relevance to Woomi site strategy).
- Monitor entitlement precedent: Nashville (Strategic watch submarket).
- Monitor entitlement precedent: Los Angeles (Strategic watch submarket).
- Monitor entitlement precedent: San Francisco (General monitoring).



## Development Lifecycle Intelligence Summary

- Lifecycle records: 48
- LA lifecycle watch items: 29
- Stage mix: Site Acquisition / Site Control: 5, Vertical Construction: 3, Refinancing / Recapitalization: 4, Unknown Stage: 26, Delivery / Opening: 7
- See `development_lifecycle_report.md` and `la_development_lifecycle_watch_report.md` for project timing, entitlement, permit, construction, delivery, and refinancing stages.

