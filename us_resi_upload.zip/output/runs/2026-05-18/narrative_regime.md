# Narrative Regime Detection

Generated: 2026-05-18 16:30:54

## Detected Regime

- Primary regime: Developer Strategy Shift
- Secondary regime: Selective Capital Re-entry
- Confidence level: High
- Explanation: Developer strategy, adaptive reuse, product strategy, or operating model signals are a meaningful part of the current briefing set.

## Regime Scorecard

| Regime | Score |
| --- | ---: |
| Developer Strategy Shift | 102 |
| Selective Capital Re-entry | 77 |
| Financing Stress | 59 |
| Supply Pressure | 57 |
| Policy / Entitlement Watch | 10 |
| Construction Cost Pressure | 0 |

## Regime Heatmap Reference

Calibrated 0-100 heatmap scores are available in `regime_heatmap_report.md` and `regime_heatmap.csv`.
Regime momentum is available in `regime_momentum_report.md` when previous heatmap history exists.

| Regime | Final Score | Strength |
| --- | ---: | --- |
| Supply Pressure | 96 | Very Strong |
| Financing Stress | 81 | Very Strong |
| Selective Capital Re-entry | 68 | Strong |
| Developer Strategy Shift | 59 | Moderate |
| Policy / Entitlement Watch | 41 | Moderate |
| Construction Cost Pressure | 0 | Not Detected |
| Stable Monitoring Environment | 0 | Not Detected |

## Signal Inputs

- Strategy-briefing articles reviewed: 31
- Market-signal articles reviewed: 23
- Articles with extracted numbers: 23
- Institutional player mentions: 6

### Strategic Angles

- Developer Strategy: 20
- Institutional Flow: 13
- Financing Risk: 9
- Rent Growth / Demand: 7
- Supply Pressure: 5
- Regulation Risk: 2

### Market Signals

- Rent Growth Signal: 9
- Supply / Starts Signal: 7
- Financing Cost Signal: 3
- Vacancy Signal: 3
- Deal Size Signal: 1

### Decision Uses

- Track Developer Strategy: 20
- Track Institutional Capital Flow: 13
- Track Financing Conditions: 9
- Track Rent / Vacancy Trend: 7
- Track Supply Pipeline: 5
- Track Regulation Risk: 2

### Market Focus

- Other / Unknown: 10
- Los Angeles: 7
- Sun Belt: 6
- California: 3
- National: 2
- New York: 2

### Action Levels

- Must Read: 22
- Review: 8
- Monitor: 1

### Woomi Relevance

- High relevance to US residential developer strategy: 24
- Medium relevance to market monitoring: 7

## Key Thematic Context

- No major thematic increase alert was detected in this run.

## Cross-Theme Interpretation

- Financing stress plus supply pressure may call for more conservative underwriting, especially around leverage, lease-up pace, and exit cap rates.
- Institutional flow plus cap rate or deal-size signals may indicate pricing discovery by major capital players.
- California / LA focus plus policy signals may indicate entitlement, zoning, rent control, or housing-production opportunity and risk.

## Implications for Woomi / Woomi Global

- Keep LA / California monitoring active because local policy, entitlement, and supply signals are directly relevant to market-entry planning.
- Track institutional capital flow to identify pricing signals, partnership targets, and markets where capital may be returning selectively.
- Use developer strategy signals to build US residential development capabilities around product type, delivery model, and GP partnership structure.

## Recommended Strategy Team Questions

- Are financing conditions changing enough to affect new development starts, refinancing, or exit cap assumptions?
- Are supply signals concentrated in specific markets, product types, or lease-up windows?
- Are institutional buyers returning to markets, assets, or capital structures relevant to Woomi?
- Are LA / California policy changes creating entitlement opportunities or risks?
