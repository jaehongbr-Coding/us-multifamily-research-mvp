# Strategic Signal Quality Report

Generated: 2026-05-18 16:30:57

- Total signals evaluated: 100
- Institutional-grade signals: 7
- High-confidence signals: 19
- Weak/noisy signals: 72

## Strongest Recurring Signals

- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Institutional Grade, score 91, 5 source file(s), 5 observation(s), latest stage Unknown Stage, identity confidence 100.
- Disposition / Exit - California - Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale: Institutional Grade, score 90, 6 source file(s), 14 observation(s), latest stage Site Acquisition / Site Control, identity confidence 80.
- BTR / Build-to-Rent - Sun Belt - NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino: Institutional Grade, score 89, 4 source file(s), 7 observation(s), latest stage Delivery / Opening, identity confidence 80.
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: Institutional Grade, score 88, 8 source file(s), 10 observation(s), latest stage Unknown Stage, identity confidence 100.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Institutional Grade, score 86, 3 source file(s), 25 observation(s), latest stage Site Acquisition / Site Control, identity confidence 80.
- Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee: Institutional Grade, score 86, 4 source file(s), 4 observation(s), latest stage Vertical Construction, identity confidence 100.
- Disposition / Exit - Sun Belt - Institutional Property Advisors Closes Sale and Arranges Financing for Dallas Multifamily...: Institutional Grade, score 85, 4 source file(s), 8 observation(s), latest stage Delivery / Opening, identity confidence 80.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: High Confidence, score 82, 5 source file(s), 35 observation(s), latest stage Refinancing / Recapitalization, identity confidence 80.
- BTR / Build-to-Rent - Florida - Adam America Real Estate and Stellar Communities Deliver First Homes at Havens at Palm Bay...: High Confidence, score 81, 6 source file(s), 6 observation(s), latest stage Unknown Stage, identity confidence 80.
- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: High Confidence, score 80, 4 source file(s), 7 observation(s), latest stage Unknown Stage, identity confidence 100.

## Strongest LA / California Signals

- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Institutional Grade, score 91, 5 source file(s), 5 observation(s), latest stage Unknown Stage, identity confidence 100.
- Disposition / Exit - California - Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale: Institutional Grade, score 90, 6 source file(s), 14 observation(s), latest stage Site Acquisition / Site Control, identity confidence 80.
- BTR / Build-to-Rent - Sun Belt - NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino: Institutional Grade, score 89, 4 source file(s), 7 observation(s), latest stage Delivery / Opening, identity confidence 80.
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: Institutional Grade, score 88, 8 source file(s), 10 observation(s), latest stage Unknown Stage, identity confidence 100.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Institutional Grade, score 86, 3 source file(s), 25 observation(s), latest stage Site Acquisition / Site Control, identity confidence 80.
- Disposition / Exit - Sun Belt - Institutional Property Advisors Closes Sale and Arranges Financing for Dallas Multifamily...: Institutional Grade, score 85, 4 source file(s), 8 observation(s), latest stage Delivery / Opening, identity confidence 80.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: High Confidence, score 82, 5 source file(s), 35 observation(s), latest stage Refinancing / Recapitalization, identity confidence 80.
- BTR / Build-to-Rent - Florida - Adam America Real Estate and Stellar Communities Deliver First Homes at Havens at Palm Bay...: High Confidence, score 81, 6 source file(s), 6 observation(s), latest stage Unknown Stage, identity confidence 80.
- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: High Confidence, score 80, 4 source file(s), 7 observation(s), latest stage Unknown Stage, identity confidence 100.
- Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades: High Confidence, score 76, 3 source file(s), 3 observation(s), latest stage Site Acquisition / Site Control, identity confidence 80.

## Most Persistent Projects

- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Institutional Grade, score 91, 5 source file(s), 5 observation(s), latest stage Unknown Stage, identity confidence 100.
- Disposition / Exit - California - Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale: Institutional Grade, score 90, 6 source file(s), 14 observation(s), latest stage Site Acquisition / Site Control, identity confidence 80.
- BTR / Build-to-Rent - Sun Belt - NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino: Institutional Grade, score 89, 4 source file(s), 7 observation(s), latest stage Delivery / Opening, identity confidence 80.
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: Institutional Grade, score 88, 8 source file(s), 10 observation(s), latest stage Unknown Stage, identity confidence 100.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Institutional Grade, score 86, 3 source file(s), 25 observation(s), latest stage Site Acquisition / Site Control, identity confidence 80.
- Disposition / Exit - Sun Belt - Institutional Property Advisors Closes Sale and Arranges Financing for Dallas Multifamily...: Institutional Grade, score 85, 4 source file(s), 8 observation(s), latest stage Delivery / Opening, identity confidence 80.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: High Confidence, score 82, 5 source file(s), 35 observation(s), latest stage Refinancing / Recapitalization, identity confidence 80.
- BTR / Build-to-Rent - Florida - Adam America Real Estate and Stellar Communities Deliver First Homes at Havens at Palm Bay...: High Confidence, score 81, 6 source file(s), 6 observation(s), latest stage Unknown Stage, identity confidence 80.
- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: High Confidence, score 80, 4 source file(s), 7 observation(s), latest stage Unknown Stage, identity confidence 100.
- BTR / Build-to-Rent - National - Cushman & Wakefield Brokers $26.4M Sale of 108-Home Built-to-Rent Multifamily Community Th...: High Confidence, score 78, 6 source file(s), 11 observation(s), latest stage Site Acquisition / Site Control, identity confidence 80.

## Strongest Refinancing / Stress Signals

- Cypress Equity Investments gets $170M loan for two Santa Monica projects: Weak Signal, score 54, 2 source file(s), 2 observation(s), latest stage Unknown Stage, identity confidence 80.
- Construction Financing - Other / Unknown - Cypress Equity Investments gets $170M loan for two Santa Monica projects: Weak Signal, score 45, 1 source file(s), 2 observation(s), latest stage Unknown Stage, identity confidence 80.
- Cypress Equity Investments gets $170M loan for two Santa Monica projects: Weak Signal, score 44, 1 source file(s), 1 observation(s), latest stage Unknown Stage, identity confidence 100.
- Construction Financing - Other / Unknown - Cypress Equity Investments gets $170M loan for two Santa Monica projects: Weak Signal, score 42, 1 source file(s), 1 observation(s), latest stage Unknown Stage, identity confidence 80.

## Strongest Entitlement Progression Signals

- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: Moderate Confidence, score 59, 2 source file(s), 2 observation(s), latest stage Early Site Signal, identity confidence 80.
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: Moderate Confidence, score 55, 2 source file(s), 2 observation(s), latest stage Unknown Stage, identity confidence 80.
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: Weak Signal, score 53, 1 source file(s), 2 observation(s), latest stage Unknown Stage, identity confidence 80.
- Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave.: Weak Signal, score 53, 1 source file(s), 2 observation(s), latest stage Unknown Stage, identity confidence 80.
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: Weak Signal, score 42, 1 source file(s), 1 observation(s), latest stage Unknown Stage, identity confidence 80.
- Builders Stay Cautious as Single-Family Permits Weaken: Weak Signal, score 42, 1 source file(s), 1 observation(s), latest stage Unknown Stage, identity confidence 100.

## Strongest Construction-Start Signals

- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Institutional Grade, score 86, 3 source file(s), 25 observation(s), latest stage Site Acquisition / Site Control, identity confidence 80.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: High Confidence, score 82, 5 source file(s), 35 observation(s), latest stage Refinancing / Recapitalization, identity confidence 80.
- Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades: High Confidence, score 76, 3 source file(s), 3 observation(s), latest stage Site Acquisition / Site Control, identity confidence 80.
- Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC...: High Confidence, score 70, 7 source file(s), 51 observation(s), latest stage Site Acquisition / Site Control, identity confidence 80.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: High Confidence, score 70, 5 source file(s), 30 observation(s), latest stage Unknown Stage, identity confidence 80.
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Moderate Confidence, score 60, 2 source file(s), 2 observation(s), latest stage Vertical Construction, identity confidence 80.
- Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC...: Moderate Confidence, score 58, 2 source file(s), 32 observation(s), latest stage Site Acquisition / Site Control, identity confidence 80.
- Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC...: Moderate Confidence, score 55, 1 source file(s), 13 observation(s), latest stage Unknown Stage, identity confidence 80.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Weak Signal, score 53, 1 source file(s), 2 observation(s), latest stage Unknown Stage, identity confidence 80.
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Weak Signal, score 49, 1 source file(s), 1 observation(s), latest stage Unknown Stage, identity confidence 100.

## Implications for Woomi / Woomi Global

- Signal quality calibration helps separate institutional-grade project intelligence from noisy one-off mentions.
- High-quality signals should receive management attention before weaker signals inflate opportunity or lifecycle conclusions.

## Recommended Signal Quality Follow-up Actions

- Immediate strategic review: Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments (Institutional Grade).
- Immediate strategic review: Disposition / Exit - California - Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale (Institutional Grade).
- Immediate strategic review: BTR / Build-to-Rent - Sun Belt - NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino (Institutional Grade).
- Immediate strategic review: Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America (Institutional Grade).
- Immediate strategic review: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights (Institutional Grade).
- Immediate strategic review: Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee (Institutional Grade).
- Immediate strategic review: Disposition / Exit - Sun Belt - Institutional Property Advisors Closes Sale and Arranges Financing for Dallas Multifamily... (Institutional Grade).
- Add to executive watchlist: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights (High Confidence).
