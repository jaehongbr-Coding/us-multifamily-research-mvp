# LA Development Lifecycle Watch Report

Generated: 2026-05-18 16:30:57

- Total LA lifecycle watch items: 32

## LA Lifecycle Stage Distribution

- Unknown Stage: 10
- Site Acquisition / Site Control: 7
- Delivery / Opening: 7
- Early Site Signal: 4
- Vertical Construction: 3
- Refinancing / Recapitalization: 1

## Koreatown / Wilshire Lifecycle Watch

- None detected.

## DTLA Lifecycle Watch

- None detected.

## Hollywood Lifecycle Watch

- None detected.

## Pasadena Lifecycle Watch

- None detected.

## Long Beach Lifecycle Watch

- None detected.

## Orange County Lifecycle Watch

- None detected.

## Inland Empire Lifecycle Watch

- None detected.

## Stalled / Distressed LA Project Watch

- None detected.

## Construction-Ready LA Project Watch

- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Vertical Construction, Monitor only, opportunity 87.
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Vertical Construction, Monitor only, opportunity 80.
- Development Start - Los Angeles - The Broad's $100M expansion tops out in DTLA: Vertical Construction, Monitor only, opportunity 80.

## Recommended LA Lifecycle Follow-up Actions

- Monitor lifecycle status for repeated confirmation: Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments.
- Monitor lifecycle status for repeated confirmation: Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave..
- Track construction progress and delivery timeline: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.
- Monitor lifecycle status for repeated confirmation: General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve....
- Monitor lifecycle status for repeated confirmation: General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd..
- Monitor lifecycle status for repeated confirmation: Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd..
- Monitor lifecycle status for repeated confirmation: Site prep underway for affordable housing at 4301 S. Vermont Ave..
- Monitor lifecycle status for repeated confirmation: Disposition / Exit - California - Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale.



## Lifecycle Transition Summary

- Lifecycle transitions analyzed: 54
- Newly detected projects: 0
- Forward progression projects: 0
- Possible stalled projects: 0
- LA lifecycle transition watch items: 30
- See `lifecycle_transition_report.md` and `la_lifecycle_transition_watch_report.md` for multi-run project movement and timing signals.




## Persistent Asset Memory Summary

- Raw project references: 405
- Canonical projects: 100
- Duplicate project clusters: 55
- Persistent assets tracked: 100
- LA persistent asset watch items: 65
- See `project_identity_report.md`, `persistent_asset_memory_report.md`, and `la_persistent_asset_watch_report.md` for canonical project tracking.

