# Institutional Relationship & Capital Flow Report

Generated: 2026-05-18 16:30:55

## Top Institutional Relationship Signals

- Quarterra: score 99, Capital Inflow, GP Capability Benchmark Signal. Review California / LA capital and developer activity.
- Blackstone: score 88, Capital Inflow, Potential JV / Partnership Signal. Map potential GP / JV relationship and monitor partnership activity.
- Alliance Residential: score 81, Capital Inflow, No Clear Relationship Signal. Track capital deployment and pricing signals.

## Tier 1 Firm Watch

- Blackstone: score 88, Capital Inflow, Potential JV / Partnership Signal. Map potential GP / JV relationship and monitor partnership activity.

## California / LA Capital and Developer Watch

- Quarterra: score 99, Capital Inflow, GP Capability Benchmark Signal. Review California / LA capital and developer activity.

## Capital Inflow / Outflow Signals

- Quarterra: score 99, Capital Inflow, GP Capability Benchmark Signal. Review California / LA capital and developer activity.
- Blackstone: score 88, Capital Inflow, Potential JV / Partnership Signal. Map potential GP / JV relationship and monitor partnership activity.
- Alliance Residential: score 81, Capital Inflow, No Clear Relationship Signal. Track capital deployment and pricing signals.

## JV / Partnership Signals

- Blackstone: score 88, Capital Inflow, Potential JV / Partnership Signal. Map potential GP / JV relationship and monitor partnership activity.

## Competitive Benchmark Signals

- Quarterra: score 99, Capital Inflow, GP Capability Benchmark Signal. Review California / LA capital and developer activity.

## Pricing Discovery Signals

- No current signal detected.

## Relationship Map

| Firm | Market | Source Category | Activity Type | Capital Flow | Relationship Signal | Woomi Implication |
| --- | --- | --- | --- | --- | --- | --- |
| Quarterra | Los Angeles | Core Multifamily News | acquisition; disposition / exit; operational technology / AI adoption | Capital Inflow | GP Capability Benchmark Signal | competitive pressure indicator |
| Blackstone | New York | Developer / GP Newsrooms | acquisition; refinancing; JV / partnership; capital raise | Capital Inflow | Potential JV / Partnership Signal | potential JV partnership signal |
| Alliance Residential | Sun Belt | Site / Parcel Source Expansion | acquisition | Capital Inflow | No Clear Relationship Signal | benchmark underwriting assumptions |

## Deal / Project Intelligence

Deal and project-level extraction is available in `deal_pipeline_report.md`.
- Disposition / Exit in Los Angeles: Unknown / Unknown / jll.
- Construction Financing in Los Angeles: Unknown / Unknown / jll.
- Acquisition in Other / Unknown: Unknown / Unknown / cbre.
- Construction Financing in Other / Unknown: Unknown / Unknown / jll.
- BTR / Build-to-Rent in National: Unknown / Unknown / cushman.

## Relationship Graph Intelligence

Capital partner, lender, GP, and market edges are available in `relationship_graph_report.md`.
- Quarterra -> jll: Financing Relationship.
- Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades -> jll: Financing Relationship.
- Blackstone -> blackstone: Capital Flow.
- Acquisition - Los Angeles - JLL Arranges Sale of 365,774 SF Industrial Portfolio Near Los Angeles Across Two Separate... -> jll: Financing Relationship.
- Acquisition - Other / Unknown - Guardian Acquires 332-Unit Ladd Tower Apartment Building in Downtown Portland -> cbre: Financing Relationship.

## High-Scoring GP Watchlist Reference

Emerging GP watchlist rankings are available in `gp_watchlist_report.md`.
- Quarterra: 75 (Tier 2 High Potential GP), Moderate partnership signal.
- Blackstone: 58 (Tier 3 Monitoring GP), Strong partnership signal.
- Alliance Residential: 47 (Emerging Watchlist), No clear partnership signal.

## GP Source Expansion Summary

Developer / GP source coverage is available in `gp_source_coverage_report.md`.
Use that report to prioritize missing capital platform, lender, and GP feeds that would strengthen relationship scoring.

## Source Activation Summary

Validated source activation scoring is available in `source_activation_report.md`.
Use that report to separate production-ready institutional feeds from critical manual-review sources.

## Historical Persistence Summary

Institutional memory is available in `historical_memory_report.md`.
Capital-flow memory is available in `capital_flow_report.md`.
Recurring relationship tracking is available in `relationship_persistence_report.md`.

## Opportunity / Distress Radar

Opportunity radar is available in `opportunity_radar_report.md`.
Distress watchlist is available in `distress_watchlist_report.md`.
Canonical deal fingerprints are available in `deal_fingerprint_report.md`.
Opportunity deduplication is available in `opportunity_deduplication_report.md`.
Timing intelligence is available in `timing_intelligence_report.md`.
Market entry window scoring is available in `market_entry_window_report.md`.

## Implications for Woomi / Woomi Global

- JV / partnership signals should be mapped to potential GP relationship targets and compared with Woomi's US entry needs.
- Capital inflow or deployment signals can help benchmark pricing, underwriting assumptions, and market timing.
- High California / LA relevance should be connected to entitlement, zoning, and local developer capability tracking.

## Recommended Executive Follow-Up

- Quarterra: Review California / LA capital and developer activity
- Blackstone: Map potential GP / JV relationship and monitor partnership activity
- Alliance Residential: Track capital deployment and pricing signals



## Signal Quality / Confidence Summary

- Signals evaluated: 100
- Institutional-grade signals: 7
- High-confidence signals: 19
- Weak/noisy signals: 72
- High-confidence watchlist items: 19
- See `signal_quality_report.md` and `high_confidence_watchlist_report.md` before using signals for executive decisions.

