# Persistent Asset Memory Report

Generated: 2026-05-18 16:30:57

- Total persistent assets tracked: 100
- Newly detected assets: 75
- Progressing assets: 0
- Possible stalled assets: 4

## Highest Priority Asset Watch Items

- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Priority Asset Watch, Unknown Stage, score 90.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Priority Asset Watch, Site Acquisition / Site Control, score 86.
- Disposition / Exit - California - Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale: Priority Asset Watch, Site Acquisition / Site Control, score 86.
- Disposition / Exit - Sun Belt - Institutional Property Advisors Closes Sale and Arranges Financing for Dallas Multifamily...: Priority Asset Watch, Delivery / Opening, score 83.
- BTR / Build-to-Rent - Sun Belt - NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino: Priority Asset Watch, Delivery / Opening, score 82.
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: Priority Asset Watch, Unknown Stage, score 80.
- BTR / Build-to-Rent - Florida - Adam America Real Estate and Stellar Communities Deliver First Homes at Havens at Palm Bay...: Priority Asset Watch, Unknown Stage, score 78.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Priority Asset Watch, Refinancing / Recapitalization, score 78.
- Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades: Strategic Asset Watch, Site Acquisition / Site Control, score 69.
- General Project Signal - Los Angeles - Taylor Yard wetland takes shape, General Hospital update, and more: Strategic Asset Watch, Site Acquisition / Site Control, score 67.

## Assets With Repeated Financing Signals

- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Priority Asset Watch, Refinancing / Recapitalization, score 78.
- Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC...: Strategic Asset Watch, Site Acquisition / Site Control, score 65.
- Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC...: Strategic Asset Watch, Site Acquisition / Site Control, score 63.
- Construction Financing - Other / Unknown - Cypress Equity Investments gets $170M loan for two Santa Monica projects: Strategic Asset Watch, Unknown Stage, score 62.
- Cypress Equity Investments gets $170M loan for two Santa Monica projects: Strategic Asset Watch, Unknown Stage, score 58.
- Construction Financing - Other / Unknown - Cypress Equity Investments gets $170M loan for two Santa Monica projects: Low Priority, Unknown Stage, score 20.
- Cypress Equity Investments gets $170M loan for two Santa Monica projects: Low Priority, Unknown Stage, score 20.

## Assets With Repeated Entitlement Signals

- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Priority Asset Watch, Site Acquisition / Site Control, score 86.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Priority Asset Watch, Refinancing / Recapitalization, score 78.
- Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC...: Strategic Asset Watch, Site Acquisition / Site Control, score 65.
- Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC...: Strategic Asset Watch, Unknown Stage, score 64.
- Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC...: Strategic Asset Watch, Site Acquisition / Site Control, score 63.
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: Strategic Asset Watch, Unknown Stage, score 60.
- Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave.: Strategic Asset Watch, Unknown Stage, score 59.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Strategic Asset Watch, Unknown Stage, score 55.
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: General Asset Monitoring, Early Site Signal, score 50.
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: Low Priority, Unknown Stage, score 30.

## Recurring Asset Signals

- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Priority Asset Watch, Unknown Stage, score 90.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Priority Asset Watch, Site Acquisition / Site Control, score 86.
- Disposition / Exit - California - Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale: Priority Asset Watch, Site Acquisition / Site Control, score 86.
- Disposition / Exit - Sun Belt - Institutional Property Advisors Closes Sale and Arranges Financing for Dallas Multifamily...: Priority Asset Watch, Delivery / Opening, score 83.
- BTR / Build-to-Rent - Sun Belt - NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino: Priority Asset Watch, Delivery / Opening, score 82.
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: Priority Asset Watch, Unknown Stage, score 80.
- BTR / Build-to-Rent - Florida - Adam America Real Estate and Stellar Communities Deliver First Homes at Havens at Palm Bay...: Priority Asset Watch, Unknown Stage, score 78.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Priority Asset Watch, Refinancing / Recapitalization, score 78.
- Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades: Strategic Asset Watch, Site Acquisition / Site Control, score 69.
- General Project Signal - Los Angeles - Taylor Yard wetland takes shape, General Hospital update, and more: Strategic Asset Watch, Site Acquisition / Site Control, score 67.

## Implications for Woomi / Woomi Global

- Persistent asset memory helps convert article flow into a durable watchlist of recurring projects, sponsors, lifecycle stages, and risk signals.
- High-scoring assets should be reviewed for potential site precedent, GP outreach, underwriting comparables, or timing windows.

## Recommended Asset Memory Follow-up

- Create or refresh a project watch file with sponsor, site, entitlement, financing, and timing notes: Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments.
- Create or refresh a project watch file with sponsor, site, entitlement, financing, and timing notes: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.
- Create or refresh a project watch file with sponsor, site, entitlement, financing, and timing notes: Disposition / Exit - California - Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale.
- Create or refresh a project watch file with sponsor, site, entitlement, financing, and timing notes: Disposition / Exit - Sun Belt - Institutional Property Advisors Closes Sale and Arranges Financing for Dallas Multifamily....
- Create or refresh a project watch file with sponsor, site, entitlement, financing, and timing notes: BTR / Build-to-Rent - Sun Belt - NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino.
- Create or refresh a project watch file with sponsor, site, entitlement, financing, and timing notes: Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America.
- Create or refresh a project watch file with sponsor, site, entitlement, financing, and timing notes: BTR / Build-to-Rent - Florida - Adam America Real Estate and Stellar Communities Deliver First Homes at Havens at Palm Bay....
- Create or refresh a project watch file with sponsor, site, entitlement, financing, and timing notes: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.



## Signal Quality / Confidence Summary

- Signals evaluated: 100
- Institutional-grade signals: 7
- High-confidence signals: 19
- Weak/noisy signals: 72
- High-confidence watchlist items: 19
- See `signal_quality_report.md` and `high_confidence_watchlist_report.md` before using signals for executive decisions.

