# LA / Southern California Submarket Watch Report

Generated: 2026-05-18 16:30:55

- Total LA / Southern California submarkets detected: 13

## Top LA / Southern California Submarkets

- Los Angeles: opportunity 90, risk 52, Monitor only.
- Inland Empire: opportunity 86, risk 52, Inland Empire BTR / rental housing watch.
- Venice: opportunity 70, risk 30, Monitor only.
- Wilshire: opportunity 63, risk 30, Koreatown multifamily watch.
- DTLA: opportunity 62, risk 30, DTLA adaptive reuse watch.
- Santa Monica: opportunity 61, risk 46, Monitor only.
- Lincoln Heights: opportunity 57, risk 30, Monitor only.
- Culver City: opportunity 12, risk 30, Monitor only.
- Downtown Los Angeles: opportunity 12, risk 30, DTLA adaptive reuse watch.
- Ontario: opportunity 12, risk 30, Inland Empire BTR / rental housing watch.

## Koreatown / Wilshire Watch

- Wilshire: opportunity 63, risk 30, Koreatown multifamily watch.

## DTLA / Adaptive Reuse Watch

- DTLA: opportunity 62, risk 30, DTLA adaptive reuse watch.
- Downtown Los Angeles: opportunity 12, risk 30, DTLA adaptive reuse watch.

## Hollywood / Transit-Oriented Watch

- None detected.

## Pasadena / Entitlement Precedent Watch

- None detected.

## Long Beach / Mixed-Use Watch

- None detected.

## Orange County / Suburban Apartment Watch

- Orange County: opportunity 12, risk 30, Orange County suburban apartment watch.

## Inland Empire / BTR Watch

- Inland Empire: opportunity 86, risk 52, Inland Empire BTR / rental housing watch.
- Ontario: opportunity 12, risk 30, Inland Empire BTR / rental housing watch.

## LA Density Bonus / TOC Watch

- None detected.

## LA CEQA / Entitlement Risk Watch

- None detected.

## Recommended Local Follow-up Actions

- Track local planning docket and entitlement precedent: Los Angeles / Monitor only.
- Review potential acquisition pipeline: Inland Empire / Inland Empire BTR / rental housing watch.
- Track local planning docket and entitlement precedent: Venice / Monitor only.
- Review potential acquisition pipeline: Wilshire / Koreatown multifamily watch.
- Review potential acquisition pipeline: DTLA / DTLA adaptive reuse watch.
- Review potential acquisition pipeline: Santa Monica / Monitor only.
- Review potential acquisition pipeline: Lincoln Heights / Monitor only.
- Monitor only: Culver City / Monitor only.

## Asset / Parcel Intelligence Reference

Asset / parcel-level site clues are available in `asset_parcel_intelligence_report.md` and `la_asset_watch_report.md`.



## Development Lifecycle Intelligence Summary

- Lifecycle records: 54
- LA lifecycle watch items: 32
- Stage mix: Unknown Stage: 28, Vertical Construction: 4, Site Acquisition / Site Control: 8, Delivery / Opening: 9, Early Site Signal: 4
- See `development_lifecycle_report.md` and `la_development_lifecycle_watch_report.md` for project timing, entitlement, permit, construction, delivery, and refinancing stages.

