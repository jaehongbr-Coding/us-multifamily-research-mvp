# Deal Fingerprint Report

Generated: 2026-05-18 16:30:55

- Total canonical deals detected: 39
- Duplicate clusters detected: 0
- California / LA recurring project count: 13

## Largest Duplicate Clusters

- None detected.

## Strongest Recurring Projects

- None detected.

## Strongest Recurring Refinancing Events

- Construction Financing - Unknown - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 65.
- Construction Financing - Unknown - JLL - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 75.
- Construction Financing - Unknown - Other / Unknown: Other / Unknown, 1 article(s), 1 source(s), confidence 65.
- Construction Financing - Unknown - JLL - Other / Unknown: Other / Unknown, 1 article(s), 1 source(s), confidence 65.

## Recurring California / LA Projects

- Disposition / Exit - Quarterra - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 90.
- General Project Signal - Unknown - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 75.
- Construction Financing - Unknown - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 65.
- Entitlement / Permitting - Unknown - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 65.
- Entitlement / Permitting - Unknown - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 65.
- Construction Financing - Unknown - JLL - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 75.
- BTR / Build-to-Rent - Unknown - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 65.
- General Project Signal - Unknown - California: California, 1 article(s), 1 source(s), confidence 65.
- General Project Signal - Unknown - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 65.
- Disposition / Exit - Unknown - California: California, 1 article(s), 1 source(s), confidence 65.

## Recurring GP / Lender Relationships

- Disposition / Exit - Quarterra - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 90.
- BTR / Build-to-Rent - Unknown - National: National, 1 article(s), 1 source(s), confidence 75.
- Construction Financing - Unknown - JLL - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 75.
- General Project Signal - Unknown - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 75.
- JV / Partnership - Unknown - Sun Belt: Sun Belt, 1 article(s), 1 source(s), confidence 75.
- Acquisition - Alliance Residential - Sun Belt: Sun Belt, 1 article(s), 1 source(s), confidence 70.
- General Project Signal - Blackstone - New York: New York, 1 article(s), 1 source(s), confidence 70.
- Acquisition - Unknown - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 65.
- Acquisition - Unknown - National: National, 1 article(s), 1 source(s), confidence 65.
- Acquisition - Unknown - Other / Unknown: Other / Unknown, 1 article(s), 1 source(s), confidence 65.

## Most Frequently Referenced Developments

- Disposition / Exit - Quarterra - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 90.
- BTR / Build-to-Rent - Unknown - National: National, 1 article(s), 1 source(s), confidence 75.
- Construction Financing - Unknown - JLL - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 75.
- General Project Signal - Unknown - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 75.
- JV / Partnership - Unknown - Sun Belt: Sun Belt, 1 article(s), 1 source(s), confidence 75.
- Acquisition - Alliance Residential - Sun Belt: Sun Belt, 1 article(s), 1 source(s), confidence 70.
- General Project Signal - Blackstone - New York: New York, 1 article(s), 1 source(s), confidence 70.
- Acquisition - Unknown - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 65.
- Acquisition - Unknown - National: National, 1 article(s), 1 source(s), confidence 65.
- Acquisition - Unknown - Other / Unknown: Other / Unknown, 1 article(s), 1 source(s), confidence 65.

## Highest-Confidence Canonical Events

- Disposition / Exit - Quarterra - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 90.
