# Strategic Signal Quality Report

Generated: 2026-05-14 16:21:12

- Total signals evaluated: 85
- Institutional-grade signals: 4
- High-confidence signals: 14
- Weak/noisy signals: 61

## Strongest Recurring Signals

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Institutional Grade, score 94, 7 source file(s), 15 observation(s), latest stage Refinancing / Recapitalization, identity confidence 80.
- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: Institutional Grade, score 92, 5 source file(s), 5 observation(s), latest stage Site Acquisition / Site Control, identity confidence 100.
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: Institutional Grade, score 88, 8 source file(s), 10 observation(s), latest stage Unknown Stage, identity confidence 100.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: Institutional Grade, score 88, 4 source file(s), 4 observation(s), latest stage Refinancing / Recapitalization, identity confidence 80.
- Disposition / Exit - Other / Unknown - Marcus & Millichap Arranges Sale of 64-Unit Multifamily Property Waterview Apartments in L...: High Confidence, score 82, 7 source file(s), 40 observation(s), latest stage Delivery / Opening, identity confidence 80.
- Operational / Property Management Tech - Texas - Crypto rewards eye renters who want to save for a down payment: High Confidence, score 80, 5 source file(s), 5 observation(s), latest stage Unknown Stage, identity confidence 80.
- Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek in West Nashville.: High Confidence, score 78, 4 source file(s), 6 observation(s), latest stage Site Acquisition / Site Control, identity confidence 80.
- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco: High Confidence, score 77, 4 source file(s), 4 observation(s), latest stage Unknown Stage, identity confidence 80.
- BTR / Build-to-Rent - National - Trump Pushes House To Pass Housing Bill With BTR Forced-Sale Provision: High Confidence, score 75, 3 source file(s), 6 observation(s), latest stage Vertical Construction, identity confidence 80.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: High Confidence, score 72, 2 source file(s), 14 observation(s), latest stage Vertical Construction, identity confidence 80.

## Strongest LA / California Signals

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Institutional Grade, score 94, 7 source file(s), 15 observation(s), latest stage Refinancing / Recapitalization, identity confidence 80.
- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: Institutional Grade, score 92, 5 source file(s), 5 observation(s), latest stage Site Acquisition / Site Control, identity confidence 100.
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: Institutional Grade, score 88, 8 source file(s), 10 observation(s), latest stage Unknown Stage, identity confidence 100.
- Disposition / Exit - Other / Unknown - Marcus & Millichap Arranges Sale of 64-Unit Multifamily Property Waterview Apartments in L...: High Confidence, score 82, 7 source file(s), 40 observation(s), latest stage Delivery / Opening, identity confidence 80.
- Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek in West Nashville.: High Confidence, score 78, 4 source file(s), 6 observation(s), latest stage Site Acquisition / Site Control, identity confidence 80.
- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco: High Confidence, score 77, 4 source file(s), 4 observation(s), latest stage Unknown Stage, identity confidence 80.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: High Confidence, score 72, 2 source file(s), 14 observation(s), latest stage Vertical Construction, identity confidence 80.
- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: High Confidence, score 72, 3 source file(s), 5 observation(s), latest stage Unknown Stage, identity confidence 100.
- Crypto rewards eye renters who want to save for a down payment: High Confidence, score 70, 4 source file(s), 4 observation(s), latest stage Unknown Stage, identity confidence 80.
- Swedish Investor Selling 1,500-Unit Northern Virginia Portfolio: High Confidence, score 70, 4 source file(s), 4 observation(s), latest stage Unknown Stage, identity confidence 80.

## Most Persistent Projects

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Institutional Grade, score 94, 7 source file(s), 15 observation(s), latest stage Refinancing / Recapitalization, identity confidence 80.
- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: Institutional Grade, score 92, 5 source file(s), 5 observation(s), latest stage Site Acquisition / Site Control, identity confidence 100.
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: Institutional Grade, score 88, 8 source file(s), 10 observation(s), latest stage Unknown Stage, identity confidence 100.
- Disposition / Exit - Other / Unknown - Marcus & Millichap Arranges Sale of 64-Unit Multifamily Property Waterview Apartments in L...: High Confidence, score 82, 7 source file(s), 40 observation(s), latest stage Delivery / Opening, identity confidence 80.
- Operational / Property Management Tech - Texas - Crypto rewards eye renters who want to save for a down payment: High Confidence, score 80, 5 source file(s), 5 observation(s), latest stage Unknown Stage, identity confidence 80.
- Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek in West Nashville.: High Confidence, score 78, 4 source file(s), 6 observation(s), latest stage Site Acquisition / Site Control, identity confidence 80.
- BTR / Build-to-Rent - National - Trump Pushes House To Pass Housing Bill With BTR Forced-Sale Provision: High Confidence, score 75, 3 source file(s), 6 observation(s), latest stage Vertical Construction, identity confidence 80.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: High Confidence, score 72, 2 source file(s), 14 observation(s), latest stage Vertical Construction, identity confidence 80.
- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: High Confidence, score 72, 3 source file(s), 5 observation(s), latest stage Unknown Stage, identity confidence 100.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: High Confidence, score 71, 6 source file(s), 7 observation(s), latest stage Unknown Stage, identity confidence 80.

## Strongest Refinancing / Stress Signals

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Institutional Grade, score 94, 7 source file(s), 15 observation(s), latest stage Refinancing / Recapitalization, identity confidence 80.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: Institutional Grade, score 88, 4 source file(s), 4 observation(s), latest stage Refinancing / Recapitalization, identity confidence 80.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: High Confidence, score 71, 6 source file(s), 7 observation(s), latest stage Unknown Stage, identity confidence 80.
- Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal...: Moderate Confidence, score 68, 7 source file(s), 53 observation(s), latest stage Refinancing / Recapitalization, identity confidence 80.
- Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal...: Moderate Confidence, score 58, 2 source file(s), 30 observation(s), latest stage Delivery / Opening, identity confidence 80.
- Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal...: Weak Signal, score 54, 1 source file(s), 12 observation(s), latest stage Unknown Stage, identity confidence 80.
- Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Florida’s Space Coast: Weak Signal, score 52, 1 source file(s), 3 observation(s), latest stage Unknown Stage, identity confidence 100.
- CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Caldwell New Jersey: Weak Signal, score 42, 2 source file(s), 2 observation(s), latest stage Unknown Stage, identity confidence 80.
- CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Caldwell New Jersey: Weak Signal, score 42, 1 source file(s), 1 observation(s), latest stage Unknown Stage, identity confidence 100.

## Strongest Entitlement Progression Signals

- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco: High Confidence, score 77, 4 source file(s), 4 observation(s), latest stage Unknown Stage, identity confidence 80.
- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco: Moderate Confidence, score 64, 4 source file(s), 4 observation(s), latest stage Unknown Stage, identity confidence 80.
- Formal Permits For 375 Laguna Honda Boulevard, San Francisco: Weak Signal, score 51, 1 source file(s), 2 observation(s), latest stage Unknown Stage, identity confidence 100.
- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Weak Signal, score 50, 1 source file(s), 2 observation(s), latest stage Unknown Stage, identity confidence 80.
- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco: Weak Signal, score 50, 1 source file(s), 2 observation(s), latest stage Unknown Stage, identity confidence 80.
- Formal Permits For 375 Laguna Honda Boulevard, San Francisco: Weak Signal, score 45, 1 source file(s), 2 observation(s), latest stage Unknown Stage, identity confidence 80.
- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco: Weak Signal, score 42, 1 source file(s), 1 observation(s), latest stage Unknown Stage, identity confidence 80.
- Builders Stay Cautious as Single-Family Permits Weaken: Weak Signal, score 42, 1 source file(s), 1 observation(s), latest stage Unknown Stage, identity confidence 100.
- Entitlement / Permitting - Other / Unknown - Completion nears for mixed-use building at 3557 S. Motor Ave. in Palms: Noise Risk, score 38, 1 source file(s), 1 observation(s), latest stage Unknown Stage, identity confidence 80.

## Strongest Construction-Start Signals

- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: Institutional Grade, score 88, 4 source file(s), 4 observation(s), latest stage Refinancing / Recapitalization, identity confidence 80.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: High Confidence, score 72, 2 source file(s), 14 observation(s), latest stage Vertical Construction, identity confidence 80.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: High Confidence, score 71, 6 source file(s), 7 observation(s), latest stage Unknown Stage, identity confidence 80.
- Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal...: Moderate Confidence, score 68, 7 source file(s), 53 observation(s), latest stage Refinancing / Recapitalization, identity confidence 80.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Moderate Confidence, score 68, 4 source file(s), 15 observation(s), latest stage Unknown Stage, identity confidence 80.
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Moderate Confidence, score 60, 2 source file(s), 2 observation(s), latest stage Vertical Construction, identity confidence 80.
- Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal...: Moderate Confidence, score 58, 2 source file(s), 30 observation(s), latest stage Delivery / Opening, identity confidence 80.
- Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal...: Weak Signal, score 54, 1 source file(s), 12 observation(s), latest stage Unknown Stage, identity confidence 80.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Weak Signal, score 53, 1 source file(s), 2 observation(s), latest stage Unknown Stage, identity confidence 80.
- Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Florida’s Space Coast: Weak Signal, score 52, 1 source file(s), 3 observation(s), latest stage Unknown Stage, identity confidence 100.

## Implications for Woomi / Woomi Global

- Signal quality calibration helps separate institutional-grade project intelligence from noisy one-off mentions.
- High-quality signals should receive management attention before weaker signals inflate opportunity or lifecycle conclusions.

## Recommended Signal Quality Follow-up Actions

- Immediate strategic review: Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village... (Institutional Grade).
- Immediate strategic review: JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek... (Institutional Grade).
- Immediate strategic review: Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America (Institutional Grade).
- Immediate strategic review: General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl... (Institutional Grade).
- Add to executive watchlist: Disposition / Exit - Other / Unknown - Marcus & Millichap Arranges Sale of 64-Unit Multifamily Property Waterview Apartments in L... (High Confidence).
- Add to executive watchlist: Operational / Property Management Tech - Texas - Crypto rewards eye renters who want to save for a down payment (High Confidence).
- Add to executive watchlist: Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek in West Nashville. (High Confidence).
- Add to executive watchlist: Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco (High Confidence).
