# 한국어 GP Watchlist

- 생성 시각: 2026-05-14 16:21:11
- 참고 원문 파일: `gp_watchlist_report.md`
- 번역 방식: 규칙 기반 한국어 요약. OpenAI/GPT API는 호출하지 않음.

## 주요 GP Watchlist

- Crescent Communities: 기타 / 미확인, 일반 주거, 점수 66 (Tier 3 Monitoring GP; Potential GP partnership candidate)
- Blackstone: 기타 / 미확인, 일반 주거, 점수 58 (Tier 3 Monitoring GP; Potential GP partnership candidate)

## 기관자본 연결성

- Blackstone: 기타 / 미확인, 일반 주거, 점수 88 (Capital Inflow; Potential JV / Partnership Signal)
- Crescent Communities: 기타 / 미확인, 주거복합, 점수 77 (No Clear Capital Flow Signal; Potential JV / Partnership Signal)

## JV / Partnership 가능성

- Crescent Communities → JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: JV / Partnership, 점수 72
- Crescent Communities → Nashville: JV / Partnership, 점수 72
- Crescent Communities → Sun Belt: JV / Partnership, 점수 72
- JV / Partnership - Other / Unknown - Affordable Senior Housing Community Southernside West Set to Break Ground in Greenvillen S... → JV / Partnership - Other / Unknown - Affordable Senior Housing Community Southernside West Set to Break Ground in Greenvillen S...: JV / Partnership, 점수 46

## 우미 파트너십 관점

- GP 신호는 자본 파트너, 시장, 프로젝트 단계, 반복 출현 여부와 함께 검토합니다.
- LA / California 또는 기관자본 연결성이 있는 GP는 우선 Watch 대상입니다.
