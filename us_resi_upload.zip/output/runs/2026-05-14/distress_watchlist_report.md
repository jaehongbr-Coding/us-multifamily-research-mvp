# Distress Watchlist Report

Generated: 2026-05-14 16:21:11

- Total distress signals: 3

## Top Distress Watch Items

- refinancing stress in New York: Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village..., score 66. Track debt maturity, lender exposure, sponsor stress, and recapitalization options.
- bridge loan stress in Sun Belt: General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl..., score 59. Monitor for repeated distress signals.
- construction loan gap in Other / Unknown: Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal..., score 59. Monitor for repeated distress signals.

## Refinancing Stress Watch

- refinancing stress in New York: Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village..., score 66. Track debt maturity, lender exposure, sponsor stress, and recapitalization options.

## Construction Financing Gap Watch

- construction loan gap in Other / Unknown: Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal..., score 59. Monitor for repeated distress signals.

## Stalled Project Watch

- None detected.

## Distressed Seller / Sponsor Watch

- None detected.

## Timing / Market Entry Window Summary

Timing intelligence is available in `timing_intelligence_report.md`.
Market entry window scoring is available in `market_entry_window_report.md`.

## Deduplicated Distress Summary

Distress rows are checked against `deal_fingerprint_report.md` and `opportunity_deduplication_report.md`.
This helps avoid counting repeated refinancing or stalled-project coverage as separate distress events.

## Market Concentration of Distress Signals

- New York: 1 distress signal(s)
- Sun Belt: 1 distress signal(s)
- Other / Unknown: 1 distress signal(s)

## Implications for Woomi / Woomi Global

- Distress rows can highlight recapitalization, rescue capital, acquisition basis, or lender pressure themes to monitor.

## Recommended Next Actions

- Track debt maturity, lender exposure, sponsor stress, and recapitalization options: refinancing stress in New York.
- Monitor for repeated distress signals: bridge loan stress in Sun Belt.
- Monitor for repeated distress signals: construction loan gap in Other / Unknown.



## Development Lifecycle Intelligence Summary

- Lifecycle records: 48
- LA lifecycle watch items: 29
- Stage mix: Site Acquisition / Site Control: 5, Vertical Construction: 3, Refinancing / Recapitalization: 4, Unknown Stage: 26, Delivery / Opening: 7
- See `development_lifecycle_report.md` and `la_development_lifecycle_watch_report.md` for project timing, entitlement, permit, construction, delivery, and refinancing stages.




## Lifecycle Transition Summary

- Lifecycle transitions analyzed: 48
- Newly detected projects: 0
- Forward progression projects: 0
- Possible stalled projects: 0
- LA lifecycle transition watch items: 26
- See `lifecycle_transition_report.md` and `la_lifecycle_transition_watch_report.md` for multi-run project movement and timing signals.




## Persistent Asset Memory Summary

- Raw project references: 344
- Canonical projects: 85
- Duplicate project clusters: 46
- Persistent assets tracked: 85
- LA persistent asset watch items: 51
- See `project_identity_report.md`, `persistent_asset_memory_report.md`, and `la_persistent_asset_watch_report.md` for canonical project tracking.




## Signal Quality / Confidence Summary

- Signals evaluated: 85
- Institutional-grade signals: 4
- High-confidence signals: 14
- Weak/noisy signals: 61
- High-confidence watchlist items: 14
- See `signal_quality_report.md` and `high_confidence_watchlist_report.md` before using signals for executive decisions.

