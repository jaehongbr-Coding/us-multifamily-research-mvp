# Relationship Persistence Report

Generated: 2026-05-14 16:21:11

## Strongest Persistent GP Relationships

- Acquisition - Other / Unknown - Mapletree Pays $100M for 97-Acre Future Logistics Site in Central Jersey -> JLL (Financing Relationship): Durable, 24 observation(s), importance 100.
- BTR / Build-to-Rent - National - Trump Pushes House To Pass Housing Bill With BTR Forced-Sale Provision -> National (Market Expansion): Durable, 24 observation(s), importance 100.
- BTR / Build-to-Rent - Other / Unknown - JV Breaks Ground on South Carolina BTR Community -> BTR / Build-to-Rent - Other / Unknown - JV Breaks Ground on South Carolina BTR Community (Innovation / Construction Strategy): Durable, 5 observation(s), importance 100.
- Berkadia -> Berkadia (Financing Relationship): Durable, 24 observation(s), importance 100.
- Berkadia -> Sun Belt (Market Expansion): Durable, 48 observation(s), importance 100.
- Blackstone -> Blackstone (Capital Flow): Durable, 24 observation(s), importance 100.
- Blackstone -> Blackstone (Pricing / Valuation Signal): Durable, 24 observation(s), importance 100.
- Blackstone -> New York (Market Expansion): Durable, 24 observation(s), importance 100.
- CBRE -> CBRE (Financing Relationship): Durable, 24 observation(s), importance 100.
- Crescent Communities -> Los Angeles (JV / Partnership): Durable, 24 observation(s), importance 100.

## Most Durable Lender Relationships

- Acquisition - Other / Unknown - Mapletree Pays $100M for 97-Acre Future Logistics Site in Central Jersey -> JLL (Financing Relationship): Durable, 24 observation(s), importance 100.
- Berkadia -> Berkadia (Financing Relationship): Durable, 24 observation(s), importance 100.
- CBRE -> CBRE (Financing Relationship): Durable, 24 observation(s), importance 100.
- Fannie Mae -> New York (Financing Relationship): Durable, 24 observation(s), importance 100.
- Fannie Mae -> Fannie Mae (Financing Relationship): Durable, 24 observation(s), importance 100.

## Recurring JV Structures

- Crescent Communities -> Los Angeles (JV / Partnership): Durable, 24 observation(s), importance 100.
- Crescent Communities -> Sun Belt (JV / Partnership): Durable, 48 observation(s), importance 100.
- JV / Partnership - Other / Unknown - Affordable Senior Housing Community Southernside West Set to Break Ground in Greenvillen S... -> JV / Partnership - Other / Unknown - Affordable Senior Housing Community Southernside West Set to Break Ground in Greenvillen S... (JV / Partnership): Durable, 24 observation(s), importance 100.
- Los Angeles -> California (JV / Partnership): Durable, 22 observation(s), importance 100.

## Repeat Market-Entry Patterns

- BTR / Build-to-Rent - National - Trump Pushes House To Pass Housing Bill With BTR Forced-Sale Provision -> National (Market Expansion): Durable, 24 observation(s), importance 100.
- Berkadia -> Sun Belt (Market Expansion): Durable, 48 observation(s), importance 100.
- Blackstone -> New York (Market Expansion): Durable, 24 observation(s), importance 100.
- Development Start - Other / Unknown - Fourth Quarter 2025 Multifamily Construction Data -> Development Start - Other / Unknown - Fourth Quarter 2025 Multifamily Construction Data (Development Activity): Durable, 24 observation(s), importance 100.
- Development Start - Other / Unknown - Missing Middle Weakness -> Development Start - Other / Unknown - Missing Middle Weakness (Development Activity): Durable, 24 observation(s), importance 100.
- Development Start - Other / Unknown - Overall Housing Starts Inch Lower in 2025 -> Development Start - Other / Unknown - Overall Housing Starts Inch Lower in 2025 (Development Activity): Durable, 24 observation(s), importance 100.
- Development Start - Other / Unknown - Third Quarter 2025 Multifamily Construction Data -> Development Start - Other / Unknown - Third Quarter 2025 Multifamily Construction Data (Development Activity): Durable, 24 observation(s), importance 100.
- Los Angeles -> Southeast (Market Expansion): Durable, 24 observation(s), importance 100.
- Los Angeles -> Texas (Market Expansion): Durable, 5 observation(s), importance 100.
- Los Angeles -> New York (Market Expansion): Durable, 24 observation(s), importance 100.

## Repeated California / LA Partnerships

- Los Angeles -> Southeast (Market Expansion): Durable, 24 observation(s), importance 100.
- Los Angeles -> Los Angeles (Disposition / Seller): Durable, 5 observation(s), importance 100.
- Los Angeles -> San Francisco (Entitlement / Permitting): Durable, 24 observation(s), importance 100.
- Los Angeles -> California (JV / Partnership): Durable, 22 observation(s), importance 100.
- Los Angeles -> Los Angeles (Market Expansion): Durable, 96 observation(s), importance 100.
- Los Angeles -> Los Angeles (Entitlement / Permitting): Durable, 24 observation(s), importance 100.
- Los Angeles -> California (Entitlement / Permitting): Durable, 24 observation(s), importance 100.
