# LA Persistent Asset Watch Report

Generated: 2026-05-14 16:21:12

- Total LA persistent asset watch items: 51

## Priority LA Asset Watch Items

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Los Angeles, Refinancing / Recapitalization, Track repeat project updates.
- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: Los Angeles, Site Acquisition / Site Control, Track repeat project updates.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, Vertical Construction, Track repeat project updates.
- Disposition / Exit - Other / Unknown - Marcus & Millichap Arranges Sale of 64-Unit Multifamily Property Waterview Apartments in L...: Los Angeles, Delivery / Opening, Track repeat project updates.
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: Los Angeles, Unknown Stage, Track repeat project updates.
- Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek in West Nashville.: Los Angeles, Site Acquisition / Site Control, Track repeat project updates.

## Koreatown / Wilshire Persistent Assets

- None detected.

## DTLA Persistent Assets

- None detected.

## Hollywood Persistent Assets

- None detected.

## Pasadena Persistent Assets

- None detected.

## Orange County Persistent Assets

- None detected.

## Stalled / Delayed LA Asset Watch

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Los Angeles, Refinancing / Recapitalization, Track repeat project updates.
- Disposition / Exit - Other / Unknown - Marcus & Millichap Arranges Sale of 64-Unit Multifamily Property Waterview Apartments in L...: Los Angeles, Delivery / Opening, Track repeat project updates.

## Construction / Delivery Transition Watch

- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, Vertical Construction, Track repeat project updates.
- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: Los Angeles, Delivery / Opening, Track repeat project updates.
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Lincoln Heights, Vertical Construction, Track repeat project updates.
- Disposition / Exit - Other / Unknown - Marcus & Millichap Arranges Sale of 64-Unit Multifamily Property Waterview Apartments in L...: Los Angeles, Delivery / Opening, Track repeat project updates.
- Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: California, Delivery / Opening, Track repeat project updates.

## Recommended Local Follow-up Actions

- Monitor for repeated project updates: General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd..
- Monitor for repeated project updates: General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd..
- Monitor for repeated project updates: General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts.
- Monitor for repeated project updates: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.
- Monitor for repeated project updates: Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena.
- Monitor for repeated project updates: General Project Signal - Other / Unknown - 22 homes pitched for 1072 E. Villa St. in Pasadena.
- Create or refresh a project watch file with sponsor, site, entitlement, financing, and timing notes: Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village....
- Create or refresh a project watch file with sponsor, site, entitlement, financing, and timing notes: JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek....
