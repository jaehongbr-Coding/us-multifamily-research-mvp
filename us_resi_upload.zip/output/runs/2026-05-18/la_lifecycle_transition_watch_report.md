# LA Lifecycle Transition Watch Report

Generated: 2026-05-18 16:30:57

- Total LA lifecycle transition watch items: 30

## LA Projects Moving Forward

- None detected.

## LA Projects With Stall Risk

- None detected.

## LA Permit / Construction Start Watch

- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Vertical Construction -> Vertical Construction, Construction start watch.
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Vertical Construction -> Vertical Construction, Construction start watch.
- Development Start - Los Angeles - The Broad's $100M expansion tops out in DTLA: Vertical Construction -> Vertical Construction, Construction start watch.

## LA Refinancing / Recap Timing Watch

- Cypress Equity Investments gets $170M loan for two Santa Monica projects: Refinancing / Recapitalization -> Refinancing / Recapitalization, Refinancing / recap timing watch.

## LA Delivery / Lease-Up Benchmarks

- Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles: Delivery / Opening -> Delivery / Opening, Delivery / lease-up benchmark.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Delivery / Opening -> Delivery / Opening, Delivery / lease-up benchmark.
- Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Delivery / Opening -> Delivery / Opening, Delivery / lease-up benchmark.
- Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles: Delivery / Opening -> Delivery / Opening, Delivery / lease-up benchmark.
- BTR / Build-to-Rent - Sun Belt - NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino: Delivery / Opening -> Delivery / Opening, Delivery / lease-up benchmark.
- Disposition / Exit - Sun Belt - Institutional Property Advisors Closes Sale and Arranges Financing for Dallas Multifamily...: Delivery / Opening -> Delivery / Opening, Delivery / lease-up benchmark.
- NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino: Delivery / Opening -> Delivery / Opening, Delivery / lease-up benchmark.

## Recommended LA Transition Follow-up Actions

- Use as delivery, lease-up, and underwriting benchmark: Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles.
- Use as delivery, lease-up, and underwriting benchmark: General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd..
- Monitor for another run to confirm lifecycle direction: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.
- Monitor for another run to confirm lifecycle direction: Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.
- Monitor for another run to confirm lifecycle direction: Development Start - Los Angeles - The Broad's $100M expansion tops out in DTLA.
- Use as delivery, lease-up, and underwriting benchmark: Onni Group plans twin 67-story towers at 5700 Wilshire Blvd..
- Use as delivery, lease-up, and underwriting benchmark: Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles.
- Use as delivery, lease-up, and underwriting benchmark: BTR / Build-to-Rent - Sun Belt - NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino.



## Persistent Asset Memory Summary

- Raw project references: 405
- Canonical projects: 100
- Duplicate project clusters: 55
- Persistent assets tracked: 100
- LA persistent asset watch items: 65
- See `project_identity_report.md`, `persistent_asset_memory_report.md`, and `la_persistent_asset_watch_report.md` for canonical project tracking.

