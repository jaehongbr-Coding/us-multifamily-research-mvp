# Narrative Regime Detection

Generated: 2026-05-14 16:21:11

## Detected Regime

- Primary regime: Developer Strategy Shift
- Secondary regime: None detected
- Confidence level: High
- Explanation: Developer strategy, adaptive reuse, product strategy, or operating model signals are a meaningful part of the current briefing set.

## Regime Scorecard

| Regime | Score |
| --- | ---: |
| Developer Strategy Shift | 85 |
| Financing Stress | 48 |
| Supply Pressure | 42 |
| Selective Capital Re-entry | 40 |
| Policy / Entitlement Watch | 10 |
| Construction Cost Pressure | 0 |

## Regime Heatmap Reference

Calibrated 0-100 heatmap scores are available in `regime_heatmap_report.md` and `regime_heatmap.csv`.
Regime momentum is available in `regime_momentum_report.md` when previous heatmap history exists.

| Regime | Final Score | Strength |
| --- | ---: | --- |
| Supply Pressure | 79 | Strong |
| Financing Stress | 69 | Strong |
| Selective Capital Re-entry | 68 | Strong |
| Developer Strategy Shift | 53 | Moderate |
| Policy / Entitlement Watch | 41 | Moderate |
| Construction Cost Pressure | 3 | Not Detected |
| Stable Monitoring Environment | 0 | Not Detected |

## Signal Inputs

- Strategy-briefing articles reviewed: 27
- Market-signal articles reviewed: 19
- Articles with extracted numbers: 19
- Institutional player mentions: 4

### Strategic Angles

- Developer Strategy: 17
- Financing Risk: 8
- Rent Growth / Demand: 6
- Institutional Flow: 6
- Supply Pressure: 4
- Regulation Risk: 2

### Market Signals

- Rent Growth Signal: 11
- Supply / Starts Signal: 5
- Financing Cost Signal: 1
- Vacancy Signal: 1
- Deal Size Signal: 1

### Decision Uses

- Track Developer Strategy: 17
- Track Financing Conditions: 8
- Track Rent / Vacancy Trend: 6
- Track Institutional Capital Flow: 6
- Track Supply Pipeline: 4
- Track Regulation Risk: 2

### Market Focus

- Other / Unknown: 12
- Los Angeles: 5
- National: 4
- New York: 3
- Sun Belt: 2
- California: 1

### Action Levels

- Must Read: 17
- Review: 8
- Monitor: 2

### Woomi Relevance

- High relevance to US residential developer strategy: 19
- Medium relevance to market monitoring: 8

## Key Thematic Context

- No major thematic increase alert was detected in this run.

## Cross-Theme Interpretation

- Financing stress plus supply pressure may call for more conservative underwriting, especially around leverage, lease-up pace, and exit cap rates.
- Institutional flow plus cap rate or deal-size signals may indicate pricing discovery by major capital players.
- California / LA focus plus policy signals may indicate entitlement, zoning, rent control, or housing-production opportunity and risk.

## Implications for Woomi / Woomi Global

- Keep LA / California monitoring active because local policy, entitlement, and supply signals are directly relevant to market-entry planning.
- Track institutional capital flow to identify pricing signals, partnership targets, and markets where capital may be returning selectively.
- Use developer strategy signals to build US residential development capabilities around product type, delivery model, and GP partnership structure.

## Recommended Strategy Team Questions

- Are financing conditions changing enough to affect new development starts, refinancing, or exit cap assumptions?
- Are supply signals concentrated in specific markets, product types, or lease-up windows?
- Are institutional buyers returning to markets, assets, or capital structures relevant to Woomi?
- Are LA / California policy changes creating entitlement opportunities or risks?
