# LA / Southern California Asset Watch Report

Generated: 2026-05-18 16:30:56

- Total LA / Southern California asset watch items: 32

## Top LA Site-Level Opportunities

- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: Los Angeles, Entitlement Play, la_asset_opportunity_score 100.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, Affordable / Density Bonus Strategy, la_asset_opportunity_score 100.
- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Los Angeles, General Asset Signal, la_asset_opportunity_score 100.
- Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave.: Los Angeles, Affordable / Density Bonus Strategy, la_asset_opportunity_score 100.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Los Angeles, Lease-Up / Delivery, la_asset_opportunity_score 100.
- Acquisition - Other / Unknown - Guardian Acquires 332-Unit Ladd Tower Apartment Building in Downtown Portland: Los Angeles, Acquisition / Site Control, la_asset_opportunity_score 100.
- Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles: Los Angeles, Lease-Up / Delivery, la_asset_opportunity_score 90.
- 96 apartments + retail proposed at 8871 W. Venice Blvd.: Los Angeles, Entitlement Play, la_asset_opportunity_score 90.
- Metro partners with developer on plans for housing at G Line's Balboa Station: Los Angeles, Affordable / Density Bonus Strategy, la_asset_opportunity_score 90.
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, Affordable / Density Bonus Strategy, la_asset_opportunity_score 90.

## Top LA Site-Level Risks

- Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles: Los Angeles, Lease-Up / Delivery, la_asset_risk_score 56.
- Construction Financing - Other / Unknown - Cypress Equity Investments gets $170M loan for two Santa Monica projects: Los Angeles, General Asset Signal, la_asset_risk_score 54.
- Acquisition - Los Angeles - JLL Arranges Sale of 365,774 SF Industrial Portfolio Near Los Angeles Across Two Separate...: Los Angeles, General Asset Signal, la_asset_risk_score 52.
- Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades: Los Angeles, General Asset Signal, la_asset_risk_score 50.
- Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd.: Los Angeles, Entitlement Play, la_asset_risk_score 40.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, Affordable / Density Bonus Strategy, la_asset_risk_score 40.
- 96 apartments + retail proposed at 8871 W. Venice Blvd.: Los Angeles, Entitlement Play, la_asset_risk_score 40.
- Metro partners with developer on plans for housing at G Line's Balboa Station: Los Angeles, Affordable / Density Bonus Strategy, la_asset_risk_score 40.
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, Affordable / Density Bonus Strategy, la_asset_risk_score 40.
- General Project Signal - California - Metro partners with developer on plans for housing at G Line's Balboa Station: Los Angeles, General Asset Signal, la_asset_risk_score 40.

## Koreatown / Wilshire Site Watch

- None detected.

## DTLA / Office Conversion Site Watch

- None detected.

## Hollywood / TOD Site Watch

- None detected.

## Pasadena / Entitlement Watch

- None detected.

## Orange County / Suburban Apartment Watch

- None detected.

## Inland Empire / BTR Watch

- None detected.

## Local Sponsor / Developer Watch

- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: Los Angeles, General Asset Signal, la_asset_opportunity_score 100.
- General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve...: Los Angeles, General Asset Signal, la_asset_opportunity_score 72.

## Recommended LA Asset Follow-up Actions

- Review parcel clue, entitlement path, sponsor, and comparable sites: Entitlement / Permitting - Los Angeles - 96 apartments + retail proposed at 8871 W. Venice Blvd..
- Review parcel clue, entitlement path, sponsor, and comparable sites: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.
- Review parcel clue, entitlement path, sponsor, and comparable sites: Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments.
- Review parcel clue, entitlement path, sponsor, and comparable sites: Entitlement / Permitting - Los Angeles - Site prep underway for affordable housing at 4301 S. Vermont Ave..
- Review parcel clue, entitlement path, sponsor, and comparable sites: General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd..
- Monitor asset for repeated local confirmation: Acquisition - Other / Unknown - Guardian Acquires 332-Unit Ladd Tower Apartment Building in Downtown Portland.
- Review parcel clue, entitlement path, sponsor, and comparable sites: Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles.
- Review parcel clue, entitlement path, sponsor, and comparable sites: 96 apartments + retail proposed at 8871 W. Venice Blvd..



## Development Lifecycle Intelligence Summary

- Lifecycle records: 54
- LA lifecycle watch items: 32
- Stage mix: Unknown Stage: 28, Vertical Construction: 4, Site Acquisition / Site Control: 8, Delivery / Opening: 9, Early Site Signal: 4
- See `development_lifecycle_report.md` and `la_development_lifecycle_watch_report.md` for project timing, entitlement, permit, construction, delivery, and refinancing stages.




## Lifecycle Transition Summary

- Lifecycle transitions analyzed: 54
- Newly detected projects: 0
- Forward progression projects: 0
- Possible stalled projects: 0
- LA lifecycle transition watch items: 30
- See `lifecycle_transition_report.md` and `la_lifecycle_transition_watch_report.md` for multi-run project movement and timing signals.




## Persistent Asset Memory Summary

- Raw project references: 405
- Canonical projects: 100
- Duplicate project clusters: 55
- Persistent assets tracked: 100
- LA persistent asset watch items: 65
- See `project_identity_report.md`, `persistent_asset_memory_report.md`, and `la_persistent_asset_watch_report.md` for canonical project tracking.

