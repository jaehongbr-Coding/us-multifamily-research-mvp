# Deal Fingerprint Report

Generated: 2026-05-14 16:21:11

- Total canonical deals detected: 31
- Duplicate clusters detected: 0
- California / LA recurring project count: 6

## Largest Duplicate Clusters

- None detected.

## Strongest Recurring Projects

- None detected.

## Strongest Recurring Refinancing Events

- Refinancing - Unknown - Fannie Mae - New York: New York, 1 article(s), 1 source(s), confidence 85.
- Construction Financing - Unknown - CBRE - Other / Unknown: Other / Unknown, 1 article(s), 1 source(s), confidence 65.

## Recurring California / LA Projects

- General Project Signal - Unknown - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 75.
- General Project Signal - Unknown - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 65.
- General Project Signal - Unknown - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 65.
- General Project Signal - Unknown - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 65.
- Entitlement / Permitting - Unknown - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 55.
- Entitlement / Permitting - Unknown - California: California, 1 article(s), 1 source(s), confidence 55.

## Recurring GP / Lender Relationships

- Refinancing - Unknown - Fannie Mae - New York: New York, 1 article(s), 1 source(s), confidence 85.
- Disposition / Exit - Unknown - Sun Belt: Sun Belt, 1 article(s), 1 source(s), confidence 75.
- General Project Signal - Unknown - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 75.
- General Project Signal - Unknown - Sun Belt: Sun Belt, 1 article(s), 1 source(s), confidence 75.
- General Project Signal - Blackstone - New York: New York, 1 article(s), 1 source(s), confidence 70.
- JV / Partnership - Crescent Communities - Sun Belt: Sun Belt, 1 article(s), 1 source(s), confidence 70.
- Acquisition - Unknown - Other / Unknown: Other / Unknown, 1 article(s), 1 source(s), confidence 65.
- Construction Financing - Unknown - CBRE - Other / Unknown: Other / Unknown, 1 article(s), 1 source(s), confidence 65.
- Development Start - Unknown - National: National, 1 article(s), 1 source(s), confidence 65.
- Entitlement / Permitting - Unknown - Other / Unknown: Other / Unknown, 1 article(s), 1 source(s), confidence 65.

## Most Frequently Referenced Developments

- Refinancing - Unknown - Fannie Mae - New York: New York, 1 article(s), 1 source(s), confidence 85.
- Disposition / Exit - Unknown - Sun Belt: Sun Belt, 1 article(s), 1 source(s), confidence 75.
- General Project Signal - Unknown - Los Angeles: Los Angeles, 1 article(s), 1 source(s), confidence 75.
- General Project Signal - Unknown - Sun Belt: Sun Belt, 1 article(s), 1 source(s), confidence 75.
- General Project Signal - Blackstone - New York: New York, 1 article(s), 1 source(s), confidence 70.
- JV / Partnership - Crescent Communities - Sun Belt: Sun Belt, 1 article(s), 1 source(s), confidence 70.
- Acquisition - Unknown - Other / Unknown: Other / Unknown, 1 article(s), 1 source(s), confidence 65.
- Construction Financing - Unknown - CBRE - Other / Unknown: Other / Unknown, 1 article(s), 1 source(s), confidence 65.
- Development Start - Unknown - National: National, 1 article(s), 1 source(s), confidence 65.
- Entitlement / Permitting - Unknown - Other / Unknown: Other / Unknown, 1 article(s), 1 source(s), confidence 65.

## Highest-Confidence Canonical Events

- Refinancing - Unknown - Fannie Mae - New York: New York, 1 article(s), 1 source(s), confidence 85.
