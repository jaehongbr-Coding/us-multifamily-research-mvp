# Regime Transition Report

Generated: 2026-05-18 16:30:57

## Summary

- Current primary regime: Developer Strategy Shift
- Previous primary regime: Developer Strategy Shift
- Regime changed: No
- Consecutive runs in current regime: 48
- Confidence direction: stable
- Market signals direction: stable
- Transition label: Persistent Regime

## Recent Regime History

| Run Timestamp | Primary Regime | Secondary Regime | Confidence | Market Signals | Top Strategic Angle | Top Market Focus | Top Market Signal |
| --- | --- | --- | --- | ---: | --- | --- | --- |
| 2026-05-18 15:09:27 | Developer Strategy Shift | Selective Capital Re-entry | High | 23 | Developer Strategy | Other / Unknown | Rent Growth Signal |
| 2026-05-18 15:18:25 | Developer Strategy Shift | Selective Capital Re-entry | High | 23 | Developer Strategy | Other / Unknown | Rent Growth Signal |
| 2026-05-18 15:50:18 | Developer Strategy Shift | Selective Capital Re-entry | High | 23 | Developer Strategy | Other / Unknown | Rent Growth Signal |
| 2026-05-18 16:09:30 | Developer Strategy Shift | Selective Capital Re-entry | High | 23 | Developer Strategy | Other / Unknown | Rent Growth Signal |
| 2026-05-18 16:30:54 | Developer Strategy Shift | Selective Capital Re-entry | High | 23 | Developer Strategy | Other / Unknown | Rent Growth Signal |

## Historical Persistence Summary

Regime and signal memory is available in `historical_memory_report.md`.
Capital-flow memory is available in `capital_flow_report.md`.
Recurring relationship tracking is available in `relationship_persistence_report.md`.

## Strategy Interpretation

- Developer Strategy Shift persistence may indicate changes in product strategy, partnerships, adaptive reuse, or delivery models.
- Market-signal volume is stable compared with the previous run.
