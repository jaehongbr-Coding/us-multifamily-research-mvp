# High Confidence Watchlist Report

Generated: 2026-05-18 16:30:57

- Total high-confidence watchlist items: 19

## Top Institutional-Grade Opportunities

- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: LA urban infill opportunity, quality 91, action: Review immediately.
- Disposition / Exit - California - Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale: LA urban infill opportunity, quality 90, action: Review immediately.
- BTR / Build-to-Rent - Sun Belt - NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino: BTR expansion, quality 89, action: Review immediately.
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: Institutional capital movement, quality 88, action: Review immediately.
- Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee: Construction start pipeline, quality 86, action: Review immediately.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Construction start pipeline, quality 86, action: Review immediately.
- Disposition / Exit - Sun Belt - Institutional Property Advisors Closes Sale and Arranges Financing for Dallas Multifamily...: LA urban infill opportunity, quality 85, action: Review immediately.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Refinancing opportunity, quality 82, action: Watch refinancing timing.
- BTR / Build-to-Rent - Florida - Adam America Real Estate and Stellar Communities Deliver First Homes at Havens at Palm Bay...: BTR expansion, quality 81, action: Maintain on strategic radar.
- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: LA urban infill opportunity, quality 80, action: Monitor sponsor relationship.

## Top Institutional-Grade Risks

- None detected.

## Strongest LA / Southern California Watch Items

- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: LA urban infill opportunity, quality 91, action: Review immediately.
- Disposition / Exit - California - Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale: LA urban infill opportunity, quality 90, action: Review immediately.
- BTR / Build-to-Rent - Sun Belt - NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino: BTR expansion, quality 89, action: Review immediately.
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: Institutional capital movement, quality 88, action: Review immediately.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Construction start pipeline, quality 86, action: Review immediately.
- Disposition / Exit - Sun Belt - Institutional Property Advisors Closes Sale and Arranges Financing for Dallas Multifamily...: LA urban infill opportunity, quality 85, action: Review immediately.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Refinancing opportunity, quality 82, action: Watch refinancing timing.
- BTR / Build-to-Rent - Florida - Adam America Real Estate and Stellar Communities Deliver First Homes at Havens at Palm Bay...: BTR expansion, quality 81, action: Maintain on strategic radar.
- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: LA urban infill opportunity, quality 80, action: Monitor sponsor relationship.
- Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades: Construction start pipeline, quality 76, action: Monitor construction execution.

## Strongest GP / Developer Signals

- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: LA urban infill opportunity, quality 91, action: Review immediately.
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: Institutional capital movement, quality 88, action: Review immediately.
- Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee: Construction start pipeline, quality 86, action: Review immediately.
- Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments: LA urban infill opportunity, quality 80, action: Monitor sponsor relationship.
- Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee: Institutional capital movement, quality 70, action: Monitor sponsor relationship.

## Strongest Capital Flow Signals

- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: Institutional capital movement, quality 88, action: Review immediately.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Refinancing opportunity, quality 82, action: Watch refinancing timing.
- JV / Partnership - Sun Belt - CFAM, RPM Living Acquire 380-Unit Waterfront Multifamily Community in North Miami: Institutional capital movement, quality 79, action: Maintain on strategic radar.
- Acquisition - Sun Belt - Outrigger Industrial Sells 1 MSF Building at Generation Park in Northeast Houston: Institutional capital movement, quality 78, action: Maintain on strategic radar.
- Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee: Institutional capital movement, quality 70, action: Monitor sponsor relationship.

## Strongest Refinancing Opportunities

- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Refinancing opportunity, quality 82, action: Watch refinancing timing.

## Strongest Construction-Ready Opportunities

- Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee: Construction start pipeline, quality 86, action: Review immediately.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Construction start pipeline, quality 86, action: Review immediately.
- Construction Financing - Los Angeles - Hyatt in SoCal’s Inland Empire Secures $104M to Finance Upgrades: Construction start pipeline, quality 76, action: Monitor construction execution.
- Construction Financing - Other / Unknown - JLL Arranged $75M Construction Financing for Innovative Multi-Housing Development The VIC...: Construction start pipeline, quality 70, action: Monitor construction execution.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Construction start pipeline, quality 70, action: Monitor construction execution.

## Recommended Executive Actions

- Review immediately: Disposition / Exit - Los Angeles - Quarterra Seeks Buyers For Almost 4,000 Apartments.
- Review immediately: Disposition / Exit - California - Institutional Property Advisors Closes $48.5M Inland Empire Multifamily Asset Sale.
- Review immediately: BTR / Build-to-Rent - Sun Belt - NexMetro Opening 24th New Build-to-Rent Community in Phoenix Market Avilla Bella Camino.
- Review immediately: Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America.
- Review immediately: Acquisition - Sun Belt - Alliance Residential to Develop 312-Unit Apartment Community in Mt. Juliet, Tennessee.
- Review immediately: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.
- Review immediately: Disposition / Exit - Sun Belt - Institutional Property Advisors Closes Sale and Arranges Financing for Dallas Multifamily....
- Watch refinancing timing: General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights.
