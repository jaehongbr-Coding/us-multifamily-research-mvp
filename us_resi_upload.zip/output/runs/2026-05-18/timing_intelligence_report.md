# Timing Intelligence Report

Generated: 2026-05-18 16:30:55

- Total timing signals detected: 30

## Top Timing Signals

- Entitlement / Permitting in Other / Unknown: in 2024, score 78, Weekly monitoring. Track entitlement, zoning, permitting, and public-agency milestones.
- Entitlement / Permitting in Los Angeles: No explicit timing reference, score 73, Biweekly monitoring. Track entitlement, zoning, permitting, and public-agency milestones.
- Entitlement / Permitting in Los Angeles: No explicit timing reference, score 73, Biweekly monitoring. Track entitlement, zoning, permitting, and public-agency milestones.
- BTR / SFR Expansion Timing in Los Angeles: No explicit timing reference, score 71, Biweekly monitoring. Monitor sector-specific platform timing and potential partnership relevance.
- Construction Completion / Delivery in Los Angeles: No explicit timing reference, score 71, Biweekly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Construction Start in Other / Unknown: 2025, score 70, Weekly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Construction Start in Other / Unknown: in 2025, score 70, Weekly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Construction Start in Other / Unknown: 2025, score 70, Weekly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Acquisition Window in Other / Unknown: No explicit timing reference, score 67, Biweekly monitoring. Monitor pricing evidence and possible acquisition outreach timing.
- Distress Sale Timing in Los Angeles: No explicit timing reference, score 65, Biweekly monitoring. Prepare sponsor, lender, and rescue-capital watchlist.

## Refinancing / Maturity Timing Watch

- None detected.

## Construction Start / Delivery Watch

- Construction Completion / Delivery in Los Angeles: No explicit timing reference, score 71, Biweekly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Construction Start in Other / Unknown: 2025, score 70, Weekly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Construction Start in Other / Unknown: in 2025, score 70, Weekly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Construction Start in Other / Unknown: 2025, score 70, Weekly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Construction Completion / Delivery in Sun Belt: No explicit timing reference, score 63, Monthly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Construction Start in Sun Belt: No explicit timing reference, score 63, Monthly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Construction Start in Other / Unknown: No explicit timing reference, score 58, Monthly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Construction Completion / Delivery in Other / Unknown: No explicit timing reference, score 53, Monthly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Construction Start in Los Angeles: No explicit timing reference, score 51, Monthly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.

## Entitlement / Permitting Timing Watch

- Entitlement / Permitting in Other / Unknown: in 2024, score 78, Weekly monitoring. Track entitlement, zoning, permitting, and public-agency milestones.
- Entitlement / Permitting in Los Angeles: No explicit timing reference, score 73, Biweekly monitoring. Track entitlement, zoning, permitting, and public-agency milestones.
- Entitlement / Permitting in Los Angeles: No explicit timing reference, score 73, Biweekly monitoring. Track entitlement, zoning, permitting, and public-agency milestones.
- Entitlement / Permitting in Other / Unknown: No explicit timing reference, score 50, Monthly monitoring. Track entitlement, zoning, permitting, and public-agency milestones.

## Acquisition / Capital Re-entry Timing Watch

- Acquisition Window in Other / Unknown: No explicit timing reference, score 67, Biweekly monitoring. Monitor pricing evidence and possible acquisition outreach timing.
- Acquisition Window in Other / Unknown: No explicit timing reference, score 63, Monthly monitoring. Monitor pricing evidence and possible acquisition outreach timing.
- Acquisition Window in Los Angeles: No explicit timing reference, score 57, Monthly monitoring. Monitor pricing evidence and possible acquisition outreach timing.
- Acquisition Window in Sun Belt: No explicit timing reference, score 56, Monthly monitoring. Monitor pricing evidence and possible acquisition outreach timing.
- Acquisition Window in National: No explicit timing reference, score 53, Monthly monitoring. Monitor pricing evidence and possible acquisition outreach timing.
- Acquisition Window in Other / Unknown: No explicit timing reference, score 53, Monthly monitoring. Monitor pricing evidence and possible acquisition outreach timing.
- Acquisition Window in Sun Belt: No explicit timing reference, score 53, Monthly monitoring. Monitor pricing evidence and possible acquisition outreach timing.
- Acquisition Window in National: No explicit timing reference, score 51, Monthly monitoring. Monitor pricing evidence and possible acquisition outreach timing.

## LA / California Timing Signals

- Entitlement / Permitting in Los Angeles: No explicit timing reference, score 73, Biweekly monitoring. Track entitlement, zoning, permitting, and public-agency milestones.
- Entitlement / Permitting in Los Angeles: No explicit timing reference, score 73, Biweekly monitoring. Track entitlement, zoning, permitting, and public-agency milestones.
- BTR / SFR Expansion Timing in Los Angeles: No explicit timing reference, score 71, Biweekly monitoring. Monitor sector-specific platform timing and potential partnership relevance.
- Construction Completion / Delivery in Los Angeles: No explicit timing reference, score 71, Biweekly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.
- Distress Sale Timing in Los Angeles: No explicit timing reference, score 65, Biweekly monitoring. Prepare sponsor, lender, and rescue-capital watchlist.
- Distress Sale Timing in Los Angeles: No explicit timing reference, score 65, Biweekly monitoring. Prepare sponsor, lender, and rescue-capital watchlist.
- Acquisition Window in Los Angeles: No explicit timing reference, score 57, Monthly monitoring. Monitor pricing evidence and possible acquisition outreach timing.
- Construction Start in Los Angeles: No explicit timing reference, score 51, Monthly monitoring. Monitor delivery, lease-up, concession, and supply pipeline timing.

## BTR / SFR Timing Signals

- BTR / SFR Expansion Timing in Los Angeles: No explicit timing reference, score 71, Biweekly monitoring. Monitor sector-specific platform timing and potential partnership relevance.
- BTR / SFR Expansion Timing in National: No explicit timing reference, score 63, Monthly monitoring. Monitor sector-specific platform timing and potential partnership relevance.
- Acquisition Window in Sun Belt: No explicit timing reference, score 53, Monthly monitoring. Monitor pricing evidence and possible acquisition outreach timing.
- BTR / SFR Expansion Timing in Sun Belt: No explicit timing reference, score 45, Monitor Only monitoring. Monitor sector-specific platform timing and potential partnership relevance.
- BTR / SFR Expansion Timing in Florida: No explicit timing reference, score 43, Monitor Only monitoring. Monitor sector-specific platform timing and potential partnership relevance.
- BTR / SFR Expansion Timing in Other / Unknown: No explicit timing reference, score 40, Monitor Only monitoring. Monitor sector-specific platform timing and potential partnership relevance.

## Recommended Monitoring Cadence

- Monthly: 16 timing signal(s)
- Biweekly: 7 timing signal(s)
- Weekly: 4 timing signal(s)
- Monitor Only: 3 timing signal(s)

## Implications for Woomi / Woomi Global

- Timing intelligence helps separate immediate watch items from longer-cycle monitoring items.
- Refinancing, entitlement, delivery, and capital re-entry timing should feed weekly strategy and sourcing cadence decisions.
- Permit and entitlement detail is available in `entitlement_intelligence_report.md` and `la_entitlement_watch_report.md`.



## Development Lifecycle Intelligence Summary

- Lifecycle records: 54
- LA lifecycle watch items: 32
- Stage mix: Unknown Stage: 28, Vertical Construction: 4, Site Acquisition / Site Control: 8, Delivery / Opening: 9, Early Site Signal: 4
- See `development_lifecycle_report.md` and `la_development_lifecycle_watch_report.md` for project timing, entitlement, permit, construction, delivery, and refinancing stages.




## Lifecycle Transition Summary

- Lifecycle transitions analyzed: 54
- Newly detected projects: 0
- Forward progression projects: 0
- Possible stalled projects: 0
- LA lifecycle transition watch items: 30
- See `lifecycle_transition_report.md` and `la_lifecycle_transition_watch_report.md` for multi-run project movement and timing signals.

