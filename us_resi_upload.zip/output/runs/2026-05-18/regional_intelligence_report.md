# Regional Intelligence Report

Generated: 2026-05-18 16:30:54

## Top 5 Markets By Relevance

- Los Angeles: Core Watch Market, 14 article(s), average relevance 85.4.
- California: Core Watch Market, 9 article(s), average relevance 76.6.
- National / Other: General Monitoring, 26 article(s), average relevance 74.5.
- Sun Belt: Strategic Watch Market, 9 article(s), average relevance 85.2.
- Southeast: Strategic Watch Market, 4 article(s), average relevance 90.2.

## LA / California Focus

- Los Angeles: 14 article(s), 10 market signal(s), Core Watch Market. Track LA / California entitlement and zoning updates.
- California: 9 article(s), 5 market signal(s), Core Watch Market. Track LA / California entitlement and zoning updates.

## Sun Belt / Texas / Southeast

- Sun Belt: 9 article(s), 1 market signal(s), Strategic Watch Market. Monitor supply pipeline and concessions.
- Southeast: 4 article(s), 1 market signal(s), Strategic Watch Market. Monitor supply pipeline and concessions.
- Dallas: 3 article(s), 0 market signal(s), Strategic Watch Market. Track institutional capital activity.
- Florida: 3 article(s), 1 market signal(s), Strategic Watch Market. Monitor supply pipeline and concessions.
- Texas: 3 article(s), 0 market signal(s), Strategic Watch Market. Track institutional capital activity.
- Phoenix: 1 article(s), 0 market signal(s), General Monitoring. Monitor only.

## Coastal Markets

- New York: 5 article(s), 2 market signal(s), General Monitoring. Monitor supply pipeline and concessions.

## National Market Signals

- National / Other: 26 article(s), 11 market signal(s), General Monitoring. Watch GP / developer partnership opportunities.

## Deal / Project Intelligence

Market-level deal and project signals are available in `deal_pipeline_report.md`.
- Los Angeles: Disposition / Exit, Entitlement / zoning watch.
- Sun Belt: JV / Partnership, Pricing benchmark.
- Los Angeles: Construction Financing, Capital market signal.
- Los Angeles: Entitlement / Permitting, Entitlement / zoning watch.
- Los Angeles: Entitlement / Permitting, Capital market signal.

## Relationship Graph Intelligence

Market-level relationship edges are available in `relationship_graph_report.md`.
- Los Angeles: Quarterra -> Los Angeles (Disposition / Seller).
- Los Angeles: Quarterra -> Southern California (Disposition / Seller).
- Sun Belt: Alliance Residential -> Nashville (Acquisition / Buyer).
- Sun Belt: Alliance Residential -> Sun Belt (Acquisition / Buyer).
- Los Angeles: Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles -> Los Angeles (Financing Relationship).

## Canonical Deal Summary

Historical memory uses unique canonical deal/event rows from `deal_fingerprint_report.md` where available.
This reduces article-count inflation in recurring entity and relationship observations.

## Opportunity / Distress Radar

Opportunity radar is available in `opportunity_radar_report.md`.
Distress watchlist is available in `distress_watchlist_report.md`.
Canonical deal fingerprints are available in `deal_fingerprint_report.md`.
Opportunity deduplication is available in `opportunity_deduplication_report.md`.

## Implications for Woomi / Woomi Global

- Core watch markets have current signals, so LA / California monitoring should stay linked to underwriting and entitlement review.
- Strategic watch markets have current signals, so the team should compare supply, capital flow, and partnership opportunities by region.
- Markets with supply pressure should be reviewed for lease-up timing, concessions, and rent-growth assumptions.
- Markets with institutional capital signals may help Woomi identify pricing discovery and possible GP or capital partners.

## Recommended Regional Follow-up Actions

- Los Angeles: Track LA / California entitlement and zoning updates
- California: Track LA / California entitlement and zoning updates
- Sun Belt: Monitor supply pipeline and concessions
- Southeast: Monitor supply pipeline and concessions
- Dallas: Track institutional capital activity
- Florida: Monitor supply pipeline and concessions
- Texas: Track institutional capital activity
