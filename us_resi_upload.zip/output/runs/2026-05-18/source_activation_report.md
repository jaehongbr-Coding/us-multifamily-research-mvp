# Source Activation Report

Generated: 2026-05-18 16:30:54

- Total sources evaluated: 152
- Working sources: 13
- Working GP/developer sources: 2
- Manual review / placeholder sources: 118
- Failed critical sources: 8

## Top Activated GP Sources

- Blackstone Real Estate (Tier 1): Working, RSS, score 56, 2 saved article(s).
- Blackstone Real Estate Source Expansion (Tier 1): Working, RSS, score 45, 2 saved article(s).

## Strongest Signal-Generating Sources

- Urbanize LA (Tier 3): Working, RSS, score 87, 8 saved article(s).
- Yield PRO (Tier 3): Working, RSS, score 85, 10 saved article(s).
- REBusiness Online (Tier 3): Working, RSS, score 82, 9 saved article(s).
- Multifamily Dive (Tier 3): Working, RSS, score 76, 3 saved article(s).
- NAHB Eye on Housing - Multifamily (Tier 3): Working, RSS, score 70, 13 saved article(s).
- Commercial Observer (Tier 3): Working, RSS, score 61, 3 saved article(s).
- Blackstone Real Estate (Tier 1): Working, RSS, score 56, 2 saved article(s).
- Bisnow (Tier 3): Working, RSS, score 46, 2 saved article(s).
- Multifamily Executive (Tier 3): Working, RSS, score 45, 3 saved article(s).

## Highest Institutional-Value Sources

- Blackstone Real Estate (Tier 1): Working, RSS, score 56, 2 saved article(s).
- Blackstone Real Estate Source Expansion (Tier 1): Working, RSS, score 45, 2 saved article(s).

## California / LA Focused Sources

- Urbanize LA (Tier 3): Working, RSS, score 87, 8 saved article(s).
- Yield PRO (Tier 3): Working, RSS, score 85, 10 saved article(s).
- REBusiness Online (Tier 3): Working, RSS, score 82, 9 saved article(s).
- Multifamily Dive (Tier 3): Working, RSS, score 76, 3 saved article(s).
- Commercial Observer (Tier 3): Working, RSS, score 61, 3 saved article(s).
- Blackstone Real Estate (Tier 1): Working, RSS, score 56, 2 saved article(s).
- Bisnow (Tier 3): Working, RSS, score 46, 2 saved article(s).
- Blackstone Real Estate Source Expansion (Tier 1): Working, RSS, score 45, 2 saved article(s).
- Urban Land Institute (Tier 1): Failed, RSS, score 24, 0 saved article(s).
- AvalonBay Source Expansion (Tier 1): Placeholder, Manual, score 20, 0 saved article(s).
- Essex Property Trust Source Expansion (Tier 1): Placeholder, Manual, score 20, 0 saved article(s).
- Holland Partner Group Source Expansion (Tier 1): Placeholder, Manual, score 20, 0 saved article(s).
- Kennedy Wilson Newsroom (Tier 1): Placeholder, Manual, score 20, 0 saved article(s).
- Kennedy Wilson Source Expansion (Tier 1): Placeholder, Manual, score 20, 0 saved article(s).
- Landmark Properties Source Expansion (Tier 2): Placeholder, Manual, score 13, 0 saved article(s).

## Failed Critical Sources

- Berkadia Research (Tier 1): Failed, RSS, score 24, 0 saved article(s).
- Berkadia Source Expansion (Tier 1): Failed, RSS, score 24, 0 saved article(s).
- Hines Newsroom (Tier 1): Failed, RSS, score 24, 0 saved article(s).
- Hines Source Expansion (Tier 1): Failed, RSS, score 24, 0 saved article(s).
- NMHC News (Tier 1): Failed, RSS, score 24, 0 saved article(s).
- Urban Land Institute (Tier 1): Failed, RSS, score 24, 0 saved article(s).
- Walker & Dunlop Insights (Tier 1): Failed, RSS, score 24, 0 saved article(s).
- Walker & Dunlop Source Expansion (Tier 1): Failed, RSS, score 24, 0 saved article(s).

## Manual-Review Queue

- AMLI Residential Source Expansion (Tier 1): Placeholder, Manual, score 20, 0 saved article(s).
- Alliance Residential Source Expansion (Tier 1): Placeholder, Manual, score 20, 0 saved article(s).
- Apollo Real Estate Source Expansion (Tier 1): Placeholder, Manual, score 20, 0 saved article(s).
- AvalonBay Source Expansion (Tier 1): Placeholder, Manual, score 20, 0 saved article(s).
- BGO Source Expansion (Tier 1): Placeholder, Manual, score 20, 0 saved article(s).
- Brookfield Real Estate (Tier 1): Placeholder, Manual, score 20, 0 saved article(s).
- Brookfield Real Estate Source Expansion (Tier 1): Placeholder, Manual, score 20, 0 saved article(s).
- CBRE Capital Markets Source Expansion (Tier 1): Placeholder, Manual, score 20, 0 saved article(s).
- CBRE Multifamily / Living Sector (Tier 1): Placeholder, Manual, score 20, 0 saved article(s).
- CBRE Newsroom (Tier 1): Placeholder, Manual, score 20, 0 saved article(s).
- CIM Group Source Expansion (Tier 1): Placeholder, Manual, score 20, 0 saved article(s).
- Camden Property Trust Source Expansion (Tier 1): Placeholder, Manual, score 20, 0 saved article(s).
- Carlyle Real Estate Source Expansion (Tier 1): Placeholder, Manual, score 20, 0 saved article(s).
- Carmel Partners Source Expansion (Tier 1): Placeholder, Manual, score 20, 0 saved article(s).
- Cushman & Wakefield Multifamily (Tier 1): Placeholder, Manual, score 20, 0 saved article(s).

## RSS-Ready Sources

- Urbanize LA (Tier 3): Working, RSS, score 87, 8 saved article(s).
- Yield PRO (Tier 3): Working, RSS, score 85, 10 saved article(s).
- REBusiness Online (Tier 3): Working, RSS, score 82, 9 saved article(s).
- Multifamily Dive (Tier 3): Working, RSS, score 76, 3 saved article(s).
- NAHB Eye on Housing - Multifamily (Tier 3): Working, RSS, score 70, 13 saved article(s).
- Commercial Observer (Tier 3): Working, RSS, score 61, 3 saved article(s).
- Blackstone Real Estate (Tier 1): Working, RSS, score 56, 2 saved article(s).
- Bisnow (Tier 3): Working, RSS, score 46, 2 saved article(s).
- Blackstone Real Estate Source Expansion (Tier 1): Working, RSS, score 45, 2 saved article(s).
- Multifamily Executive (Tier 3): Working, RSS, score 45, 3 saved article(s).
- Construction Dive (Tier 3): Working, RSS, score 32, 0 saved article(s).
- Federal Reserve - Press Releases (Tier 3): Working, RSS, score 32, 0 saved article(s).
- HousingWire (Tier 3): Working, RSS, score 32, 0 saved article(s).

## HTML-Only / Newsroom Sources

- None detected.

## Source Quality Leaderboard

| Rank | Source | Tier | Status | Score | Saved | Signal Density |
| ---: | --- | --- | --- | ---: | ---: | ---: |
| 1 | Urbanize LA | Tier 3 | Working | 87 | 8 | 100 |
| 2 | Yield PRO | Tier 3 | Working | 85 | 10 | 100 |
| 3 | REBusiness Online | Tier 3 | Working | 82 | 9 | 100 |
| 4 | Multifamily Dive | Tier 3 | Working | 76 | 3 | 100 |
| 5 | NAHB Eye on Housing - Multifamily | Tier 3 | Working | 70 | 13 | 100 |
| 6 | Commercial Observer | Tier 3 | Working | 61 | 3 | 41 |
| 7 | Blackstone Real Estate | Tier 1 | Working | 56 | 2 | 20 |
| 8 | Bisnow | Tier 3 | Working | 46 | 2 | 17 |
| 9 | Blackstone Real Estate Source Expansion | Tier 1 | Working | 45 | 2 | 0 |
| 10 | Multifamily Executive | Tier 3 | Working | 45 | 3 | 40 |
| 11 | Construction Dive | Tier 3 | Working | 32 | 0 | 0 |
| 12 | Federal Reserve - Press Releases | Tier 3 | Working | 32 | 0 | 0 |
| 13 | HousingWire | Tier 3 | Working | 32 | 0 | 0 |
| 14 | Berkadia Research | Tier 1 | Failed | 24 | 0 | 0 |
| 15 | Berkadia Source Expansion | Tier 1 | Failed | 24 | 0 | 0 |
| 16 | Hines Newsroom | Tier 1 | Failed | 24 | 0 | 0 |
| 17 | Hines Source Expansion | Tier 1 | Failed | 24 | 0 | 0 |
| 18 | NMHC News | Tier 1 | Failed | 24 | 0 | 0 |
| 19 | Urban Land Institute | Tier 1 | Failed | 24 | 0 | 0 |
| 20 | Walker & Dunlop Insights | Tier 1 | Failed | 24 | 0 | 0 |

## Recommended Activation Actions

- Activate Tier 1 placeholders first, especially agency lenders, capital markets firms, and major GP platforms.
- Keep RSS-ready sources in the daily run and review failed critical feeds for better public URLs.
- Treat HTML-only newsroom sources as manual validation targets unless a stable feed is confirmed.
- Prioritize California / LA sources when they improve regional and relationship intelligence.
