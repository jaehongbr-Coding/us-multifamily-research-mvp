# Deal & Project Pipeline Report

Generated: 2026-05-14 16:21:11

- Total deal/project signals found: 31
- High deal intelligence count: 1

## Top 10 Deal / Project Signals

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Refinancing, New York, score 83. Capital market signal.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: General Project Signal, Los Angeles, score 73. Capital market signal.
- Entitlement / Permitting - Other / Unknown - Completion nears for mixed-use building at 3557 S. Motor Ave. in Palms: Entitlement / Permitting, Other / Unknown, score 64. Entitlement / zoning watch.
- Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal...: Construction Financing, Other / Unknown, score 63. Capital market signal.
- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Entitlement / Permitting, Los Angeles, score 63. Entitlement / zoning watch.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: General Project Signal, Sun Belt, score 63. Capital market signal.
- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: General Project Signal, Los Angeles, score 63. Entitlement / zoning watch.
- General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts: General Project Signal, Los Angeles, score 63. Entitlement / zoning watch.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: General Project Signal, Los Angeles, score 63. Entitlement / zoning watch.
- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: JV / Partnership, Sun Belt, score 62. GP partnership reference.

## California / LA Deal Watch

- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: General Project Signal, Los Angeles, score 73. Capital market signal.
- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Entitlement / Permitting, Los Angeles, score 63. Entitlement / zoning watch.
- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: General Project Signal, Los Angeles, score 63. Entitlement / zoning watch.
- General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts: General Project Signal, Los Angeles, score 63. Entitlement / zoning watch.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: General Project Signal, Los Angeles, score 63. Entitlement / zoning watch.
- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco: Entitlement / Permitting, California, score 55. Entitlement / zoning watch.

## GP / Developer Activity

- JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: JV / Partnership, Sun Belt, score 62. GP partnership reference.
- General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve...: General Project Signal, New York, score 48. Monitor only.

## Financing / Refinancing Signals

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Refinancing, New York, score 83. Capital market signal.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: General Project Signal, Los Angeles, score 73. Capital market signal.
- Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal...: Construction Financing, Other / Unknown, score 63. Capital market signal.
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl...: General Project Signal, Sun Belt, score 63. Capital market signal.

## Project Pipeline / Supply Signals

- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village...: Refinancing, New York, score 83. Capital market signal.
- General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: General Project Signal, Los Angeles, score 73. Capital market signal.
- Entitlement / Permitting - Other / Unknown - Completion nears for mixed-use building at 3557 S. Motor Ave. in Palms: Entitlement / Permitting, Other / Unknown, score 64. Entitlement / zoning watch.
- Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Entitlement / Permitting, Los Angeles, score 63. Entitlement / zoning watch.
- General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: General Project Signal, Los Angeles, score 63. Entitlement / zoning watch.
- General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts: General Project Signal, Los Angeles, score 63. Entitlement / zoning watch.
- General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: General Project Signal, Los Angeles, score 63. Entitlement / zoning watch.
- Disposition / Exit - Sun Belt - New homes make progress at 2540 Rosemead Boulevard in South El Monte: Disposition / Exit, Sun Belt, score 59. Underwriting benchmark.
- Development Start - National - Apartment Construction Starts Plummet To 15-Year Low: Development Start, National, score 55. Pipeline / supply signal.
- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco: Entitlement / Permitting, California, score 55. Entitlement / zoning watch.

## BTR / Modular / Innovation Signals

- Operational / Property Management Tech - Texas - Crypto rewards eye renters who want to save for a down payment: Operational / Property Management Tech, Texas, score 44. Underwriting benchmark.
- BTR / Build-to-Rent - National - Trump Pushes House To Pass Housing Bill With BTR Forced-Sale Provision: BTR / Build-to-Rent, National, score 31. Pipeline / supply signal.

## Pricing / Cap Rate / Valuation Signals

- Acquisition - Other / Unknown - Mapletree Pays $100M for 97-Acre Future Logistics Site in Central Jersey: Acquisition, Other / Unknown, score 46. Pricing benchmark.

## Deal / Project Signals By Residential Sector

- Apartment: 9 deal/project signal(s)
- Multifamily: 7 deal/project signal(s)
- Affordable Housing: 7 deal/project signal(s)
- General Residential: 4 deal/project signal(s)
- Senior Housing: 2 deal/project signal(s)
- Mixed-Use Residential: 1 deal/project signal(s)
- BTR / Single-Family Rental: 1 deal/project signal(s)

## Canonical Deal Summary

Canonical deal fingerprints are available in `deal_fingerprint_report.md`.
Opportunity deduplication is available in `opportunity_deduplication_report.md`.
Use those reports to separate repeated coverage from genuinely separate events.

## Relationship Graph Intelligence

Developer, lender, capital partner, market, and deal edges are available in `relationship_graph_report.md`.
- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village... -> fannie mae: Financing Relationship, score 74.
- Crescent Communities -> JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek...: JV / Partnership, score 72.
- Crescent Communities -> Nashville: JV / Partnership, score 72.
- Crescent Communities -> Sun Belt: JV / Partnership, score 72.
- Blackstone -> blackstone: Capital Flow, score 71.

## Implications for Woomi / Woomi Global

- Pricing and cap-rate deal signals should be used as valuation benchmarks for underwriting discussions.
- Financing and refinancing rows can help track lender appetite, debt sizing, and capital-market conditions.
- JV and partnership rows should be mapped to potential GP relationship targets.
- California / LA project rows should feed entitlement, zoning, and local supply monitoring.

## Recommended Follow-up Actions

- Capital market signal: read `Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village in Central Islip New York` from Yield PRO. Canonical market: New York.
- Capital market signal: read `Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.` from Urbanize LA. Canonical market: Los Angeles.
- Entitlement / zoning watch: read `Completion nears for mixed-use building at 3557 S. Motor Ave. in Palms` from Urbanize LA. Canonical market: Other / Unknown.
- Capital market signal: read `CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Caldwell New Jersey` from Yield PRO. Canonical market: Other / Unknown.
- Entitlement / zoning watch: read `New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena` from Urbanize LA. Canonical market: Los Angeles.
- Capital market signal: read `Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Florida’s Space Coast` from Yield PRO. Canonical market: Sun Belt.
- Entitlement / zoning watch: read `Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.` from Urbanize LA. Canonical market: Los Angeles.
- Entitlement / zoning watch: read `New look for affordable housing at 10304 S. Central Ave. in Watts` from Urbanize LA. Canonical market: Los Angeles.
