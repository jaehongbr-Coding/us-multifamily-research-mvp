# Regional Intelligence Report

Generated: 2026-05-13 17:23:17

## Top 5 Markets By Relevance

- Los Angeles: Core Watch Market, 1 article(s), average relevance 72.0.
- California: Core Watch Market, 1 article(s), average relevance 63.0.
- National / Other: General Monitoring, 37 article(s), average relevance 70.1.
- New York: General Monitoring, 3 article(s), average relevance 79.3.
- Florida: Strategic Watch Market, 2 article(s), average relevance 74.0.

## LA / California Focus

- Los Angeles: 1 article(s), 1 market signal(s), Core Watch Market. Track LA / California entitlement and zoning updates.
- California: 1 article(s), 0 market signal(s), Core Watch Market. Track LA / California entitlement and zoning updates.

## Sun Belt / Texas / Southeast

- Florida: 2 article(s), 1 market signal(s), Strategic Watch Market. Review development underwriting assumptions.
- Sun Belt: 2 article(s), 0 market signal(s), Strategic Watch Market. Watch GP / developer partnership opportunities.
- Texas: 2 article(s), 0 market signal(s), Strategic Watch Market. Monitor only.
- Southeast: 1 article(s), 0 market signal(s), General Monitoring. Monitor only.

## Coastal Markets

- New York: 3 article(s), 1 market signal(s), General Monitoring. Track institutional capital activity.

## National Market Signals

- National / Other: 37 article(s), 14 market signal(s), General Monitoring. Track institutional capital activity.

## Implications for Woomi / Woomi Global

- Core watch markets have current signals, so LA / California monitoring should stay linked to underwriting and entitlement review.
- Strategic watch markets have current signals, so the team should compare supply, capital flow, and partnership opportunities by region.
- Markets with institutional capital signals may help Woomi identify pricing discovery and possible GP or capital partners.

## Recommended Regional Follow-up Actions

- Los Angeles: Track LA / California entitlement and zoning updates
- California: Track LA / California entitlement and zoning updates
- Florida: Review development underwriting assumptions
- Sun Belt: Watch GP / developer partnership opportunities
- Texas: Monitor only
