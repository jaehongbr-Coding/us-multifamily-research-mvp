# Opportunity Deduplication Report

Generated: 2026-05-14 16:21:11

- Total duplicate clusters: 3
- Opportunities removed via deduplication: 0
- Distress inflation prevented: 0

## Strongest Multi-Source Confirmed Opportunities

- Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village in Central Islip New York: New York, 2 related row(s), opportunity score 68, distress score 66.
- CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Caldwell New Jersey: Other / Unknown, 2 related row(s), opportunity score 63, distress score 59.
- Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Florida’s Space Coast: Sun Belt, 2 related row(s), opportunity score 63, distress score 59.

## Repeated Refinancing Stories

- Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village in Central Islip New York: New York, 2 related row(s), opportunity score 68, distress score 66.

## Repeated GP Partnership Stories

- Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek in West Nashville.: Sun Belt, 1 related row(s), opportunity score 74, distress score 0.
- Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve Growing Energy Demand Centers Across North America: New York, 1 related row(s), opportunity score 72, distress score 0.
- Affordable Senior Housing Community Southernside West Set to Break Ground in Greenvillen South Carolina: Other / Unknown, 1 related row(s), opportunity score 53, distress score 0.

## California / LA Duplicate Project Tracking

- Onni Group plans twin 67-story towers at 5700 Wilshire Blvd.: Los Angeles, 1 related row(s), opportunity score 66, distress score 0.
- New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena: Los Angeles, 1 related row(s), opportunity score 63, distress score 0.
- Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd.: Los Angeles, 1 related row(s), opportunity score 63, distress score 0.
- New look for affordable housing at 10304 S. Central Ave. in Watts: Los Angeles, 1 related row(s), opportunity score 63, distress score 0.
- Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights: Los Angeles, 1 related row(s), opportunity score 63, distress score 0.
- Formal Permits For 375 Laguna Honda Boulevard, San Francisco: California, 1 related row(s), opportunity score 61, distress score 0.

## Why This Matters

- Deduplication prevents syndicated or repeated articles from overstating opportunity, distress, GP, and capital-flow signals.
- Multi-source confirmation still raises confidence when different sources point to the same canonical event.
