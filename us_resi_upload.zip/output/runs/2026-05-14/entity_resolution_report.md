# Entity Resolution Report

Generated: 2026-05-14 16:21:11

- Total raw entities reviewed: 96
- Total canonical entities created: 37
- Possible duplicate entity groups: 6
- Weak matches needing review: 59
- Unknown entities needing review: 4

## Top Canonical Firms

- Unknown: 86 occurrence(s)
- Blackstone: 8 occurrence(s)
- Crescent Communities: 6 occurrence(s)
- Berkadia: 2 occurrence(s)
- CBRE: 2 occurrence(s)
- Fannie Mae: 2 occurrence(s)
- JLL: 2 occurrence(s)

## Top Canonical Markets

- Other / Unknown: 35 occurrence(s)
- Los Angeles: 20 occurrence(s)
- Sun Belt: 18 occurrence(s)
- National: 15 occurrence(s)
- Unknown: 15 occurrence(s)
- New York: 14 occurrence(s)
- Texas: 6 occurrence(s)
- California: 4 occurrence(s)
- Southeast: 3 occurrence(s)
- San Francisco: 2 occurrence(s)

## Possible Duplicate Entities

- Berkadia: General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl..., berkadia
- Blackstone: Blackstone, General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve..., blackstone
- CBRE: Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal..., cbre
- Fannie Mae: Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village..., fannie mae
- Los Angeles: Development Start - National - Apartment Construction Starts Plummet To 15-Year Low, Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco, Entitlement / Permitting - Los Angeles - New look for big affordable housing complex at 2155 E. Colorado Blvd. in Pasadena, General Project Signal - Los Angeles - Mixed-use project aims for mid-2027 completion at 400 San Vicente Blvd., General Project Signal - Los Angeles - New look for affordable housing at 10304 S. Central Ave. in Watts, General Project Signal - Los Angeles - Onni Group plans twin 67-story towers at 5700 Wilshire Blvd., General Project Signal - Los Angeles - Wood framing takes shape for affordable housing at 1321 N. Mission Rd. in Lincoln Heights, General Project Signal - New York - Stagg Group Files Plans for 68 Apartments in Astoria, General Project Signal - Other / Unknown - 22 homes pitched for 1072 E. Villa St. in Pasadena, JV / Partnership - Sun Belt - Crescent Communities Started Work on Multifamily Mixed-Use Community NOVEL Richland Creek..., Los Angeles
- Sun Belt: Austin, Dallas, Disposition / Exit - Sun Belt - New homes make progress at 2540 Rosemead Boulevard in South El Monte, Miami, Nashville, Phoenix, Sun Belt

## Weak Matches Needing Manual Review

- Acquisition - Other / Unknown - Mapletree Pays $100M for 97-Acre Future Logistics Site in Central Jersey -> Acquisition - Other / Unknown - Mapletree Pays $100M for 97-Acre Future Logistics Site in Central Jersey (40, relationship_graph.csv)
- Arizona -> Arizona (40, regional_intelligence.csv)
- BTR / Build-to-Rent - National - Trump Pushes House To Pass Housing Bill With BTR Forced-Sale Provision -> BTR / Build-to-Rent - National - Trump Pushes House To Pass Housing Bill With BTR Forced-Sale Provision (40, relationship_graph.csv)
- General Project Signal - Sun Belt - Berkadia Arranges $37M Construction Bridge Loan for Waterfront Multifamily Community on Fl... -> Berkadia (60, relationship_graph.csv)
- General Project Signal - New York - Ares Acquires Stake in Rover Pipeline from Blackstone Energy Transition Partners to Serve... -> Blackstone (60, relationship_graph.csv)
- Construction Financing - Other / Unknown - CBRE Secures $30.7M Construction Loan for Luxury Multifamily Property The Vail in West Cal... -> CBRE (60, relationship_graph.csv)
- Crescent Communities -> Crescent Communities (40, deal_pipeline.csv)
- Crescent Communities -> Crescent Communities (40, gp_intelligence.csv)
- Crescent Communities -> Crescent Communities (40, institutional_relationships.csv)
- Crescent Communities -> Crescent Communities (40, relationship_graph.csv)
- Development Start - Other / Unknown - Fourth Quarter 2025 Multifamily Construction Data -> Development Start - Other / Unknown - Fourth Quarter 2025 Multifamily Construction Data (40, relationship_graph.csv)
- Development Start - Other / Unknown - Missing Middle Weakness -> Development Start - Other / Unknown - Missing Middle Weakness (40, relationship_graph.csv)
- Development Start - Other / Unknown - Overall Housing Starts Inch Lower in 2025 -> Development Start - Other / Unknown - Overall Housing Starts Inch Lower in 2025 (40, relationship_graph.csv)
- Development Start - Other / Unknown - Third Quarter 2025 Multifamily Construction Data -> Development Start - Other / Unknown - Third Quarter 2025 Multifamily Construction Data (40, relationship_graph.csv)
- Disposition / Exit - National - Swedish Investor Selling 1,500-Unit Northern Virginia Portfolio -> Disposition / Exit - National - Swedish Investor Selling 1,500-Unit Northern Virginia Portfolio (40, relationship_graph.csv)

## Relationship Graph Improvement Notes

- Canonical source and target names are now written into relationship_graph.csv.
- Deal rows now include canonical GP/developer, lender, capital partner, and market fields.
- Weak and unknown entities should be reviewed before relying on multi-run network counts.

## Recommended Cleanup Actions

- Add confirmed aliases for repeated weak matches.
- Review unknown lender, capital partner, and project/deal entities.
- Expand the market alias dictionary when new submarkets appear repeatedly.
