# Historical Memory Report

Generated: 2026-05-18 16:30:55

- Memory rows tracked: 223
- Fastest-rising GP: Quarterra
- Strongest recurring lender: JLL

## Fastest-Rising GP

- Quarterra (GP / Developer): Persistent, 19 observation(s), importance 74.

## Strongest Recurring Lender

- JLL (Lender / Debt Provider): Persistent, 19 observation(s), importance 82.
- JLL (Lender / Debt Provider): Persistent, 19 observation(s), importance 82.
- JLL (Lender / Debt Provider): Persistent, 17 observation(s), importance 74.
- JLL (Lender / Debt Provider): Persistent, 19 observation(s), importance 73.
- CBRE (Lender / Debt Provider): Fading, 24 observation(s), importance 68.
- Fannie Mae (Lender / Debt Provider): Fading, 24 observation(s), importance 68.
- CBRE (Lender / Debt Provider): Persistent, 17 observation(s), importance 65.
- cushman (Lender / Debt Provider): Persistent, 19 observation(s), importance 65.
- JLL (Lender / Debt Provider): Persistent, 17 observation(s), importance 64.
- Berkadia (Lender / Debt Provider): Fading, 24 observation(s), importance 60.

## Recurring California / LA Relationships

- Quarterra -> JLL (Relationship Edge): Persistent, 19 observation(s), importance 84.
- Quarterra (Institutional Capital Partner): Persistent, 19 observation(s), importance 83.
- JLL (Lender / Debt Provider): Persistent, 19 observation(s), importance 82.
- JLL (Lender / Debt Provider): Persistent, 19 observation(s), importance 82.
- Los Angeles -> JLL (Relationship Edge): Persistent, 19 observation(s), importance 82.
- Los Angeles -> Los Angeles (Relationship Edge): Persistent, 38 observation(s), importance 82.
- JLL -> JLL (Relationship Edge): Persistent, 17 observation(s), importance 82.
- Los Angeles -> California (Relationship Edge): Persistent, 19 observation(s), importance 82.
- Construction Financing - Los Angeles - Lendlease and Aware Super Open Mixed-Use Multifamily Community in Los Angeles (Deal / Project): Persistent, 19 observation(s), importance 80.
- Quarterra -> California (Relationship Edge): Persistent, 19 observation(s), importance 76.

## Persistent BTR / Student / Senior Housing Players

- Student Housing (Residential Sector): Persistent, 19 observation(s), importance 74.
- BTR / Build-to-Rent - Los Angeles - Core Spaces Secures $1.64B Fundraise for Student Housing Development, Investment (Deal / Project): Persistent, 19 observation(s), importance 73.
- Entitlement / Permitting - California - Formal Permits For 375 Laguna Honda Boulevard, San Francisco (Deal / Project): Fading, 24 observation(s), importance 68.
- JV / Partnership - California - Early Collaboration, Public-Private Partnerships New Norm For Bay Area Student Housing Dev... (Deal / Project): Fading, 22 observation(s), importance 68.
- Student Housing (Residential Sector): Fading, 22 observation(s), importance 68.
- cushman (Lender / Debt Provider): Persistent, 19 observation(s), importance 65.
- JLL (Lender / Debt Provider): Persistent, 17 observation(s), importance 64.
- BTR / Single-Family Rental (Residential Sector): Persistent, 17 observation(s), importance 57.
- BTR / Build-to-Rent - National - Cushman & Wakefield Brokers $26.4M Sale of 108-Home Built-to-Rent Multifamily Community Th... (Deal / Project): Persistent, 19 observation(s), importance 57.
- BTR / Single-Family Rental (Residential Sector): Fading, 21 observation(s), importance 57.

## Recurring Institutional Capital Pairings

- Quarterra -> JLL (Relationship Edge): Persistent, 19 observation(s), importance 84.
- Quarterra (Institutional Capital Partner): Persistent, 19 observation(s), importance 83.
- Los Angeles -> JLL (Relationship Edge): Persistent, 19 observation(s), importance 82.
- Los Angeles -> Los Angeles (Relationship Edge): Persistent, 38 observation(s), importance 82.
- JLL -> JLL (Relationship Edge): Persistent, 17 observation(s), importance 82.
- Los Angeles -> California (Relationship Edge): Persistent, 19 observation(s), importance 82.
- Quarterra -> California (Relationship Edge): Persistent, 19 observation(s), importance 76.
- Quarterra -> Los Angeles (Relationship Edge): Persistent, 38 observation(s), importance 76.
- California -> California (Relationship Edge): Fading, 18 observation(s), importance 75.
- California -> San Francisco (Relationship Edge): Fading, 18 observation(s), importance 75.

## Strongest Multi-Run Relationships

- Quarterra -> JLL (Relationship Edge): Persistent, 19 observation(s), importance 84.
- Los Angeles -> JLL (Relationship Edge): Persistent, 19 observation(s), importance 82.
- Los Angeles -> Los Angeles (Relationship Edge): Persistent, 38 observation(s), importance 82.
- JLL -> JLL (Relationship Edge): Persistent, 17 observation(s), importance 82.
- Los Angeles -> California (Relationship Edge): Persistent, 19 observation(s), importance 82.
- Quarterra -> California (Relationship Edge): Persistent, 19 observation(s), importance 76.
- Quarterra -> Los Angeles (Relationship Edge): Persistent, 38 observation(s), importance 76.
- California -> California (Relationship Edge): Fading, 18 observation(s), importance 75.
- California -> San Francisco (Relationship Edge): Fading, 18 observation(s), importance 75.
- Los Angeles -> Los Angeles (Relationship Edge): Persistent, 81 observation(s), importance 74.

## Accelerating Markets

- None detected.

## Fading Markets

- Florida (Market / Region): Fading, 24 observation(s), importance 53.
- Sun Belt (Market / Region): Fading, 24 observation(s), importance 53.
- Dallas (Market / Region): Fading, 24 observation(s), importance 45.
- New York (Market / Region): Fading, 17 observation(s), importance 45.
- Texas (Market / Region): Fading, 24 observation(s), importance 45.
- New York (Market / Region): Fading, 2 observation(s), importance 40.
- Florida (Market / Region): Fading, 2 observation(s), importance 37.
- New York (Market / Region): Fading, 5 observation(s), importance 37.
- Sun Belt (Market / Region): Fading, 1 observation(s), importance 35.

## Recurring Refinancing Stress Signals

- Fannie Mae (Lender / Debt Provider): Fading, 24 observation(s), importance 68.
- Blackstone (GP / Developer): Persistent, 43 observation(s), importance 60.
- Refinancing - New York - Greystone Provides $16M in Fannie Mae Financing for Multifamily Property Coventry Village... (Deal / Project): Fading, 24 observation(s), importance 60.

## Canonical Deal Summary

Capital-flow memory uses deal fingerprints from `deal_fingerprint_report.md` to avoid overstating repeated refinancing coverage.
Opportunity deduplication details are available in `opportunity_deduplication_report.md`.

## Opportunity / Distress Radar

Opportunity radar is available in `opportunity_radar_report.md`.
Distress watchlist is available in `distress_watchlist_report.md`.
Canonical deal fingerprints are available in `deal_fingerprint_report.md`.
Opportunity deduplication is available in `opportunity_deduplication_report.md`.
Timing intelligence is available in `timing_intelligence_report.md`.
Market entry window scoring is available in `market_entry_window_report.md`.
Entitlement intelligence is available in `entitlement_intelligence_report.md`.
LA entitlement watch is available in `la_entitlement_watch_report.md`.
