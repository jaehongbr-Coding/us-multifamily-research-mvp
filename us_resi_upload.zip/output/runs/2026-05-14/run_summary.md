# Run Summary

Generated: 2026-05-14 16:21:11

## Quick Counts

- Total articles saved: 43
- High-confidence signals: 14
- Opportunities: 26
- Distress signals: 3
- LA asset watch items: 28
- Dashboard cards: 33
- Pipeline health status: OK

## Key Files To Open First

- `executive_dashboard_brief.md`
- `high_confidence_watchlist_report.md`
- `pipeline_health_report.md`
- `pipeline_manifest.md`

## Top Dashboard Signal

- Berkadia (Capital Flow)

## Suggested Next Action

- Open the executive dashboard brief first, then review the high-confidence watchlist.

## Korean Report Reference

- Korean executive reports are available in `korean_reporting_index.md`.
- Start with `executive_dashboard_brief_ko.md` for a Korean executive briefing.

